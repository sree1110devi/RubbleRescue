#!/usr/bin/env python3
"""Capture a local candidate report; never saves an occupancy map or commands motion."""
import argparse,base64,html,json,math,time
from datetime import datetime,timezone
from pathlib import Path
import cv2,rclpy
from cv_bridge import CvBridge
from rclpy.node import Node
from rclpy.qos import QoSProfile,DurabilityPolicy,qos_profile_sensor_data
from sensor_msgs.msg import Image
from std_msgs.msg import String

ROOT=Path(__file__).resolve().parent

def stamp(msg):return msg.header.stamp.sec+msg.header.stamp.nanosec*1e-9

def associate(registry,report,image_stamp):
    """Only attach an image from the same detector frame to a unique nearby record."""
    matches={}
    for candidate in report.get('candidates',[]):
        s=candidate.get('stamp',{});t=s.get('sec',0)+s.get('nanosec',0)*1e-9
        p=candidate.get('map_surface_xyz_m')
        if not p or abs(t-image_stamp)>.001:continue
        near=[r for r in registry.get('candidates',[]) if math.hypot(p[0]-r['position'][0],p[1]-r['position'][1])<.8]
        if len(near)==1:matches[near[0]['label']]=t
    return matches

def render(payload):
    esc=lambda x:html.escape(str(x))
    cards=[]
    for r in payload.get('candidates',[]):
        p=r['position'];snap=r.get('camera_snapshot');photo=(f'<img alt="Annotated camera observation of {esc(r["label"])}" src="{esc(snap["path"])}"><p>Image captured at simulation {snap["simulation_seconds"]:.1f} s</p>' if snap else '<div class="missing">No matching camera image captured yet</div>')
        cards.append(f'<article><h2>{esc(r["label"])}</h2><strong class="badge">Unconfirmed · needs human review</strong>{photo}<dl><dt>Map position (metres)</dt><dd>X {p[0]:.3f} · Y {p[1]:.3f} · Z {p[2]:.3f}</dd><dt>Last seen (simulation time)</dt><dd>{r["last_seen_sim_s"]:.1f} s</dd><dt>Supporting observations</dt><dd>{r["observations"]}</dd></dl></article>')
    rejected=''.join(f'<li><b>{esc(r["label"])}</b>: {esc(r.get("review_reason","Review reason unavailable"))}</li>' for r in payload.get('rejected_candidates',[])) or '<li>None recorded.</li>'
    return '''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>RubbleRescue · Candidate report</title><style>
body{margin:0;background:#eef2f5;color:#172c3c;font:16px system-ui,sans-serif}main{max-width:1120px;margin:auto;padding:36px 24px}header{border-top:6px solid #ef9c32;padding-top:20px}h1{font-size:36px;margin:8px 0}h2{margin:0 0 14px}.sub{color:#526575}.notice{background:#fff5df;border-left:4px solid #c78316;padding:16px;line-height:1.6}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(285px,1fr));gap:20px;margin:26px 0}article{background:white;border:1px solid #d5dfe6;border-radius:12px;padding:22px;overflow:hidden}.badge{display:inline-block;color:#875200;background:#fff0cd;padding:7px 10px;border-radius:6px;font-size:13px}img{width:100%;margin-top:18px;border-radius:6px}.missing{margin-top:18px;background:#edf1f4;padding:42px 18px;text-align:center;color:#526575}dt{font-size:13px;color:#526575;margin-top:17px}dd{margin:5px 0;font-weight:600}p,li{line-height:1.6}footer{color:#526575;font-size:14px}</style><main><header><div>RUBBLERESCUE / SIMULATION</div><h1>Candidate inspection report</h1><p class="sub">'''+str(len(payload.get('candidates',[])))+' candidate locations · coordinate frame: '+esc(payload.get('frame_id','unknown'))+'</p></header><p class="notice">These are unconfirmed mannequin candidates from simulation colour and depth detection. Positions describe visible surface observations, not verified survivor locations. Localization uses the Gazebo position reference. Simulation seconds are not wall-clock times.</p><div class="grid">'+''.join(cards)+'</div><section><h2>Reviewed and rejected alerts</h2><ul>'+rejected+'</ul></section><footer>Generated '+esc(payload['generated_utc'])+' · Snapshot report; reopen a newly generated report for updated observations. No occupancy map was saved.</footer></main></html>'

class Report(Node):
    def __init__(self):
        super().__init__('rescue_report_capture');self.registry=None;self.reports=[];self.images=[];self.snapshots={};self.bridge=CvBridge()
        previous=ROOT/'rescue_report.json'
        if previous.exists():
            for r in json.loads(previous.read_text()).get('candidates',[]):
                if r.get('camera_snapshot'):self.snapshots[r['label']]=r['camera_snapshot']
        q=QoSProfile(depth=1,durability=DurabilityPolicy.TRANSIENT_LOCAL)
        self.create_subscription(String,'/survivor_candidates/registry',self.registry_cb,q)
        self.create_subscription(String,'/survivor_candidates/report',self.report_cb,10)
        self.create_subscription(Image,'/survivor_candidates/image',self.image_cb,qos_profile_sensor_data)
    def registry_cb(self,msg):self.registry=json.loads(msg.data);self.capture()
    def report_cb(self,msg):self.reports=(self.reports+[json.loads(msg.data)])[-12:];self.capture()
    def image_cb(self,msg):
        if self.snapshots and stamp(msg)<max(s['simulation_seconds'] for s in self.snapshots.values())-1:
            self.snapshots={};self.images=[];self.reports=[]
        self.images=(self.images+[msg])[-4:];self.capture()
    def capture(self):
        if not self.registry:return
        for im in self.images:
            for report in self.reports:
                for label,t in associate(self.registry,report,stamp(im)).items():
                    if label in self.snapshots and t<=self.snapshots[label]['simulation_seconds']:continue
                    data=self.bridge.imgmsg_to_cv2(im,'bgr8');ok,encoded=cv2.imencode('.jpg',data)
                    if ok:self.snapshots[label]={'path':'data:image/jpeg;base64,'+base64.b64encode(encoded).decode(),'simulation_seconds':t}
    def write(self):
        if self.registry is None:raise RuntimeError('No live registry received; report was not generated.')
        payload=json.loads(json.dumps(self.registry));payload['generated_utc']=datetime.now(timezone.utc).isoformat();payload['simulation_reference']=True
        for r in payload['candidates']:
            if r['label'] in self.snapshots:r['camera_snapshot']=self.snapshots[r['label']]
        for name,content in [('rescue_report.json',json.dumps(payload,indent=2)+'\n'),('rescue_report.html',render(payload))]:
            temporary=ROOT/(name+'.tmp');temporary.write_text(content);temporary.replace(ROOT/name)
        print(json.dumps({'candidate_count':len(payload['candidates']),'images_captured':list(self.snapshots),'report':str(ROOT/'rescue_report.html')}),flush=True)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--duration',type=float,default=12);args=parser.parse_args();rclpy.init();n=Report()
    try:
        end=time.monotonic()+args.duration
        while time.monotonic()<end:rclpy.spin_once(n,timeout_sec=.1)
        n.write()
    finally:n.destroy_node();rclpy.shutdown()
if __name__=='__main__':main()
