"""Isolated real robot_localization test: bad encoder yaw, valid IMU yaw."""
import os,time,math,json,subprocess
from pathlib import Path
os.environ['ROS_DOMAIN_ID']='95'
import yaml,rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from sensor_msgs.msg import Imu
from rclpy.qos import qos_profile_sensor_data
R=Path(__file__).resolve().parent;d=yaml.safe_load((R/'ekf.yaml').read_text());d['ekf_filter_node']['ros__parameters']['use_sim_time']=False;(R/'ekf_test.yaml').write_text(yaml.safe_dump(d,sort_keys=False));log=open(R/'ekf_test.log','w');proc=subprocess.Popen(['/opt/ros/jazzy/lib/robot_localization/ekf_node','--ros-args','--params-file',str(R/'ekf_test.yaml')],stdout=log,stderr=log)
rclpy.init();n=Node('isolated_ekf_test');op=n.create_publisher(Odometry,'/odom',10);ip=n.create_publisher(Imu,'/imu',qos_profile_sensor_data);out=[];n.create_subscription(Odometry,'/odometry/filtered',lambda m:out.append(m),10)
try:
 start=time.monotonic()
 while time.monotonic()-start<1:rclpy.spin_once(n,timeout_sec=.05)
 start=time.monotonic();t=0
 while time.monotonic()-start<4:
  t=time.monotonic()-start;stamp=n.get_clock().now().to_msg();o=Odometry();o.header.frame_id='odom';o.child_frame_id='base_link';o.header.stamp=stamp;o.pose.pose.orientation.z=math.sin(t/2);o.pose.pose.orientation.w=math.cos(t/2);o.twist.twist.linear.x=.1;o.twist.twist.angular.z=1.;o.twist.covariance[0]=o.twist.covariance[7]=.01;op.publish(o)
  i=Imu();i.header.frame_id='base_link';i.header.stamp=stamp;i.orientation.z=math.sin(.25*t/2);i.orientation.w=math.cos(.25*t/2);i.angular_velocity.z=.25;i.orientation_covariance[8]=.001;i.angular_velocity_covariance[8]=.001;ip.publish(i);rclpy.spin_once(n,timeout_sec=.02);time.sleep(.01)
 assert len(out)>30,len(out)
 q=out[-1].pose.pose.orientation;actual=math.atan2(2*q.w*q.z,1-2*q.z*q.z);error=abs(math.atan2(math.sin(actual-.25*t),math.cos(actual-.25*t)))
 result={'samples':len(out),'fused_yaw_rad':actual,'imu_yaw_rad':.25*t,'deliberately_wrong_encoder_yaw_rad':t,'fused_heading_error_rad':error,'uses_ground_truth':False};(R/'imu_ekf_check.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));assert error<.12
finally:
 n.destroy_node();rclpy.shutdown();proc.terminate()
 try:proc.wait(timeout=5)
 except subprocess.TimeoutExpired:proc.kill();proc.wait()
 log.close()
