#!/usr/bin/env python3
"""Simulation evaluation only: never publishes TF, odometry, or commands."""
import json,math,time,threading,collections
from pathlib import Path
import xml.etree.ElementTree as ET
import rclpy,tf2_ros
from rclpy.node import Node
from rclpy.executors import ExternalShutdownException
from rclpy.parameter import Parameter
from gz.transport13 import Node as GzNode
from gz.msgs10.pose_v_pb2 import Pose_V
ROOT=Path(__file__).resolve().parent

def yaw(q):return math.atan2(2*(q.w*q.z+q.x*q.y),1-2*(q.y*q.y+q.z*q.z))
def residual(anchor,current):
 tx,ty,ta,mx,my,ma=anchor;a=ta-ma;dx=current[3]-mx;dy=current[4]-my
 px=tx+math.cos(a)*dx-math.sin(a)*dy;py=ty+math.sin(a)*dx+math.cos(a)*dy
 return math.hypot(px-current[0],py-current[1]),abs(math.atan2(math.sin(current[5]+a-current[2]),math.cos(current[5]+a-current[2])))

def main():
 rclpy.init();n=Node('simulation_pose_audit_readonly',parameter_overrides=[Parameter('use_sim_time',value=True)])
 buf=tf2_ros.Buffer();listener=tf2_ros.TransformListener(buf,n);gz=GzNode();queue=collections.deque(maxlen=1000);lock=threading.Lock();rows=[];anchor=None;last=0;maximum=0.
 world=ET.parse(ROOT.parent/'final_project/world.sdf').getroot().find('world').get('name')
 def receive(m):
  for p in m.pose:
   if p.name=='rubblerescue':
    with lock:queue.append((m.header.stamp.sec,m.header.stamp.nsec,p.position.x,p.position.y,yaw(p.orientation)))
    break
 assert gz.subscribe(Pose_V,'/world/'+world+'/dynamic_pose/info',receive)
 try:
  while rclpy.ok():
   rclpy.spin_once(n,timeout_sec=.05)
   with lock:pending=list(queue)
   for sec,ns,x,y,a in pending:
    stamp=sec+ns/1e9
    if rows and stamp<=rows[-1]['sim_s']+.15:continue
    t=rclpy.time.Time(seconds=sec,nanoseconds=ns)
    if not buf.can_transform('map','base_link',t):continue
    p=buf.lookup_transform('map','base_link',t).transform
    row=(x,y,a,p.translation.x,p.translation.y,yaw(p.rotation))
    if anchor is None:anchor=row
    error,angle=residual(anchor,row);maximum=max(maximum,error)
    rows.append({'sim_s':stamp,'world_pose':[x,y,a],'map_pose':list(row[3:]),'aligned_position_error_m':error,'aligned_heading_error_rad':angle})
   if time.monotonic()-last>3:
    payload={'diagnostic_only':True,'feeds_navigation':False,'samples':len(rows),'max_aligned_position_error_m':maximum,'latest':rows[-1] if rows else None,'note':'Initial origins/headings aligned for evaluation. Later residual measures pose drift or SLAM frame corrections; it does not force map orientation.'}
    temp=ROOT/'pose_audit.tmp';temp.write_text(json.dumps(payload,indent=2)+'\n');temp.replace(ROOT/'pose_audit.json');last=time.monotonic()
   if len(rows)>1000:rows=rows[-1000:]
 except (KeyboardInterrupt,ExternalShutdownException):pass
 finally:
  n.destroy_node()
  if rclpy.ok():rclpy.shutdown()
if __name__=='__main__':main()
