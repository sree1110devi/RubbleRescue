"""Isolated ROS test. Domain 91, synthetic sensors, no Gazebo or robot."""
import os,subprocess,time,math,json
from pathlib import Path
os.environ['ROS_DOMAIN_ID']='91'
import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from lifecycle_msgs.srv import ChangeState
from geometry_msgs.msg import Twist,PolygonStamped,Point32
from sensor_msgs.msg import LaserScan
root=Path(__file__).resolve().parent
log=open(root/'predictive_monitor_test.log','w')
p=subprocess.Popen(['/opt/ros/jazzy/lib/nav2_collision_monitor/collision_monitor','--ros-args','--params-file',str(root/'nav2.yaml'),'-p','use_sim_time:=false','-p','base_shift_correction:=false','-p','observation_sources:=[scan]'],stdout=log,stderr=log)
rclpy.init();n=Node('isolated_monitor_test');seen=[]
cmd=n.create_publisher(Twist,'/nav2/cmd_vel_smoothed',10);scan=n.create_publisher(LaserScan,'/scan',qos_profile_sensor_data);foot=n.create_publisher(PolygonStamped,'/local_costmap/published_footprint',10)
n.create_subscription(Twist,'/cmd_vel',lambda m:seen.append((m.linear.x,m.angular.z)),10)
def transition(i):
 c=n.create_client(ChangeState,'/collision_monitor/change_state');assert c.wait_for_service(timeout_sec=10)
 q=ChangeState.Request();q.transition.id=i;f=c.call_async(q);rclpy.spin_until_future_complete(n,f,timeout_sec=8);assert f.done() and f.result().success
 n.destroy_client(c)
def trial(obstacle,v):
 seen.clear();end=time.monotonic()+2
 while time.monotonic()<end:
  stamp=n.get_clock().now().to_msg();f=PolygonStamped();f.header.frame_id='base_link';f.header.stamp=stamp;f.polygon.points=[Point32(x=float(x),y=float(y),z=0.) for x,y in [( .51,.28),(.51,-.28),(-.31,-.28),(-.31,.28)]];foot.publish(f)
  s=LaserScan();s.header=f.header;s.angle_min=-math.pi;s.angle_max=math.pi;s.angle_increment=2*math.pi/719;s.range_min=.05;s.range_max=10.;s.ranges=[10.]*720
  if obstacle:
   for i in range(355,365):s.ranges[i]=.65
  scan.publish(s);m=Twist();m.linear.x=v;cmd.publish(m);rclpy.spin_once(n,timeout_sec=.04)
 return list(seen[-10:])
try:
 transition(1);transition(3)
 clear=trial(False,.2);blocked=trial(True,.2);retreat=trial(True,-.1)
 assert clear and any(v>.1 for v,a in clear),clear
 assert blocked and all(abs(v)<.2 for v,a in blocked),blocked
 assert retreat and any(v<-.05 for v,a in retreat),retreat
 result={'clear_path_forward_allowed':True,'obstacle_ahead_reduces_forward_speed':True,'reverse_away_allowed':True,'isolated_domain':91,'live_gazebo_verified':False}
 (root/'predictive_monitor_check.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
finally:
 n.destroy_node();rclpy.shutdown();p.terminate()
 try:p.wait(timeout=5)
 except subprocess.TimeoutExpired:p.kill();p.wait()
 log.close()
