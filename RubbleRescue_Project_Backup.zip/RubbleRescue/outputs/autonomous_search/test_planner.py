"""Isolated real Nav2 planner test using synthetic maps, no Gazebo commands."""
import os,math,time,subprocess,json
from pathlib import Path
os.environ['ROS_DOMAIN_ID']='92'
import yaml,rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile,DurabilityPolicy
from rclpy.action import ActionClient
from lifecycle_msgs.srv import ChangeState
from nav_msgs.msg import OccupancyGrid
from geometry_msgs.msg import TransformStamped,PoseStamped
from nav2_msgs.action import ComputePathToPose
from tf2_ros.static_transform_broadcaster import StaticTransformBroadcaster
root=Path(__file__).resolve().parent
params=yaml.safe_load((root/'nav2_candidate.yaml').read_text())
params['planner_server']['ros__parameters']['use_sim_time']=False
c=params['global_costmap']['global_costmap']['ros__parameters'];c.update(use_sim_time=False,plugins=['static_layer','inflation_layer']);c['static_layer']['map_subscribe_transient_local']=True
(root/'planner_test_params.yaml').write_text(yaml.safe_dump(params,sort_keys=False))
log=open(root/'planner_test.log','w');p=subprocess.Popen(['/opt/ros/jazzy/lib/nav2_planner/planner_server','--ros-args','--params-file',str(root/'planner_test_params.yaml')],stdout=log,stderr=log)
rclpy.init();n=Node('isolated_planner_check');pub=n.create_publisher(OccupancyGrid,'/map',QoSProfile(depth=1,durability=DurabilityPolicy.TRANSIENT_LOCAL));tf=StaticTransformBroadcaster(n)
t=TransformStamped();t.header.frame_id='map';t.child_frame_id='base_link';t.transform.rotation.w=1.;tf.sendTransform(t)
def pump(seconds):
 end=time.monotonic()+seconds
 while time.monotonic()<end:rclpy.spin_once(n,timeout_sec=.05)
def change(i):
 c=n.create_client(ChangeState,'/planner_server/change_state');assert c.wait_for_service(timeout_sec=12)
 q=ChangeState.Request();q.transition.id=i;f=c.call_async(q);rclpy.spin_until_future_complete(n,f,timeout_sec=10);assert f.done() and f.result().success
 n.destroy_client(c)
def publish(blocked):
 m=OccupancyGrid();m.header.frame_id='map';m.header.stamp=n.get_clock().now().to_msg();m.info.resolution=.1;m.info.width=m.info.height=100;m.info.origin.position.x=m.info.origin.position.y=-5.;m.info.origin.orientation.w=1.;m.data=[0]*10000
 for y in range(100):
  for x in range(100):
   if x in (0,99) or y in (0,99) or (x in (49,50) and (blocked or y<60)):m.data[y*100+x]=100
 pub.publish(m);pump(2)
def pose(x,y):
 m=PoseStamped();m.header.frame_id='map';m.pose.position.x=x;m.pose.position.y=y;m.pose.orientation.w=1.;return m
def plan():
 g=ComputePathToPose.Goal();g.start=pose(-2.,0.);g.goal=pose(2.,0.);g.use_start=True;g.planner_id='GridBased';f=client.send_goal_async(g);rclpy.spin_until_future_complete(n,f,timeout_sec=8);assert f.done() and f.result().accepted
 f=f.result().get_result_async();rclpy.spin_until_future_complete(n,f,timeout_sec=8);assert f.done();return f.result()
try:
 pump(1);publish(False);change(1);change(3);client=ActionClient(n,ComputePathToPose,'/compute_path_to_pose');assert client.wait_for_server(timeout_sec=8)
 publish(False);a=plan();assert a.status==4 and len(a.result.path.poses)>5,(a.status,a.result.error_code)
 assert max(v.pose.position.y for v in a.result.path.poses)>1.0
 publish(True);b=plan();assert b.status!=4
 result={'smac_detour_around_wall':True,'blocked_route_rejected':True,'path_points':len(a.result.path.poses),'domain':92,'live_gazebo_test':False};(root/'planner_check.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
finally:
 n.destroy_node();rclpy.shutdown();p.terminate()
 try:p.wait(timeout=5)
 except subprocess.TimeoutExpired:p.kill();p.wait()
 log.close()
