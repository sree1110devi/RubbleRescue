"""Project-local robot modifications; original CAD source remains untouched."""
def remove_arm(robot):
    removed={'turret_link'}
    joints=list(robot.findall('joint'))
    changed=True
    while changed:
        changed=False
        for j in joints:
            if j.find('parent').get('link') in removed and j.find('child').get('link') not in removed:
                removed.add(j.find('child').get('link'));changed=True
    removed_joints={j.get('name') for j in joints if j.find('child').get('link') in removed}
    for e in list(robot):
        if (e.tag=='link' and e.get('name') in removed) or (e.tag=='joint' and e.get('name') in removed_joints) or (e.tag=='gazebo' and e.get('reference') in removed|removed_joints):robot.remove(e)
    for control in robot.findall('ros2_control'):
        for j in list(control):
            if j.tag=='joint' and j.get('name') in removed_joints:control.remove(j)
    for transmission in list(robot.findall('transmission')):
        if any(j.get('name') in removed_joints for j in transmission.findall('joint')):robot.remove(transmission)
    return sorted(removed)

def add_imu(robot):
    import xml.etree.ElementTree as E
    if robot.find("gazebo/sensor[@name='rescue_imu']") is None:
        gazebo=E.SubElement(robot,'gazebo',reference='base_link')
        sensor=E.SubElement(gazebo,'sensor',name='rescue_imu',type='imu')
        for tag,value in [('always_on','true'),('update_rate','100'),('topic','/imu'),('gz_frame_id','base_link')]:E.SubElement(sensor,tag).text=value
        E.SubElement(sensor,'imu')

def add_world_imu(path):
    import xml.etree.ElementTree as E
    tree=E.parse(path);world=tree.getroot().find('world')
    if not any('imu-system' in p.get('filename','') for p in world.findall('plugin')):
        E.SubElement(world,'plugin',filename='gz-sim-imu-system',name='gz::sim::systems::Imu')
    tree.write(path,encoding='unicode')
