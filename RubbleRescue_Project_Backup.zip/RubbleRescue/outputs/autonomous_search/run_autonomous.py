"""Supervised alternative to the known-layout demo; no truth-pose mapper."""
import argparse,os,signal,uuid,json
from pathlib import Path
from nav_msgs.msg import Odometry
from sensor_msgs.msg import Imu
from rclpy.qos import qos_profile_sensor_data
from robot_setup import add_world_imu
import xml.etree.ElementTree as ET
import rclpy
from rclpy.signals import SignalHandlerOptions
from project import Project,prepare_files,stop_processes,ROOT,OUT

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--autonomous',action='store_true');parser.add_argument('--world',type=Path);parser.add_argument('--no-ui',action='store_true');parser.add_argument('--manual',action='store_true');parser.add_argument('--spawn',nargs=4,type=float,default=[0,0,.2,0],metavar=('X','Y','Z','YAW'));args=parser.parse_args()
 if args.world:
  world=args.world.resolve();tree=ET.parse(world)
  if tree.getroot().find('world') is None:raise ValueError('Supply a Gazebo SDF world file')
 stop_processes(legacy=True)
 os.environ.update(RUBBLERESCUE_PROJECT_ROOT=str(ROOT),RUBBLERESCUE_SESSION_ID=uuid.uuid4().hex,RUBBLERESCUE_MANAGED_RUN='1',RUBBLE_AUTONOMOUS='1',RUBBLE_IMU_ODOMETRY='1',RUBBLE_NAV_PARAMS=str(OUT/'autonomous_search/nav2.yaml'))
 prepare_files()
 for key,value in zip(('X','Y','Z','YAW'),args.spawn):os.environ['RUBBLE_SPAWN_'+key]=str(value)
 if args.world:
  (ROOT/'world.sdf').write_text(world.read_text())
  os.environ['GZ_SIM_RESOURCE_PATH']=str(world.parent)+':'+str(world.parent/'models')+':'+os.environ.get('GZ_SIM_RESOURCE_PATH','')
 add_world_imu(ROOT/'world.sdf')
 rclpy.init(signal_handler_options=SignalHandlerOptions.NO)
 def interrupted(*a):raise KeyboardInterrupt
 for sig in (signal.SIGINT,signal.SIGTERM,signal.SIGHUP):signal.signal(sig,interrupted)
 n=Project();status={'mode':'experimental_unknown_map_exploration','ground_truth_localization':False,'preset_room_route':False,'live_validated':False}
 try:
  n.launch('simulation',['ros2','launch',str(ROOT/'simulation.launch.py')])
  n.wait(lambda:all(k in n.state for k in ('rgb','depth','scan')),90,'live sensors')
  n.create_subscription(Imu,'/imu',lambda m:n.receive('imu',m),qos_profile_sensor_data)
  n.create_subscription(Odometry,'/odometry/filtered',lambda m:n.receive('filtered_odom',m),10)
  n.launch('odometry',['ros2','run','robot_localization','ekf_node','--ros-args','--params-file',str(OUT/'autonomous_search/ekf.yaml')])
  n.wait(lambda:'filtered_odom' in n.state and 'imu' in n.state,30,'wheel + IMU odometry')
  n.launch('mapping',['ros2','launch','slam_toolbox','online_async_launch.py','slam_params_file:='+str(OUT/'autonomous_search/slam.yaml'),'use_sim_time:=true'])
  n.wait(lambda:'map' in n.state and n.state['map'].info.width>0,60,'SLAM map')
  n.launch('pose_audit',['python3',str(OUT/'autonomous_search/pose_audit.py')])
  n.launch('detector',['python3',str(OUT/'survivor_detection/survivor_candidate_detector.py')])
  n.launch('registry',['python3',str(OUT/'survivor_detection/survivor_map_markers.py'),'--ros-args','-r','/mapping_reference/odom:=/odometry/filtered'])
  n.launch('navigation',['bash',str(OUT/'navigation_setup/start_navigation.sh')])
  if not args.no_ui:
   n.launch('gazebo_gui',['gz','sim','-g']);n.launch('rviz',['bash',str(ROOT/'open_viewer.sh')])
  n.wait(lambda:'bt_navigator' in n.get_node_names(),45,'navigation nodes');n.pump(3)
  explorer=n.launch('mission',['python3',str(OUT/'autonomous_search/explore.py')]+(['--manual'] if args.manual else []))
  print('EXPLORATION_STARTED: SLAM + map-derived goals. No saved map or survivor positions.',flush=True)
  while explorer.poll() is None:n.pump(.5)
  status['explorer_exit_code']=explorer.returncode
  if explorer.returncode!=0:raise RuntimeError('Explorer crashed; see logs/mission.log')
  print('Exploration stopped; view logs/mission.log. This does not certify complete coverage.',flush=True)
  while True:n.pump(.5)
 except KeyboardInterrupt:status['phase']='stopped'
 except Exception as e:status.update(phase='failed',error=str(e));print('AUTONOMY_ERROR',str(e),flush=True)
 finally:
  (OUT/'autonomous_search/session_status.json').write_text(json.dumps(status,indent=2)+'\n')
  n.close();n.destroy_node();rclpy.shutdown()
