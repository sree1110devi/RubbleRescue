#!/usr/bin/env python3
"""Read-only live diagnostic. Never publishes velocities or navigation goals."""
import collections,json,time,math
import rclpy,tf2_ros
from rclpy.node import Node
from rclpy.parameter import Parameter
from rclpy.qos import qos_profile_sensor_data
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry,OccupancyGrid
from nav2_msgs.msg import CollisionMonitorState
from sensor_msgs.msg import LaserScan
from rosgraph_msgs.msg import Clock
from pathlib import Path
rclpy.init();n=Node('rubble_readonly_stall_check',parameter_overrides=[Parameter('use_sim_time',value=True)])
buf=tf2_ros.Buffer();listener=tf2_ros.TransformListener(buf,n);counts=collections.Counter();received={};peaks=collections.defaultdict(float);odom=[];clock=[];messages={}
def command(topic,msg):
 counts[topic]+=1;received[topic]=time.monotonic();peaks[topic]=max(peaks[topic],abs(msg.linear.x),abs(msg.angular.z));messages[topic]={'linear':msg.linear.x,'angular':msg.angular.z}
for t in ['/nav2/cmd_vel_raw','/nav2/cmd_vel_smoothed','/cmd_vel']:
 n.create_subscription(Twist,t,lambda m,t=t:command(t,m),10)
def remember(key,m):counts[key]+=1;received[key]=time.monotonic();messages[key]=m
n.create_subscription(CollisionMonitorState,'/nav2/collision_monitor_state',lambda m:remember('collision_state',m),10)
n.create_subscription(Odometry,'/odom',lambda m:odom.append(m.pose.pose.position),10)
n.create_subscription(Clock,'/clock',lambda m:clock.append(m.clock.sec+m.clock.nanosec/1e9),qos_profile_sensor_data)
n.create_subscription(LaserScan,'/scan',lambda m:remember('scan',m),qos_profile_sensor_data)
n.create_subscription(OccupancyGrid,'/local_costmap/costmap',lambda m:remember('local_costmap',m),10)
print('READ_ONLY_CHECK: watching for 10 seconds; select a nearby goal in RViz now.',flush=True)
end=time.monotonic()+10
while time.monotonic()<end:rclpy.spin_once(n,timeout_sec=.05)
result={'nodes':n.get_node_names(),'message_counts':dict(counts),'peak_command_magnitudes':dict(peaks),'last_commands':{k:v for k,v in messages.items() if k.startswith('/')},'simulation_elapsed_s':clock[-1]-clock[0] if len(clock)>1 else None,'wheel_odometry_displacement_m':math.hypot(odom[-1].x-odom[0].x,odom[-1].y-odom[0].y) if len(odom)>1 else None}
result['sample_ages_wall_s']={k:round(time.monotonic()-v,2) for k,v in received.items()}
state=messages.get('collision_state');result['collision_state']=str(state) if state else None
try:
 p=buf.lookup_transform('map','base_link',rclpy.time.Time()).transform.translation;result['map_pose']=[p.x,p.y,p.z]
except Exception as e:result['map_transform_error']=str(e)
if not clock:reason='No simulation clock received: check the project is running in ROS_DOMAIN_ID=42.'
elif len(clock)<2 or clock[-1]<=clock[0]:reason='Simulation paused or clock stalled.'
elif not counts['scan']:reason='No LiDAR scan received.'
elif not peaks['/nav2/cmd_vel_raw']:reason='Controller sent no nonzero motion during this window; inspect current goal/controller errors.'
elif not peaks['/nav2/cmd_vel_smoothed']:reason='Motion stops at the velocity smoother.'
elif not peaks['/cmd_vel']:reason='Motion stops at the collision monitor; inspect its state and sensor freshness.'
else:reason='Motion reaches /cmd_vel; compare physical pose and wheel movement for obstruction, traction, or Gazebo drive issues.'
result['diagnostic']=reason
path=Path(__file__).with_name('stall_diagnostic.json');path.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2));print('Saved:',path,flush=True)
n.destroy_node();rclpy.shutdown()
