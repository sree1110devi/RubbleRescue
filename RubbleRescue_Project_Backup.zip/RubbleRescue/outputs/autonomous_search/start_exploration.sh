#!/usr/bin/env bash
set -euo pipefail
bash /home/sreedevi-k/Documents/Codex/2026-11-18/th/outputs/final_project/run_project.sh --autonomous "$@"
