"""Isolated Gazebo turning audit: truth is used for evaluation only."""
import os,subprocess,time,signal,threading,math,json
from pathlib import Path
import xml.etree.ElementTree as E
import numpy as np
from gz.transport13 import Node
from gz.msgs10.twist_pb2 import Twist
from gz.msgs10.pose_v_pb2 import Pose_V
from gz.msgs10.odometry_pb2 import Odometry
from gz.msgs10.imu_pb2 import IMU
from robot_setup import remove_arm,add_imu,add_world_imu
R=Path(__file__).resolve().parent
robot=E.fromstring(subprocess.check_output(['xacro',str(R.parent/'lidar_mount_fix/Unsaved.urdf.xacro')],text=True));remove_arm(robot);add_imu(robot);E.ElementTree(robot).write(R/'imu_robot.urdf')
sdf=subprocess.check_output(['gz','sdf','-p',str(R/'imu_robot.urdf')],text=True)
robot=E.fromstring(sdf).find('model');robot.set('name','rubblerescue');E.SubElement(robot,'pose').text='0 0 .05 0 0 0'
for link in robot.findall('link'):
 for sensor in list(link.findall('sensor')):
  if sensor.get('type')!='imu':link.remove(sensor)
for uri in robot.findall('.//uri'):uri.text=uri.text.replace('model://robocar_description/',Path('/home/sreedevi-k/rubblerescue_ws/src/robocar_description').as_uri()+'/')
world=E.parse(R.parent/'final_project/world.sdf');w=world.getroot().find('world');w.set('name','turn_audit')
for v in list(w):
 if v.tag=='include' or (v.tag=='model' and v.get('name')!='ground_plane') or (v.tag=='plugin' and 'sensors-system' in v.get('filename','')):w.remove(v)
w.append(robot);world.write(R/'turn_audit.sdf');add_world_imu(R/'turn_audit.sdf')
os.environ['GZ_PARTITION']='turn_audit_'+str(os.getpid());lock=threading.Lock();data={'world':[],'encoder':[],'imu':[]};node=Node()
def yaw(q):return math.atan2(2*(q.w*q.z+q.x*q.y),1-2*(q.y*q.y+q.z*q.z))
def record(key,q):
 with lock:data[key].append(yaw(q))
def truth(m):
 for p in m.pose:
  if p.name=='rubblerescue':record('world',p.orientation)
assert node.subscribe(Pose_V,'/world/turn_audit/pose/info',truth)
assert node.subscribe(Odometry,'/odom',lambda m:record('encoder',m.pose.orientation))
assert node.subscribe(IMU,'/imu',lambda m:record('imu',m.orientation))
pub=node.advertise('/cmd_vel',Twist);log=open(R/'turn_audit.log','w');server=subprocess.Popen(['gz','sim','-r','-s',str(R/'turn_audit.sdf')],stdout=log,stderr=log,start_new_session=True)
try:
 time.sleep(3)
 for _ in range(100):
  msg=Twist();msg.angular.z=.6;pub.publish(msg);time.sleep(.1)
 msg=Twist();pub.publish(msg);time.sleep(2)
 with lock:values={k:list(v) for k,v in data.items()}
 assert all(len(v)>10 for v in values.values()),{k:len(v) for k,v in values.items()}
 deltas={k:float(np.unwrap(v)[-1]-np.unwrap(v)[0]) for k,v in values.items()}
 result={'sample_counts':{k:len(v) for k,v in values.items()},'heading_changes_rad':deltas,'encoder_heading_error_rad':abs(deltas['encoder']-deltas['world']),'imu_heading_error_rad':abs(deltas['imu']-deltas['world']),'evaluation_only':True}
 (R/'turn_odometry_check.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));assert result['imu_heading_error_rad']<.05
finally:
 try:os.killpg(server.pid,signal.SIGTERM);server.wait(timeout=5)
 except subprocess.TimeoutExpired:os.killpg(server.pid,signal.SIGKILL);server.wait()
 log.close()
