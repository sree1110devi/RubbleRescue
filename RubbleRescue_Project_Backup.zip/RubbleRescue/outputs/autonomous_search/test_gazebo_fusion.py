"""End-to-end isolated Gazebo IMU -> ROS bridge -> EKF turning test."""
import os,time,math,json,subprocess,signal
from pathlib import Path
os.environ['ROS_DOMAIN_ID']='96';os.environ['GZ_PARTITION']='fusion_test_'+str(os.getpid())
import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from nav_msgs.msg import Odometry
from sensor_msgs.msg import Imu
from gz.transport13 import Node as GzNode
from gz.msgs10.twist_pb2 import Twist
R=Path(__file__).resolve().parent
jobs=[];logs=[]
def launch(label,cmd):
 log=open(R/('fusion_'+label+'.log'),'w');logs.append(log);p=subprocess.Popen(cmd,stdout=log,stderr=log,start_new_session=True);jobs.append(p)
def yaw(q):return math.atan2(2*(q.w*q.z+q.x*q.y),1-2*(q.y*q.y+q.z*q.z))
launch('gazebo',['gz','sim','-r','-s',str(R/'turn_audit.sdf')])
launch('bridge',['ros2','run','ros_gz_bridge','parameter_bridge','/imu@sensor_msgs/msg/Imu[gz.msgs.IMU','/odom@nav_msgs/msg/Odometry[gz.msgs.Odometry','/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock'])
launch('ekf',['/opt/ros/jazzy/lib/robot_localization/ekf_node','--ros-args','--params-file',str(R/'ekf.yaml')])
rclpy.init();n=Node('isolated_gazebo_fusion_check');imu=[];fused=[];raw=[]
n.create_subscription(Imu,'/imu',lambda m:imu.append(m),qos_profile_sensor_data)
n.create_subscription(Odometry,'/odometry/filtered',lambda m:fused.append(m),10)
n.create_subscription(Odometry,'/odom',lambda m:raw.append(m),10)
gz=GzNode();pub=gz.advertise('/cmd_vel',Twist)
def pump(duration,turn=0.):
 end=time.monotonic()+duration
 while time.monotonic()<end:
  m=Twist();m.angular.z=turn;pub.publish(m);rclpy.spin_once(n,timeout_sec=.03)
try:
 pump(4);assert imu and fused,{'imu':len(imu),'filtered':len(fused)}
 first_imu=yaw(imu[-1].orientation);first_fused=yaw(fused[-1].pose.pose.orientation)
 pump(7,.6);pump(1)
 di=math.atan2(math.sin(yaw(imu[-1].orientation)-first_imu),math.cos(yaw(imu[-1].orientation)-first_imu));df=math.atan2(math.sin(yaw(fused[-1].pose.pose.orientation)-first_fused),math.cos(yaw(fused[-1].pose.pose.orientation)-first_fused));error=abs(math.atan2(math.sin(di-df),math.cos(di-df)))
 result={'imu_frame':imu[-1].header.frame_id,'imu_samples':len(imu),'filtered_samples':len(fused),'raw_odom_samples':len(raw),'heading_error_rad':error,'isolated_domain':96,'full_house_mapping_test':False};(R/'gazebo_fusion_check.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));assert error<.05
finally:
 n.destroy_node();rclpy.shutdown()
 for p in jobs:
  try:os.killpg(p.pid,signal.SIGTERM)
  except ProcessLookupError:pass
 for p in jobs:
  try:p.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
 for f in logs:f.close()
