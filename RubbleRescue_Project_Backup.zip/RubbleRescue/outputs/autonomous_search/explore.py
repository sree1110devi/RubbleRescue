#!/usr/bin/env python3
"""Live frontier exploration; no preset stations or survivor positions."""
import json,math,time,signal
from pathlib import Path
import numpy as np,rclpy,tf2_ros
from rclpy.node import Node
from rclpy.signals import SignalHandlerOptions
from rclpy.executors import ExternalShutdownException
from rclpy.parameter import Parameter
from rclpy.action import ActionClient
from rclpy.qos import QoSProfile,DurabilityPolicy
from nav_msgs.msg import OccupancyGrid
from nav2_msgs.action import NavigateToPose,Spin
from geometry_msgs.msg import Twist,PoseStamped
from frontiers import goals

class Explorer(Node):
 def __init__(self,manual=False):
  super().__init__('rubble_frontier_explorer',parameter_overrides=[Parameter('use_sim_time',value=True)])
  self.map=None;self.blacklist=[];self.visited=[];self.goal_handle=None
  self.manual_mode=manual;self.operator_goal=None
  self.create_subscription(PoseStamped,'/rubblerescue/operator_goal',self.clicked_goal,10)
  self.tf=tf2_ros.Buffer();self.listener=tf2_ros.TransformListener(self.tf,self)
  self.create_subscription(OccupancyGrid,'/map',lambda m:setattr(self,'map',m),QoSProfile(depth=1,durability=DurabilityPolicy.TRANSIENT_LOCAL))
  self.nav=ActionClient(self,NavigateToPose,'/navigate_to_pose');self.spin=ActionClient(self,Spin,'/spin')
  self.stop=self.create_publisher(Twist,'/cmd_vel',10);self.last_clock=None;self.last_tick=time.monotonic()
 def clicked_goal(self,msg):
  p=msg.pose.position;q=msg.pose.orientation
  if msg.header.frame_id!='map' or not all(math.isfinite(v) for v in (p.x,p.y,q.x,q.y,q.z,q.w)) or q.x*q.x+q.y*q.y+q.z*q.z+q.w*q.w<.01:
   self.get_logger().warn('Rejected invalid goal; select a position in the map frame');return
  self.manual_mode=True;self.operator_goal=msg
  print('OPERATOR_GOAL_RECEIVED',p.x,p.y,flush=True)
 def pump(self,seconds):
  end=time.monotonic()+seconds
  while time.monotonic()<end:
   rclpy.spin_once(self,timeout_sec=.05)
   tick=self.get_clock().now().nanoseconds
   if tick!=self.last_clock:self.last_tick=time.monotonic();self.last_clock=tick
   if time.monotonic()-self.last_tick>20:raise RuntimeError('Simulation clock stalled')
 def action(self,client,goal,limit):
  if self.operator_goal is not None:return False
  f=client.send_goal_async(goal)
  end=time.monotonic()+10
  while not f.done() and time.monotonic()<end:self.pump(.1)
  if not f.done():raise RuntimeError('Navigation action did not acknowledge goal')
  self.goal_handle=f.result()
  if not self.goal_handle.accepted:self.goal_handle=None;return False
  f=self.goal_handle.get_result_async();start=self.get_clock().now().nanoseconds/1e9;wall=time.monotonic()
  while not f.done() and self.operator_goal is None and self.get_clock().now().nanoseconds/1e9-start<limit and time.monotonic()-wall<900:self.pump(.1)
  if not f.done():
   cancel=self.goal_handle.cancel_goal_async();deadline=time.monotonic()+8
   while not cancel.done() and time.monotonic()<deadline:self.pump(.1)
   if not cancel.done() or (not cancel.result().goals_canceling and not f.done()):raise RuntimeError('Navigation cancellation not acknowledged')
   while not f.done() and time.monotonic()<deadline:self.pump(.1)
   if not f.done():raise RuntimeError('Old action did not finish after cancellation')
   self.goal_handle=None;return False
  self.goal_handle=None;outcome=f.result()
  if outcome.status!=4:print('NAVIGATION_FAILURE',outcome.status,getattr(outcome.result,'error_code',None),getattr(outcome.result,'error_msg',''),flush=True)
  return outcome.status==4
 def sweep(self,views=6,after_goal=False):
  # Short increments allow registry observations while stopped at each view.
  for i in range(views):
   if self.operator_goal is not None or (self.manual_mode and not after_goal):return False
   print('CAMERA_SWEEP',i+1,'/',views,flush=True)
   g=Spin.Goal();g.target_yaw=math.pi/3;g.time_allowance.sec=20
   if not self.action(self.spin,g,30):
    print('CAMERA_SWEEP_INCOMPLETE blocked or interrupted',flush=True);return False
   start=self.get_clock().now().nanoseconds
   while self.operator_goal is None and (self.get_clock().now().nanoseconds-start)/1e9<4:self.pump(.1)
  print('CAMERA_SWEEP_COMPLETE',views*60,'degrees',flush=True)
  return True
 def run(self):
  if not self.nav.wait_for_server(timeout_sec=60) or not self.spin.wait_for_server(timeout_sec=10):raise RuntimeError('Nav2 unavailable')
  self.pump(3);self.sweep(1);empty=0
  while True:
   if self.manual_mode:
    if self.operator_goal is None:self.pump(.1);continue
    selected=self.operator_goal;self.operator_goal=None
    g=NavigateToPose.Goal();g.pose=selected;g.pose.header.stamp=self.get_clock().now().to_msg()
    ok=self.action(self.nav,g,180)
    print('OPERATOR_GOAL_RESULT', 'reached' if ok else 'failed or superseded; waiting for your next goal',flush=True)
    if ok and self.operator_goal is None:self.sweep(6,after_goal=True)
    continue
   if empty>=5:
    self.manual_mode=True
    print('EXPLORATION_STOPPED no eligible frontier; waiting for operator goal',flush=True);continue
   if self.map is None:self.pump(1);continue
   try:p=self.tf.lookup_transform('map','base_link',rclpy.time.Time()).transform.translation
   except tf2_ros.TransformException:self.pump(1);continue
   m=self.map;grid=np.asarray(m.data).reshape(m.info.height,m.info.width)
   candidates=goals(grid,m.info.resolution,(m.info.origin.position.x,m.info.origin.position.y),(p.x,p.y),self.blacklist+self.visited)
   if not candidates:empty+=1;self.pump(2);continue
   empty=0;x,y=candidates[0]
   g=NavigateToPose.Goal();g.pose.header.frame_id='map';g.pose.header.stamp=self.get_clock().now().to_msg();g.pose.pose.position.x=x;g.pose.pose.position.y=y
   a=math.atan2(y-p.y,x-p.x);g.pose.pose.orientation.z=math.sin(a/2);g.pose.pose.orientation.w=math.cos(a/2)
   print('FRONTIER_GOAL',x,y,flush=True)
   if self.action(self.nav,g,150):self.visited.append((x,y));self.sweep()
   else:self.blacklist.append((x,y));print('FRONTIER_BLOCKED',x,y,flush=True)
  print('EXPLORATION_STOPPED no more eligible reachable frontiers; this does not prove all survivors were found',flush=True)

def main():
 import argparse
 parser=argparse.ArgumentParser();parser.add_argument('--manual',action='store_true');args=parser.parse_args()
 rclpy.init(signal_handler_options=SignalHandlerOptions.NO)
 def interrupted(*a):raise KeyboardInterrupt
 for sig in (signal.SIGINT,signal.SIGTERM,signal.SIGHUP):signal.signal(sig,interrupted)
 n=Explorer(manual=args.manual)
 try:n.run()
 except (KeyboardInterrupt,ExternalShutdownException):pass
 finally:
  for sig in (signal.SIGINT,signal.SIGTERM,signal.SIGHUP):signal.signal(sig,signal.SIG_IGN)
  if n.goal_handle:n.goal_handle.cancel_goal_async();n.pump(.5)
  for _ in range(3):n.stop.publish(Twist());rclpy.spin_once(n,timeout_sec=.05)
  Path(__file__).with_name('exploration_status.json').write_text(json.dumps({'visited':n.visited,'blocked':n.blacklist,'all_survivors_found':False},indent=2)+'\n')
  n.destroy_node()
  if rclpy.ok():rclpy.shutdown()
if __name__=='__main__':main()
