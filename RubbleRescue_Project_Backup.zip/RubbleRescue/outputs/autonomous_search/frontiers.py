"""Map-derived exploration goals. No world geometry or scene coordinates."""
import numpy as np
from scipy import ndimage as ndi

def goals(grid,resolution,origin,position,blacklist=()):
    free=(grid>=0)&(grid<25)
    clearance=ndi.distance_transform_edt(grid<50)*resolution
    safe=free&(clearance>.62)
    sx=int((position[0]-origin[0])/resolution);sy=int((position[1]-origin[1])/resolution)
    if not (0<=sy<grid.shape[0] and 0<=sx<grid.shape[1]):return []
    # Flood only known free cells from the robot. Reject disconnected rooms.
    seed=np.zeros_like(free);seed[sy,sx]=free[sy,sx]
    reachable=ndi.binary_propagation(seed,mask=free)
    frontier=reachable&ndi.binary_dilation(grid<0)
    labels,n=ndi.label(frontier)
    result=[]
    yy,xx=np.where(safe&reachable)
    for i in range(1,n+1):
        cells=np.argwhere(labels==i)
        if len(cells)*resolution<.35:continue
        # Use actual boundary samples, not a perimeter centroid inside the room.
        for cy,cx in cells[::max(1,int(.8/resolution))]:
            dist=np.hypot(yy-cy,xx-cx)*resolution
            valid=(dist>.45)&(dist<1.25)
            if not np.any(valid):continue
            candidates=np.where(valid)[0]
            j=candidates[np.argmin(dist[candidates])]
            x=origin[0]+(xx[j]+.5)*resolution;y=origin[1]+(yy[j]+.5)*resolution
            distance=np.hypot(x-position[0],y-position[1])
            if distance<.5 or any(np.hypot(x-a,y-b)<.9 for a,b in blacklist):continue
            result.append((float(distance-.08*min(len(cells)*resolution,8)),x,y))
    return [(x,y) for _,x,y in sorted(result)]
