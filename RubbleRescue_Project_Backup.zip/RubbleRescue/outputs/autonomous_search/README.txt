RubbleRescue — experimental unknown-map exploration

Start in a terminal after stopping the previous project with Ctrl+C:
  bash /home/sreedevi-k/Documents/Codex/2026-11-18/th/outputs/autonomous_search/start_exploration.sh

Use a different Gazebo world and choose a safe spawn location (metres, yaw radians):
  bash /home/sreedevi-k/Documents/Codex/2026-11-18/th/outputs/autonomous_search/start_exploration.sh --world /absolute/path/building.sdf --spawn 0 0 0.2 0

World files must include Gazebo physics, user-command, scene-broadcaster and sensor systems and resolve their model resources. Spawn must be on clear ground. Default world remains the rubble house; its layout is not passed to the explorer.

Changes from the known-layout demonstration:
* No map bootstrap teleports or preset room goals.
* No Gazebo ground-truth pose reference or known-survivor coordinates.
* slam_toolbox uses LiDAR scan matching, loop closure and wheel odometry.
* Nav2 uses odom; camera detection and marker registry run during exploration.
* Goals come from reachable known-free cells near unexplored map boundaries.
* Unsuccessful goals are excluded and other frontier goals are tried.
* Robot pauses and turns to observe with the camera after reaching a frontier.
* Occupancy maps are not saved.

Validation: frontier selection tested on synthetic grids, changed map origin, enclosed rooms and disconnected rooms; configuration and Python syntax checked. Full live navigation on a new world has NOT been verified. This is not a completed or certified autonomous rescue system. Wheel odometry drift, LiDAR geometry, narrow passages, camera occlusion and poor traction can prevent progress.

The detector remains a simulation colour/depth mannequin detector, NOT a trained general human detector. New people, clothing, lighting or victim postures require an appropriate trained detector and validation. Camera visibility is necessary; the system cannot see through rubble. Labels remain unconfirmed candidates.

No remaining eligible frontiers means exploration has stopped; it does NOT prove complete coverage or that every survivor was found. Blocked frontier exclusions persist for the session. Known-layout guide/results/evaluator do not certify this mode. Current logs are in outputs/final_project/logs; exploration_status.json records visited and blocked goals.

Operator-selected destinations
Start with --manual to wait for RViz clicks instead of exploring automatically:
  bash /home/sreedevi-k/Documents/Codex/2026-11-18/th/outputs/autonomous_search/start_exploration.sh --manual
Use the newly opened operator_view.rviz window. Its 2D Goal Pose publishes /rubblerescue/operator_goal. Close older RViz windows whose goal tools still publish /goal_pose.
A click in automatic mode cancels the active navigation/spin action and permanently transfers control to operator goals for that session. A second click cancels the previous goal before starting the new one. Automatic exploration resumes only after restarting without --manual. Safety stopping and replanning remain enabled. Select a clear known-free location; unknown or blocked destinations can fail and the failure is logged, not bypassed.
Validation: actual ROS node initialization, operator takeover and sweep suppression checked; mocked active-action cancellation ordering checked. Live click-to-arrival testing is still pending.

Predictive safety update: collision monitor now uses FootprintApproach with the padded local-costmap footprint and a 1.2 second collision prediction horizon. LiDAR and depth inputs remain required. An isolated real ROS monitor test (domain 91, synthetic LiDAR only) verified clear forward motion, speed reduction for an obstacle ahead, and reversing away. Full live Gazebo behavior with both sensors is not yet verified. Previous fixed-zone config retained in nav2_before_predictive_safety.yaml.

Planner review update: experimental mode now uses installed SmacPlanner2D instead of Navfn following an internal Navfn planning error. Isolated real planner tests passed wall detour and blocked-route rejection. Explorer, sensor adapter, detector and registry all exited cleanly on SIGINT in isolated ROS tests. Live full-scene behavior and SLAM survivor-position consistency remain unverified. See latest_audit.json, planner_check.json and shutdown_check.json.

Arm removal and post-goal observation update
The project robot generator removes the turret/arm/fingers and their joints/control entries. Wheels, cage, LiDAR and RGB-D camera remain. After an operator goal succeeds, six 60-degree Spin actions provide a full sweep, each followed by 4 simulated seconds stopped for detection. New operator goals interrupt the sweep. Collision-blocked turns stop the sweep and log CAMERA_SWEEP_INCOMPLETE. No unsafe forced rotation is commanded.
The three supplied synchronized samples (20261125-155054/155120/155253) all retain mannequin proposals, including lying and seated subjects. These samples do not demonstrate detection through occluding rubble.
A read-only simulation pose audit runs alongside SLAM. It uses Gazebo pose ONLY to evaluate relative pose drift; it publishes no TF, odometry or commands and supplies nothing to navigation. pose_audit.json compares timestamp-matched poses after initial origin/heading alignment. This does not fix or certify SLAM accuracy. Live drive/turn measurements are still needed.

Wheel/IMU odometry correction
The pose audit measured ~7 m current drift and 11.6 m maximum after initial frame alignment. A separate Gazebo turn test measured wheel-yaw error 1.3834 rad while IMU error was 0.00000165 rad. Autonomous mode now adds a 100 Hz onboard IMU, bridges /imu, and uses installed robot_localization to fuse wheel linear velocity and IMU heading/angular rate. Raw wheel heading/position are not fused. The raw Gazebo odom TF bridge is disabled in this mode, leaving EKF as the sole odom -> base_link TF authority. SLAM supplies map -> odom. Both IMU and filtered odometry must arrive before mapping starts. The registry and navigation adapter consume filtered odometry. No ground-truth pose feeds localization. Turns were reduced to 0.45 rad/s target maximum.
The isolated sensor-to-bridge-to-EKF test passed; this does not validate the complete house map. Restart clears the corrupted online map and in-memory candidate markers. The original URDF sources remain unchanged. Full-house pose audit and candidate-location validation remain required.
