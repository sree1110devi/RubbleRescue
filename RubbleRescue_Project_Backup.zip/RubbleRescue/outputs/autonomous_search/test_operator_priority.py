"""Regression test: finish old action cancellation before forwarding a click."""
from types import SimpleNamespace as NS
from explore import Explorer
class Future:
 def __init__(self,result=None,done=False):self.value=result;self.ready=done
 def done(self):return self.ready
 def result(self):return self.value
result=Future(NS(status=5))
events=[]
class Handle:
 accepted=True
 def get_result_async(self):return result
 def cancel_goal_async(self):
  events.append('cancel_requested')
  return Future(NS(goals_canceling=[1]),True)
handle=Handle()
class Client:
 def send_goal_async(self,goal):events.append('old_goal_sent');return Future(handle,True)
node=NS(operator_goal=None,goal_handle=None,get_clock=lambda:NS(now=lambda:NS(nanoseconds=0)))
def pump(seconds):
 if 'cancel_requested' in events:
  result.ready=True;events.append('old_action_finished')
 else:node.operator_goal='clicked_goal';events.append('click_received')
node.pump=pump
assert Explorer.action(node,Client(),None,20) is False
assert events==['old_goal_sent','click_received','cancel_requested','old_action_finished'],events
assert node.goal_handle is None
print('PASS: click interrupts active goal; cancellation completes before a replacement can be sent.')
