"""Continuous camera tracks prevent extra labels during SLAM position shifts.
Track keys are observations, not verified person identities.
"""
import math

def source_key(candidate):
 session=candidate.get('detector_session');track=candidate.get('candidate_id')
 return str(session)+':'+str(track) if session and track is not None else None

def update_position(record,point):
 p=list(map(float,point))
 if math.hypot(p[0]-record['position'][0],p[1]-record['position'][1])>.4:
  record['position_status']='unstable_map_shift'
  waiting=record.get('relocation_check')
  if waiting and math.hypot(p[0]-waiting['position'][0],p[1]-waiting['position'][1])<.2:
   waiting['observations']+=1;waiting['position']=p
  else:waiting={'position':p,'observations':1};record['relocation_check']=waiting
  if waiting['observations']>=3:
   record['position']=p;record['position_status']='stable_observations_after_map_shift';record.pop('relocation_check',None)
 else:
  record['position']=[.85*a+.15*b for a,b in zip(record['position'],p)]
  record['position_status']='stable_observations';record.pop('relocation_check',None)
