#!/usr/bin/env python3
"""In-memory, unconfirmed candidate registry. Does not save map or reports."""
import json,math,time
from pathlib import Path
import rclpy
from rclpy.node import Node
from rclpy.executors import ExternalShutdownException
from rclpy.parameter import Parameter
from rclpy.qos import QoSProfile,DurabilityPolicy
from std_msgs.msg import String
from nav_msgs.msg import Odometry
from stationary_observation_gate import StationaryGate
from track_registration import source_key,update_position
from visualization_msgs.msg import Marker,MarkerArray

class Registry(Node):
 def __init__(self):
  super().__init__('survivor_map_registry',parameter_overrides=[Parameter('use_sim_time',value=True)])
  self.records=[];self.pending=[];self.rejected=[];self.gate=StationaryGate();self.declare_parameter('merge_radius',.8)
  self.radius=float(self.get_parameter('merge_radius').value)
  self.declare_parameter('restore_observation_log','')
  restore=self.get_parameter('restore_observation_log').value
  if restore:
   lines=Path(restore).read_text().splitlines()
   entries=[json.loads(line.split(' ',1)[1]) for line in lines if line.startswith('FINAL_REGISTRY ')]
   if not entries or entries[-1].get('frame_id')!='map':raise ValueError('No map-frame registry observation in log.')
   for old in entries[-1].get('candidates',[]):
    if not all(math.isfinite(float(v)) for v in old['position']):raise ValueError('Invalid historical location')
    record=dict(old);record['historical_restored']=True;self.records.append(record)
   self.get_logger().warn('Restored '+str(len(self.records))+' historical observations from diagnostic log. They remain unconfirmed; last-seen times are preserved and fresh observations are required.')
  self.declare_parameter('restore_snapshot_path','')
  snapshot=self.get_parameter('restore_snapshot_path').value
  if snapshot:
   payload=json.loads(Path(snapshot).read_text())
   if payload.get('frame_id')!='map':raise ValueError('Snapshot is not in map frame')
   self.records=payload.get('candidates',[]);self.rejected=payload.get('rejected_candidates',[])
   self.get_logger().warn('Restored a same-session observation snapshot with original last-seen timestamps; no new detections inferred.')
  self.declare_parameter('reject_labels','')
  self.declare_parameter('rejection_reason','Rejected after manual visual review.')
  rejected_labels=set(filter(None,self.get_parameter('reject_labels').value.split(',')))
  for record in list(self.records):
   if record['label'] in rejected_labels:
    self.records.remove(record);record['classification']='rejected_candidate';record['review_reason']=self.get_parameter('rejection_reason').value;self.rejected.append(record)
  self.next_label=1+max([int(r['label'][1:]) for r in self.records+self.rejected]+[0])
  self.create_subscription(Odometry,'/mapping_reference/odom',self.motion,20)
  self.pub=self.create_publisher(MarkerArray,'/survivor_candidates/map_markers',QoSProfile(depth=1,durability=DurabilityPolicy.TRANSIENT_LOCAL))
  self.report=self.create_publisher(String,'/survivor_candidates/registry',QoSProfile(depth=1,durability=DurabilityPolicy.TRANSIENT_LOCAL))
  self.sub=self.create_subscription(String,'/survivor_candidates/report',self.observe,10)
  self.timer=self.create_timer(1.,self.publish);self.lastwarn=0
  self.get_logger().info('Persistent candidate markers enabled: Stationary observation gate and 3 map observations required; 0.8 m default merge radius; in-memory only. Labels do not confirm a person or count unique survivors.')
 def motion(self,msg):
  p=msg.pose.pose;q=p.orientation;t=msg.header.stamp.sec+msg.header.stamp.nanosec*1e-9
  a=math.atan2(2*(q.w*q.z+q.x*q.y),1-2*(q.y*q.y+q.z*q.z))
  self.gate.update(t,p.position.x,p.position.y,a)
 def observe(self,msg):
  try:data=json.loads(msg.data)
  except (ValueError,TypeError):return
  used=set()
  for c in data.get('candidates',[]):
   p=c.get('map_surface_xyz_m');stamp=c.get('stamp',{});sec=float(stamp.get('sec',0))+float(stamp.get('nanosec',0))*1e-9
   if not p or len(p)!=3 or not all(math.isfinite(float(v)) for v in p):
    if time.monotonic()-self.lastwarn>10:self.get_logger().warn('Candidate has no valid map position; waiting for mapping/localization.');self.lastwarn=time.monotonic()
    continue
   if self.records and sec<max(r['last_seen_sim_s'] for r in self.records)-1:
    self.records=[];self.pending=[];self.rejected=[];self.next_label=1;self.get_logger().warn('Simulation time moved backwards: cleared candidate registry to avoid mixing sessions.')
   now=self.get_clock().now().nanoseconds/1e9
   if not self.gate.allows(sec,now):
    self.pending=[]
    continue
   key=source_key(c)
   linked=[(0.,i,r) for i,r in enumerate(self.records) if key and key in r.get('camera_tracks',[]) and i not in used]
   options=[(math.hypot(p[0]-r['position'][0],p[1]-r['position'][1]),i,r) for i,r in enumerate(self.records) if i not in used]
   options=linked or [o for o in options if o[0]<self.radius]
   if options:
    _,idx,r=min(options,key=lambda o:o[0]);used.add(idx)
    if sec<=r['last_seen_sim_s']:continue
    update_position(r,p)
    if key and key not in r.setdefault('camera_tracks',[]):r['camera_tracks'].append(key)
    r['last_seen_sim_s']=sec;r['observations']+=1;r['historical_restored']=False
   else:
    matches=[r for r in self.pending if math.hypot(p[0]-r['position'][0],p[1]-r['position'][1])<.4 and 0<=sec-r['last_seen_sim_s']<3]
    r=min(matches,key=lambda r:math.hypot(p[0]-r['position'][0],p[1]-r['position'][1])) if matches else None
    if r is None:r={'position':list(map(float,p)),'last_seen_sim_s':sec,'observations':1};self.pending.append(r)
    elif sec>r['last_seen_sim_s']:r['observations']+=1;r['last_seen_sim_s']=sec;r['position']=[.5*(a+b) for a,b in zip(r['position'],p)]
    if key and key not in r.setdefault('camera_tracks',[]):r['camera_tracks'].append(key)
    if r['observations']>=3:
     r['label']='S'+str(self.next_label).zfill(2);self.next_label+=1;r['classification']='unconfirmed_survivor_candidate';self.records.append(r);self.pending.remove(r);used.add(len(self.records)-1)
     self.get_logger().info('Added '+r['label']+' at '+str(r['position']))
   self.pending=[r for r in self.pending if sec-r['last_seen_sim_s']<3]
  self.publish()
 def publish(self):
  array=MarkerArray();clear=Marker();clear.action=Marker.DELETEALL;array.markers.append(clear)
  for i,r in enumerate(self.records):
   for kind in ['point','label']:
    m=Marker();m.header.frame_id='map';m.header.stamp=self.get_clock().now().to_msg();m.ns='survivor_candidates_'+kind;m.id=i;m.action=Marker.ADD;m.pose.orientation.w=1.;m.pose.position.x=r['position'][0];m.pose.position.y=r['position'][1];m.pose.position.z=r['position'][2]+(.45 if kind=='label' else 0.)
    m.color.r=1.;m.color.g=.65;m.color.b=.05;m.color.a=1.
    if kind=='point':m.type=Marker.SPHERE;m.scale.x=m.scale.y=m.scale.z=.25
    else:m.type=Marker.TEXT_VIEW_FACING;m.scale.z=.22;m.pose.position.y+=.35;m.text=r['label']+' - UNCONFIRMED'+(' / POSITION UNSTABLE' if r.get('position_status')=='unstable_map_shift' else '')+(' (historical)' if r.get('historical_restored',False) else '')
    array.markers.append(m)
  self.pub.publish(array)
  msg=String();msg.data=json.dumps({'frame_id':'map','candidate_locations':len(self.records),'note':'Spatially grouped surface observations, not a verified count of survivors. Locations persist until this node restarts or simulation time resets.','candidates':self.records,'rejected_candidates':self.rejected,'position_update_policy':'stationary_pose_for_one_second_then_three_observations'});self.report.publish(msg)

def main():
 rclpy.init();n=Registry()
 try:rclpy.spin(n)
 except (KeyboardInterrupt,ExternalShutdownException):pass
 finally:
  n.destroy_node()
  if rclpy.ok():rclpy.shutdown()
if __name__=='__main__':main()
