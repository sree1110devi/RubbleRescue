"""Gate mapping observations on pose-derived stationary time."""
import math
class StationaryGate:
 def __init__(self,hold=1.,linear_limit=.02,angular_limit=.08):
  self.hold=hold;self.linear_limit=linear_limit;self.angular_limit=angular_limit;self.previous=None;self.since=None
 def update(self,stamp,x,y,yaw):
  if self.previous:
   t0,x0,y0,a0=self.previous;dt=stamp-t0
   if dt<=0 or dt>.5:self.since=None
   else:
    v=math.hypot(x-x0,y-y0)/dt;w=abs(math.atan2(math.sin(yaw-a0),math.cos(yaw-a0)))/dt
    if v>self.linear_limit or w>self.angular_limit:self.since=None
    elif self.since is None:self.since=t0
  self.previous=(stamp,x,y,yaw)
 def allows(self,image_stamp,now):
  return bool(self.previous and self.since is not None and -.1<=now-self.previous[0]<.6 and image_stamp>=self.since+self.hold and image_stamp<=now+.1)
