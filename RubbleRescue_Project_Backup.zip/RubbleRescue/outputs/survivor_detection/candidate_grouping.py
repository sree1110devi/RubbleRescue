"""Geometric filtering/grouping for simulation colour candidates; no human model."""
import math
import cv2
import numpy as np

def parts(mask,minimum):
 n,labels,stats,centers=cv2.connectedComponentsWithStats(mask)
 return [(i,stats[i],centers[i]) for i in range(1,n) if stats[i,4]>=minimum],labels

def plausible_head(mask,width,height,area):
 """Reject rectangular masonry patches; allow round/elliptical mannequin heads."""
 fill=area/max(width*height,1)
 if not .45<fill<.90:return False
 contours,_=cv2.findContours(mask.astype(np.uint8),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
 if not contours:return False
 c=max(contours,key=cv2.contourArea);a=cv2.contourArea(c);perimeter=cv2.arcLength(c,True)
 return perimeter>0 and 4*math.pi*a/(perimeter*perimeter)>.60

def proposals(image,depth,fx,fy,cx,cy):
 valid=np.isfinite(depth)&(depth>.15)&(depth<6.)
 hsv=cv2.cvtColor(image,cv2.COLOR_BGR2HSV)
 blue=cv2.inRange(hsv,(85,55,25),(130,255,255))
 orange=cv2.inRange(hsv,(5,105,40),(29,255,255))
 cloth=cv2.morphologyEx(blue|orange,cv2.MORPH_CLOSE,np.ones((3,3),np.uint8))
 skin=cv2.inRange(hsv,(3,65,45),(24,155,255))
 clothes,clabel=parts(cloth,30);heads,hlabel=parts(skin,30)
 accepted=[];height,width=depth.shape
 for hi,hs,hc in heads:
  hx,hy,hw,hh,ha=map(int,hs)
  if not(.55<hw/max(hh,1)<1.65 and hx>1 and hy>1 and hx+hw<width-1 and hy+hh<height-1):continue
  if not plausible_head(hlabel[hy:hy+hh,hx:hx+hw]==hi,hw,hh,ha):continue
  hm=(hlabel==hi)&valid
  if np.count_nonzero(hm)<20:continue
  hz=float(np.median(depth[hm]));q10,q90=np.percentile(depth[hm],[10,90])
  # Reject broad walls, tiny distant fragments and depth-discontinuous patches.
  if q90-q10>.35 or not(.18<hw*hz/fx<.40 and .18<hh*hz/fy<.44):continue
  related=[]
  for ci,cs,cc in clothes:
   x,y,w,h,area=map(int,cs)
   gap=math.hypot(max(hx-(x+w),x-(hx+hw),0),max(hy-(y+h),y-(hy+hh),0))
   if gap>max(8,1.8*max(hw,hh)):continue
   cm=(clabel==ci)&valid&(hlabel!=hi)
   if np.count_nonzero(cm)<20:continue
   cz=float(np.median(depth[cm]));c10,c90=np.percentile(depth[cm],[10,90])
   if abs(cz-hz)>.5 or c90-c10>.6:continue
   pw,ph=w*cz/fx,h*cz/fy
   if max(pw,ph)>1.4 or max(pw,ph)<.12 or area<ha*.15:continue
   related.append((ci,cs,cm))
  if not related:continue
  # Assign a single candidate per plausible head, including clothing fragments.
  union=np.zeros(depth.shape,bool);x0=hx;y0=hy;x1=hx+hw;y1=hy+hh
  for _,cs,cm in related:
   union|=cm;x,y,w,h,_=map(int,cs);x0=min(x0,x);y0=min(y0,y);x1=max(x1,x+w);y1=max(y1,y+h)
  ys,xs=np.nonzero(union);z=float(np.median(depth[union]));u=float(np.median(xs));v=float(np.median(ys))
  head=np.array([(hc[0]-cx)*hz/fx,(hc[1]-cy)*hz/fy,hz])
  accepted.append({'bbox':[x0,y0,x1,y1],'head':head,'head_uv':np.asarray(hc),'head_depth':hz,'u':u,'v':v,'z':z,'support':int(np.count_nonzero(union))})
 # Suppress split head patches or overlapping hypotheses of the same mannequin.
 result=[]
 for p in sorted(accepted,key=lambda p:p['support'],reverse=True):
  duplicate=False
  for old in result:
   a=p['bbox'];b=old['bbox'];inter=max(0,min(a[2],b[2])-max(a[0],b[0]))*max(0,min(a[3],b[3])-max(a[1],b[1]));small=min((a[2]-a[0])*(a[3]-a[1]),(b[2]-b[0])*(b[3]-b[1]))
   if np.linalg.norm(p['head']-old['head'])<.30 or (inter/max(small,1)>.65 and abs(p['z']-old['z'])<.4):duplicate=True;break
  if not duplicate:result.append(p)
 return result

class PersistentCandidates:
 """Require repeated observations; IDs are local tracks, not unique survivor IDs."""
 def __init__(self):self.tracks=[];self.frame=0;self.nextid=1
 def update(self,observations):
  self.frame+=1;used=set();visible=[]
  for p in observations:
   options=[(np.linalg.norm(t['head']-p['head']),i,t) for i,t in enumerate(self.tracks) if i not in used and self.frame-t['frame']<=2]
   options=[o for o in options if o[0]<.65]
   if options:
    _,idx,t=min(options,key=lambda o:o[0]);used.add(idx);t['hits']=t['hits']+1 if t['frame']==self.frame-1 else 1
   else:
    t={'id':self.nextid,'hits':1};self.nextid+=1;self.tracks.append(t);used.add(len(self.tracks)-1)
   t['head']=p['head'];t['frame']=self.frame;p['track_id']=t['id'];p['observations']=t['hits']
   if t['hits']>=3:visible.append(p)
  self.tracks=[t for t in self.tracks if self.frame-t['frame']<=3]
  return visible
