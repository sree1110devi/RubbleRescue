#!/usr/bin/env python3
"""Simulation-only colour-associated mannequin candidates, not a human classifier."""
import json,math,time
import cv2,numpy as np,rclpy,message_filters,tf2_ros
from rclpy.node import Node
from rclpy.parameter import Parameter
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import Image,CameraInfo
from std_msgs.msg import String
from visualization_msgs.msg import Marker,MarkerArray
from geometry_msgs.msg import PointStamped
from cv_bridge import CvBridge
import tf2_geometry_msgs

class Detector(Node):
 def __init__(self):
  super().__init__('survivor_candidate_detector',parameter_overrides=[Parameter('use_sim_time',value=True)])
  self.cv=CvBridge();self.tf=tf2_ros.Buffer();self.listener=tf2_ros.TransformListener(self.tf,self)
  self.image_pub=self.create_publisher(Image,'/survivor_candidates/image',2)
  self.depth_pub=self.create_publisher(Image,'/rescue_camera/depth_preview',2)
  self.marker_pub=self.create_publisher(MarkerArray,'/survivor_candidates/markers',2)
  self.report_pub=self.create_publisher(String,'/survivor_candidates/report',10)
  self.subs=[message_filters.Subscriber(self,kind,topic,qos_profile=qos_profile_sensor_data) for kind,topic in [(Image,'/rescue_camera/image'),(Image,'/rescue_camera/depth_image'),(CameraInfo,'/rescue_camera/camera_info')]]
  self.sync=message_filters.ApproximateTimeSynchronizer(self.subs,queue_size=8,slop=.12);self.sync.registerCallback(self.process)
  self.last=0;self.last_log=0
  self.get_logger().info('Simulation mannequin candidate detector: blue/ochre clothing + nearby skin colour + valid depth. No pretrained human classifier and no ground-truth positions are used.')
 def components(self,mask,minarea):
  num,labels,stats,centers=cv2.connectedComponentsWithStats(mask)
  return [(i,stats[i],centers[i]) for i in range(1,num) if stats[i,cv2.CC_STAT_AREA]>=minarea],labels
 def process(self,rgb_msg,depth_msg,info):
  now=time.monotonic()
  if now-self.last<.3:return
  self.last=now
  try:
   image=self.cv.imgmsg_to_cv2(rgb_msg,'bgr8');depth=self.cv.imgmsg_to_cv2(depth_msg,'passthrough')
   if depth_msg.encoding=='16UC1':depth=depth.astype(np.float32)*.001
   if depth.shape!=image.shape[:2]:return
   valid=np.isfinite(depth)&(depth>.1)&(depth<8.)
   preview=np.zeros(depth.shape,np.uint8);preview[valid]=(255*(1-np.clip(depth[valid]/8.,0,1))).astype(np.uint8)
   preview=cv2.applyColorMap(preview,cv2.COLORMAP_TURBO);preview[~valid]=0
   dm=self.cv.cv2_to_imgmsg(preview,'bgr8');dm.header=depth_msg.header;self.depth_pub.publish(dm)
   hsv=cv2.cvtColor(image,cv2.COLOR_BGR2HSV)
   blue=cv2.inRange(hsv,(85,55,25),(130,255,255));ochre=cv2.inRange(hsv,(5,105,40),(29,255,255))
   cloth=cv2.morphologyEx(blue|ochre,cv2.MORPH_CLOSE,np.ones((5,5),np.uint8))
   skin=cv2.inRange(hsv,(3,65,45),(24,200,255))
   clothparts,labels=self.components(cloth,45);skinparts,skinlabels=self.components(skin,30)
   annotated=image.copy();markers=MarkerArray();clear=Marker();clear.action=Marker.DELETEALL;markers.markers.append(clear)
   candidates=[];fx,fy,cx,cy=info.k[0],info.k[4],info.k[2],info.k[5]
   if fx<=0 or fy<=0:return
   for part,st,center in clothparts:
    x,y,w,h,area=map(int,st)
    if area>image.shape[0]*image.shape[1]*.45:continue
    nearby=[]
    for si,ss,sc in skinparts:
     sx,sy,sw,sh,sa=map(int,ss)
     dx=max(x-(sx+sw),sx-(x+w),0);dy=max(y-(sy+sh),sy-(y+h),0)
     if math.hypot(dx,dy)<max(20,.85*max(w,h)) and .5<sw/max(sh,1)<1.8 and sa<area*1.5 and sx>1 and sy>1 and sx+sw<image.shape[1]-1:nearby.append((si,ss,sc))
    if not nearby:continue
    mask=(labels==part)&valid
    if np.count_nonzero(mask)<20:continue
    ys,xs=np.nonzero(mask);z=float(np.median(depth[mask]));u=float(np.median(xs));v=float(np.median(ys))
    # Report the visible clothing surface, not a presumed whole-body centre.
    chosen=min(nearby,key=lambda p:np.linalg.norm(p[2]-center));sx,sy,sw,sh,_=map(int,chosen[1])
    x0=min(x,sx);y0=min(y,sy);x1=max(x+w,sx+sw);y1=max(y+h,sy+sh)
    optical=PointStamped();optical.header=depth_msg.header;optical.point.x=(u-cx)*z/fx;optical.point.y=(v-cy)*z/fy;optical.point.z=z
    base=None;map_point=None
    for frame in ['base_link','map']:
     try:
      p=self.tf.transform(optical,frame,timeout=rclpy.duration.Duration(seconds=.01))
      if frame=='base_link':base=p
      else:map_point=p
     except Exception:pass
    if base is not None:
     mid=len(candidates);m=Marker();m.header=base.header;m.ns='simulation_candidates';m.id=mid;m.type=Marker.SPHERE;m.action=Marker.ADD;m.pose.position=base.point;m.pose.orientation.w=1.;m.scale.x=m.scale.y=m.scale.z=.18;m.color.r=1.;m.color.g=.55;m.color.a=1.;m.lifetime.sec=1;markers.markers.append(m)
    report={'candidate_id':len(candidates)+1,'method':'simulation_colour_and_depth','classification':'unconfirmed_mannequin_candidate','stamp':{'sec':rgb_msg.header.stamp.sec,'nanosec':rgb_msg.header.stamp.nanosec},'depth_m':round(z,3),'bbox_pixels':[x0,y0,x1,y1],'optical_frame':optical.header.frame_id,'optical_surface_xyz_m':[round(optical.point.x,3),round(optical.point.y,3),round(z,3)]}
    if base:report['base_link_surface_xyz_m']=[round(base.point.x,3),round(base.point.y,3),round(base.point.z,3)]
    if map_point:report['map_surface_xyz_m']=[round(map_point.point.x,3),round(map_point.point.y,3),round(map_point.point.z,3)]
    else:report['map_position_status']='unavailable: active map transform required'
    candidates.append(report);cv2.rectangle(annotated,(x0,y0),(x1,y1),(0,220,255),2);cv2.putText(annotated,f'Candidate {len(candidates)} | depth {z:.2f} m',(x0,max(32,y0-8)),cv2.FONT_HERSHEY_SIMPLEX,.5,(0,220,255),1,cv2.LINE_AA)
   cv2.putText(annotated,'SIMULATION CANDIDATES - VERIFY PERSON',(8,20),cv2.FONT_HERSHEY_SIMPLEX,.46,(0,220,255),1,cv2.LINE_AA)
   out=self.cv.cv2_to_imgmsg(annotated,'bgr8');out.header=rgb_msg.header;self.image_pub.publish(out);self.marker_pub.publish(markers)
   msg=String();msg.data=json.dumps({'candidate_count':len(candidates),'candidates':candidates});self.report_pub.publish(msg)
   if now-self.last_log>5:
    self.get_logger().info('Camera processed; candidate count: '+str(len(candidates))+(' | '+json.dumps(candidates[0]) if candidates else ''));self.last_log=now
  except Exception as e:self.get_logger().error(str(e))

def main():
 rclpy.init();n=Detector()
 try:rclpy.spin(n)
 except KeyboardInterrupt:pass
 finally:n.destroy_node();rclpy.shutdown()
if __name__=='__main__':main()
