# RubbleRescue — Searchable collapsed house V2

Open RubbleRescue_Searchable_House_V2.blend. Numpad 0 shows the overview. All meshes are editable; metres are used throughout. The original V1 is preserved separately.

## Layout

16 × 14 m house with four rooms, a central hall, windows, front and rear openings, broken wall tops, localized roof collapse and scattered masonry. Front is negative Y. Interior walls at x=±1.5 m have a 2.78 m clear central corridor. Room entrances at y=±3.5 m are 2.4 m wide. Room-to-room openings at x=±4.5 m are also 2.4 m wide. Passage clearance must still be tested against the full robot footprint and arm pose.

Debris generation excludes a nominal 1.8 m wide network of routes, including the central hall and room approaches. This is not a validated Nav2 route. Small chips and rebar are visual only. Static box collisions approximate walls, larger rubble, slabs and mannequins. The lower front wall is a damaged/cutaway facade for interior visibility. No live collapse physics is included.

## Survivors

Three non-graphic clothed adult-sized mannequins are included as visual search targets:

- Survivor_01: front-left room, lying, x=-6 y=-4.8.
- Survivor_02: rear-left room, seated, x=-6 y=4.7.
- Survivor_03: rear-right room beneath damaged roof, lying, x=6 y=4.9.

Ground truth is provided separately in survivor_ground_truth.csv for evaluation. Do not feed these positions into the robot's search algorithm if demonstrating autonomous discovery. Mannequins are static and do not simulate body heat, breathing, sound, medical condition or automatic person detections. A generic real-image person detector may not reliably detect these simplified models; test it or use a suitable simulation-trained detector. Robot detection should use camera/depth observations and report an estimated map position; evaluation can then compare against ground truth. No detector, Nav2 configuration, or ROS bridge is installed by this asset package.

## Gazebo integration

Keep all files together in the rubblerescue_house_v2 folder. In the launch terminal:

```bash
export GZ_SIM_RESOURCE_PATH="/home/sreedevi-k/Documents/Codex/2026-11-18/th/outputs:${GZ_SIM_RESOURCE_PATH}"
```

Add inside your existing SDF <world>:

```xml
<include>
  <uri>model://rubblerescue_house_v2</uri>
  <name>rescue_house</name>
  <pose>0 0 0 0 0 0</pose>
</include>
```

Remove the V1 building include and overlapping old obstacles. Foundation top is z=0; suggested spawn is x=0, y=-8, with robot facing +Y (yaw=1.5708). Choose spawn Z based on your robot's link origin. Test doorway contacts, camera views and under-roof inspection before autonomous navigation. Blender render and file integrity are checked; Gazebo runtime, LiDAR/camera behavior and full robot traversal are not verified.

OBJ retains the concrete colour texture but does not carry Blender procedural bump or presentation lighting. Survivors are included in the combined environment mesh, not separate semantic Gazebo entities. For an entity-ID-based detector, separate survivor models and labeling configuration are needed.
