import bpy, math, random, bmesh, json
from mathutils import Vector
from pathlib import Path
import numpy as np
random.seed(28)
OUT=Path(__file__).resolve().parent; OUT.mkdir(exist_ok=True)
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
scene=bpy.context.scene
bpy.context.preferences.filepaths.save_version=0
visual=bpy.data.collections.new('BUILDING_VISUAL'); scene.collection.children.link(visual)
coll=bpy.data.collections.new('COLLISION_PROXIES'); scene.collection.children.link(coll); coll.hide_render=True

def move(o,c):
 for old in list(o.users_collection): old.objects.unlink(o)
 c.objects.link(o)

def mat(name,color,rough=.85):
 m=bpy.data.materials.new(name); m.diffuse_color=(*color,1); m.use_nodes=True
 bs=m.node_tree.nodes.get('Principled BSDF'); bs.inputs['Base Color'].default_value=(*color,1); bs.inputs['Roughness'].default_value=rough
 return m
concrete=mat('Weathered concrete',(.40,.385,.34)); brick=mat('Broken terracotta',(.36,.16,.09)); steel=mat('Oxidized reinforcement',(.20,.095,.045)); plaster=mat('Aged plaster',(.66,.63,.52)); dust=mat('Concrete dust',(.39,.35,.28)); dark=mat('Dark asphalt',(.12,.125,.12))
# Portable image texture, shared by Blender and OBJ export.
rng=np.random.default_rng(35); n=512
noise=rng.random((n,n)); coarse=np.repeat(np.repeat(rng.random((32,32)),16,0),16,1)
value=.68+.25*noise+.14*coarse
pixels=np.ones((n,n,4),dtype=np.float32); pixels[:,:,:3]=value[:,:,None]*np.array([.51,.49,.44])
img=bpy.data.images.new('concrete_albedo',width=n,height=n); img.pixels.foreach_set(pixels.ravel()); img.filepath_raw=str(OUT/'concrete_albedo.png'); img.file_format='PNG'; img.save()
nodes=concrete.node_tree.nodes; bs=nodes.get('Principled BSDF'); tex=nodes.new('ShaderNodeTexImage'); tex.image=img; concrete.node_tree.links.new(tex.outputs['Color'],bs.inputs['Base Color'])
noise_node=nodes.new('ShaderNodeTexNoise'); noise_node.inputs['Scale'].default_value=95; bump=nodes.new('ShaderNodeBump'); bump.inputs['Strength'].default_value=.25; bump.inputs['Distance'].default_value=.035
concrete.node_tree.links.new(noise_node.outputs['Fac'],bump.inputs['Height']); concrete.node_tree.links.new(bump.outputs['Normal'],bs.inputs['Normal'])
proxies=[]
def proxy(name,loc,dim,rot=(0,0,0)):
 proxies.append(dict(name=name,loc=list(loc),dim=list(dim),rot=list(rot)))

def box(name,loc,dim,material=concrete,rot=(0,0,0),collision=True,bevel=.025):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc); o=bpy.context.object; o.name=name; o.dimensions=dim; bpy.ops.object.transform_apply(location=False,rotation=False,scale=True); o.rotation_euler=rot; o.data.materials.append(material); move(o,visual)
 if bevel:
  mod=o.modifiers.new('Chipped edge highlights','BEVEL'); mod.width=bevel; mod.segments=2
 if collision: proxy(name,loc,dim,rot)
 return o

def rock(name,loc,size,material=concrete):
 # Asymmetric convex fragments, rather than scaled spheres.
 verts=[]
 for z in [-.5,.5]:
  for x,y in [(-.5,-.5),(.5,-.5),(.5,.5),(-.5,.5)]: verts.append(((x+random.uniform(-.22,.22))*size[0],(y+random.uniform(-.22,.22))*size[1],(z+random.uniform(-.15,.15))*size[2]))
 me=bpy.data.meshes.new(name); me.from_pydata(verts,[],[]); bm=bmesh.new(); bm.from_mesh(me); bmesh.ops.convex_hull(bm,input=list(bm.verts)); bm.to_mesh(me); bm.free(); me.update()
 o=bpy.data.objects.new(name,me); visual.objects.link(o); o.location=loc; o.rotation_euler=[random.uniform(-.3,.3),random.uniform(-.3,.3),random.uniform(0,6.28)]; o.data.materials.append(material)
 if max(size)>.45: proxy(name,loc,[s*.8 for s in size],o.rotation_euler)
 return o

def rod(name,a,b,r=.014,material=steel):
 d=Vector(b)-Vector(a); bpy.ops.mesh.primitive_cylinder_add(vertices=8,radius=r,depth=d.length,location=(Vector(a)+Vector(b))/2); o=bpy.context.object; o.name=name; o.rotation_euler=d.to_track_quat('Z','Y').to_euler(); o.data.materials.append(material); move(o,visual); return o


box('House foundation',(0,0,-.15),(16.5,14.5,.3),concrete)
floor=mat('Dusty floor tiles',(.43,.41,.36))
box('Interior floor',(0,0,-.018),(16,14,.035),floor,collision=False,bevel=0)
# Faint tile joints remain visible beneath dust.
for x in range(-7,8): box('Floor joint',(x,0,.001),(.009,14,.002),dust,collision=False,bevel=0)
for y in range(-6,7): box('Floor joint',(0,y,.002),(16,.009,.002),dust,collision=False,bevel=0)
# Irregular broken wall tops, with continuous lower wall geometry.
def wall(name,x1,y1,x2,y2,height=2.1,material=plaster):
 length=math.hypot(x2-x1,y2-y1); angle=math.atan2(y2-y1,x2-x1); count=max(3,int(length/.5)); thick=.22
 top=[height+random.uniform(-.22,.16) for _ in range(count+1)]
 verts=[]
 profile=[(-length/2,0),(length/2,0)]+[(length/2-i*length/count,top[count-i]) for i in range(count+1)]
 for y in [-thick/2,thick/2]: verts.extend([(x,y,z) for x,z in profile])
 n=len(profile); faces=[tuple(reversed(range(n))),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
 me=bpy.data.meshes.new(name); me.from_pydata(verts,[],faces); me.update(); o=bpy.data.objects.new(name,me); visual.objects.link(o); o.location=((x1+x2)/2,(y1+y2)/2,0); o.rotation_euler.z=angle; o.data.materials.append(material)
 proxy(name,((x1+x2)/2,(y1+y2)/2,(height-.22)/2),(length,thick,height-.22),(0,0,angle))
 return o
# Front is damaged low masonry: room interiors visible in overview.
wall('Front left damaged facade',-8,-7,-1.4,-7,1.0)
wall('Front right damaged facade',1.4,-7,8,-7,1.0)
wall('Rear left wall',-8,7,-1.5,7,2.2)
wall('Rear right wall',1.5,7,8,7,2.3)
# Side windows are real openings, not painted rectangles.
for x in [-8,8]:
 for a,b in [(-7,-5),(-2,2),(5,7)]: wall('Side wall remnant',x,a,x,b,2.0)
 for y in [-3.5,3.5]:
  box('Window sill',(x,y,.45),(.22,3,.9),plaster)
  box('Window lintel',(x,y,2.05),(.28,3,.18),concrete)
# 2.8-m-wide central hallway, doors into four rooms.
for x in [-1.5,1.5]:
 for a,b in [(-7,-4.7),(-2.3,2.3),(4.7,7)]: wall('Hall partition',x,a,x,b,1.9,brick)
 for y in [-3.5,3.5]: box('Interior door lintel',(x,y,2.10),(.25,2.4,.23),concrete)
for side in [-1,1]:
 # Split front and rear room, with 2.4-m connecting doorway.
 a,b=sorted([side*8,side*5.7]); wall('Room division outer',a,0,b,0,1.8)
 a,b=sorted([side*3.3,side*1.5]); wall('Room division inner',a,0,b,0,1.8)
 box('Room connecting lintel',(side*4.5,0,2.05),(2.4,.25,.2),concrete)
# Localized collapse in rear-right room; corridor and door mouths stay clear.
for x,y,h in [(6.6,5.8,1.6),(-6.8,5.9,1.25),(-6.5,-5.5,.7)]:
 box('Broken column',(x,y,h/2),(.35,.35,h))
 for dx in [-.10,.10]: rod('Exposed column steel',(x+dx,y,h-.12),(x+dx+.1,y-.1,h+.45),.012)
box('Collapsed roof section',(6.0,5.5,1.18),(3.2,2.2,.22),concrete,rot=(.18,-.28,.12))
box('Fallen roof slab',(-6,5.8,.25),(2.7,1.8,.22),concrete,rot=(.08,.1,-.2))
for i in range(11):
 x=4.6+i*.27; z=1.18+.28*(x-6)
 rock('Jagged roof edge',(x,4.4,z),(.34,.30,.25)); rod('Roof exposed mesh',(x,4.5,z),(x+.06,4.0,z-.12),.011)
# Reserved driving network (metres): central hall, cross passages, room spines.
segments=[((0,-9),(0,7)),((-6,-3.5),(6,-3.5)),((-6,3.5),(6,3.5)),((-4.5,-5.5),(-4.5,5.5)),((4.5,-5.5),(4.5,5.5))]
def distance_segment(x,y,a,b):
 dx=b[0]-a[0];dy=b[1]-a[1];t=max(0,min(1,((x-a[0])*dx+(y-a[1])*dy)/(dx*dx+dy*dy)))
 return math.hypot(x-a[0]-t*dx,y-a[1]-t*dy)
def route_distance(x,y):return min(distance_segment(x,y,*s) for s in segments)
for i in range(290):
 x=random.uniform(-7.6,7.6); y=random.uniform(-6.6,6.6); s=random.uniform(.10,.52)
 if route_distance(x,y)<1.0+s*.8: continue
 # Keep survivor inspection spots clear.
 if any(math.hypot(x-a,y-b)<1.1 for a,b in [(-6,-4.8),(-6,4.7),(6,4.9)]):continue
 rock('Clustered masonry',(x,y,s*.23), (s*1.5,s,s*.6),brick if random.random()<.25 else concrete)
for i in range(150):
 x=random.uniform(-7.8,7.8); y=random.uniform(-6.8,6.8)
 if route_distance(x,y)<.9:continue
 s=random.uniform(.025,.08);rock('Fine debris',(x,y,.025),(s,s*1.4,s*.45),dust)
# Simple clothed adult-sized rescue mannequins: non-graphic search targets.
skin=mat('Mannequin skin',(.52,.30,.18)); blue=mat('Survivor blue clothing',(.065,.18,.30)); orange=mat('Survivor ochre clothing',(.62,.27,.07)); trousers=mat('Survivor dark trousers',(.07,.085,.10)); shoes=mat('Shoes',(.035,.035,.035))
def sphere(name,loc,scale,material):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=16,ring_count=8,radius=1,location=loc);o=bpy.context.object;o.name=name;o.scale=scale;o.data.materials.append(material);move(o,visual)
 for p in o.data.polygons:p.use_smooth=True
 return o
def person(name,x,y,shirt,seated=False):
 if not seated:
  sphere(name+' torso',(x,y,.24),(.24,.36,.17),shirt)
  sphere(name+' head',(x,y+.55,.25),(.145,.18,.15),skin)
  for sign in [-1,1]:
   rod(name+' trouser leg',(x+sign*.12,y-.28,.20),(x+sign*.17,y-.91,.15),.10,trousers)
   sphere(name+' shoe',(x+sign*.17,y-.99,.14),(.105,.18,.09),shoes)
   rod(name+' sleeve',(x+sign*.22,y+.2,.26),(x+sign*.36,y-.11,.18),.075,shirt)
   rod(name+' forearm',(x+sign*.36,y-.11,.18),(x+sign*.32,y-.39,.16),.055,skin)
  proxy(name+' body',(x,y-.15,.25),(.8,1.85,.5))
 else:
  sphere(name+' torso',(x,y,.68),(.24,.17,.34),shirt);sphere(name+' head',(x,y,.68+.49),(.145,.15,.18),skin)
  for sign in [-1,1]:
   rod(name+' thigh',(x+sign*.12,y,.4),(x+sign*.19,y-.42,.25),.1,trousers)
   rod(name+' shin',(x+sign*.19,y-.42,.25),(x+sign*.2,y-.85,.13),.085,trousers)
   sphere(name+' shoe',(x+sign*.2,y-.94,.10),(.10,.16,.09),shoes)
   rod(name+' arm',(x+sign*.24,y,.85),(x+sign*.28,y-.25,.45),.065,shirt)
  proxy(name+' body',(x,y-.3,.62),(.8,1.3,1.25))
person('Survivor_01',-6,-4.8,blue)
person('Survivor_02',-6,4.7,orange,seated=True)
person('Survivor_03',6,4.9,blue)
(OUT/'survivor_ground_truth.csv').write_text('id,x_m,y_m,posture,location\nSurvivor_01,-6,-4.8,lying,front left room\nSurvivor_02,-6,4.7,seated,rear left room\nSurvivor_03,6,4.9,lying,rear right roof void\n')
(OUT/'route_waypoints.json').write_text(json.dumps({'units':'metres','nominal_clear_route_width':1.8,'waypoints':[[0,-8],[0,-3.5],[-4.5,-3.5],[-4.5,3.5],[0,3.5],[4.5,3.5],[4.5,-3.5]],'note':'Geometric planning reference; not a validated Nav2 path.'},indent=2))
# Planar UVs for portable concrete texture.
for o in visual.objects:
 if o.type!='MESH': continue
 uv=o.data.uv_layers.new(name='UVMap') if not o.data.uv_layers else o.data.uv_layers.active
 for poly in o.data.polygons:
  normal=poly.normal; axis=max(range(3),key=lambda k:abs(normal[k])); axes=[k for k in range(3) if k!=axis]
  for li in poly.loop_indices:
   co=o.data.vertices[o.data.loops[li].vertex_index].co; uv.data[li].uv=(co[axes[0]],co[axes[1]])
# Export visual geometry only.
bpy.ops.object.select_all(action='DESELECT')
for o in visual.objects:o.select_set(True)
bpy.ops.wm.obj_export(filepath=str(OUT/'collapsed_building.obj'),export_selected_objects=True,forward_axis='Y',up_axis='Z',apply_modifiers=True,export_materials=True,path_mode='COPY')
# Gazebo-compatible diffuse fallback for image-textured concrete.
mtl_path=OUT/'collapsed_building.mtl'
mtl_text=mtl_path.read_text()
mtl_text=mtl_text.replace('newmtl Weathered_concrete\n','newmtl Weathered_concrete\nKd 0.65 0.63 0.58\n')
mtl_path.write_text(mtl_text)
# Static primitive collisions preserve door and under-slab void.
from xml.sax.saxutils import escape
parts=['<?xml version="1.0"?><sdf version="1.9"><model name="rubblerescue_house_v2"><static>true</static><link name="structure"><visual name="building"><geometry><mesh><uri>model://rubblerescue_house_v2/collapsed_building.obj</uri></mesh></geometry></visual>']
for i,p in enumerate(proxies):
 pose=' '.join(str(v) for v in p['loc']+p['rot']); dim=' '.join(str(v) for v in p['dim'])
 parts.append(f'<collision name="collision_{i}"><pose>{pose}</pose><geometry><box><size>{dim}</size></box></geometry></collision>')
parts.append('</link></model></sdf>'); (OUT/'model.sdf').write_text('\n'.join(parts))
(OUT/'model.config').write_text('<?xml version="1.0"?><model><name>RubbleRescue searchable house V2</name><version>1.0</version><sdf version="1.9">model.sdf</sdf><description>Static rescue test environment, metres.</description></model>')
# Visible, toggleable collision proxies in the editable blend.
for p in proxies:
 bpy.ops.mesh.primitive_cube_add(size=1,location=p['loc']); o=bpy.context.object; o.name='COL_'+p['name']; o.dimensions=p['dim']; o.rotation_euler=p['rot']; move(o,coll); o.display_type='WIRE'; o.hide_render=True
coll.hide_viewport=True
# Presentation ground and studio daylight, excluded from OBJ.
box_ground=None
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.34)); bpy.context.object.name='Presentation ground'; bpy.context.object.data.materials.append(mat('Ground',(.22,.235,.23)))
world=bpy.data.worlds.new('Overcast daylight'); scene.world=world; world.use_nodes=True; world.node_tree.nodes['Background'].inputs[0].default_value=(.65,.73,.85,1); world.node_tree.nodes['Background'].inputs[1].default_value=.45
bpy.ops.object.light_add(type='AREA',location=(-3,-5,10)); bpy.context.object.data.energy=1800; bpy.context.object.data.shape='DISK'; bpy.context.object.data.size=8
bpy.ops.object.light_add(type='SUN',location=(0,0,8)); bpy.context.object.rotation_euler=(.5,-.4,-.6); bpy.context.object.data.energy=1.5; bpy.context.object.data.angle=.18
bpy.ops.object.camera_add(location=(20,-26,25)); camera=bpy.context.object; camera.rotation_euler=(Vector((0,.3,.7))-camera.location).to_track_quat('-Z','Y').to_euler(); camera.data.type='ORTHO'; camera.data.ortho_scale=25; scene.camera=camera
scene.unit_settings.system='METRIC'; scene.unit_settings.scale_length=1
scene.render.engine='CYCLES'; scene.cycles.samples=24; scene.cycles.use_denoising=True
scene.render.resolution_x=1440; scene.render.resolution_y=1080; scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG'; scene.render.filepath=str(OUT/'building_preview.png')
# Pack texture for self-contained blend.
img.pack()
bpy.ops.render.render(write_still=True)
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'RubbleRescue_Searchable_House_V2.blend'))
print('BUILDING_COMPLETE',len(visual.objects),'visual objects;',len(proxies),'collision boxes')

import os; os._exit(0)
