Rubble traversal terrain

28 physical rubble pieces: four broad corridor ridges and 24 scattered slabs in the four rooms. Heights 12–22 mm, with sloped edges; visual and collision meshes are identical closed STL solids. The current 73 mm radius wheels and low chassis require small obstacles. Existing large rubble remains an avoidance obstacle.

The normal project launcher rebuilds this terrain automatically. Restart the project to load changes. Navigation height thresholds remain unchanged; these low pieces are beneath them. This is a controlled low-rubble demonstration, not general rough-terrain planning.

check_crossing.py runs an isolated Gazebo physics test at 0.15 m/s over the 18 mm corridor ridge, using the actual robot collision model and a separate Gazebo partition. It does not control the running project. Results: crossing_result.json.
