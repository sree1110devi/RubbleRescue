"""Add shallow, physically collidable rubble without changing the house model."""
from pathlib import Path
import math
import random
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent


def mesh(path, length, width, height):
    # Closed convex slab with a flat crest and a gentle ramp on every side.
    inset = min(length, width) * .28
    vertices = [(-length/2,-width/2,-.003),(length/2,-width/2,-.003),
                (length/2,width/2,-.003),(-length/2,width/2,-.003),
                (-length/2+inset,-width/2+inset,height),
                (length/2-inset,-width/2+inset,height),
                (length/2-inset,width/2-inset,height),
                (-length/2+inset,width/2-inset,height)]
    faces = [(4,3,2,1),(5,6,7,8),(1,2,6,5),(2,3,7,6),
             (3,4,8,7),(4,1,5,8)]
    lines = ['solid rubble']
    for a,b,c,d in faces:
        for tri in ((a,b,c),(a,c,d)):
            pts=[vertices[j-1] for j in tri]
            u=[pts[1][j]-pts[0][j] for j in range(3)]
            v=[pts[2][j]-pts[0][j] for j in range(3)]
            n=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]]
            norm=math.sqrt(sum(q*q for q in n))
            lines += ['facet normal '+' '.join(str(q/norm) for q in n),'outer loop']
            lines += ['vertex '+' '.join(map(str,p)) for p in pts]
            lines += ['endloop','endfacet']
    lines += ['endsolid rubble']
    path.write_text('\n'.join(lines)+'\n')


def add_terrain(source, destination):
    tree = ET.parse(source)
    world = tree.getroot().find('world')
    for old in list(world.findall('model')):
        if old.get('name','').startswith('traversable_rubble_'):
            world.remove(old)
    rng = random.Random(27)
    # Broad low ridges across the corridor ensure straight driving crosses rubble.
    pieces = [(0,y,0, .65,2.65,.018) for y in (-5.4,-2.0,2.0,5.4)]
    # Scatter through all four rooms. Keep doorways and mannequin sites clear.
    for cx in (-4.6,4.6):
        for cy in (-3.5,3.5):
            for dx in (-1.5,0,1.5):
                for dy in (-1.0,.8):
                    pieces.append((cx+dx,cy+dy,rng.uniform(-math.pi,math.pi),
                                   rng.uniform(.65,.9),rng.uniform(.5,.7),
                                   rng.uniform(.012,.022)))
    for i,(x,y,yaw,length,width,height) in enumerate(pieces):
        path = ROOT/f'rubble_{i:02}.stl'
        mesh(path,length,width,height)
        model = ET.SubElement(world,'model',name=f'traversable_rubble_{i:02}')
        ET.SubElement(model,'static').text='true'
        ET.SubElement(model,'pose').text=f'{x} {y} 0 0 0 {yaw}'
        link = ET.SubElement(model,'link',name='rubble')
        for tag in ('collision','visual'):
            item = ET.SubElement(link,tag,name=tag)
            geo = ET.SubElement(item,'geometry')
            ET.SubElement(ET.SubElement(geo,'mesh'),'uri').text=path.as_uri()
            if tag=='collision':
                ode=ET.SubElement(ET.SubElement(ET.SubElement(item,'surface'),'friction'),'ode')
                ET.SubElement(ode,'mu').text='1.0'
                ET.SubElement(ode,'mu2').text='1.0'
            else:
                material=ET.SubElement(item,'material')
                shade=rng.uniform(.32,.48)
                colour=f'{shade} {shade*.94} {shade*.84} 1'
                ET.SubElement(material,'ambient').text=colour
                ET.SubElement(material,'diffuse').text=colour
    ET.indent(tree,space='  ')
    tree.write(destination,encoding='unicode',xml_declaration=True)
    return len(pieces)


if __name__=='__main__':
    import sys
    print('Added',add_terrain(sys.argv[1],sys.argv[2]),'collidable rubble pieces')
