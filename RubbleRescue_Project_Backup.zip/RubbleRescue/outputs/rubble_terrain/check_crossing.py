from pathlib import Path
import xml.etree.ElementTree as E
import subprocess as S,os,time,json,signal,math
P=Path(__file__).resolve().parent
w=E.parse(P.parent/'final_project/world.sdf');world=w.getroot().find('world');world.set('name','crossing_check')
for v in list(world):
    if v.tag=='include' or (v.tag=='plugin' and 'sensors' in v.get('filename','')) or (v.tag=='model' and v.get('name','').startswith('traversable_rubble_')):world.remove(v)
# Same corridor ridge, rotated across forward direction.
m=E.parse(P.parent/'final_project/world.sdf').getroot().find("world/model[@name='traversable_rubble_00']")
m.find('pose').text='1.2 0 0 0 0 0';world.append(m)
r=E.parse(P/'test_robot.sdf').getroot().find('model');r.set('name','rubblerescue');E.SubElement(r,'pose').text='0 0 .05 0 0 0'
for link in r.findall('link'):
    for sensor in link.findall('sensor'):link.remove(sensor)
for uri in r.findall('.//uri'):
    uri.text=uri.text.replace('model://robocar_description/',Path('/home/sreedevi-k/rubblerescue_ws/src/robocar_description').as_uri()+'/')
world.append(r);w.write(P/'crossing_check.sdf')
env=os.environ.copy();env['GZ_PARTITION']='rubble_crossing_check_'+str(os.getpid())
log=open(P/'crossing_check.log','w');poses=open(P/'crossing_poses.jsonl','w');children=[]
try:
    server=S.Popen(['gz','sim','-r','-s',str(P/'crossing_check.sdf')],env=env,stdout=log,stderr=log,start_new_session=True);children.append(server)
    monitor=S.Popen(['gz','topic','-e','--json-output','-t','/world/crossing_check/pose/info'],env=env,stdout=poses,stderr=log,start_new_session=True);children.append(monitor)
    time.sleep(4)
    for i in range(24):
        S.run(['gz','topic','-t','/cmd_vel','-m','gz.msgs.Twist','-p','linear: {x: 0.15}'],env=env,stdout=S.DEVNULL,stderr=log,timeout=3)
        time.sleep(.18)
    S.run(['gz','topic','-t','/cmd_vel','-m','gz.msgs.Twist','-p','linear: {x: 0}'],env=env,stdout=S.DEVNULL,timeout=3)
    time.sleep(1)
finally:
    for c in children:
        try:os.killpg(c.pid,signal.SIGTERM)
        except ProcessLookupError:pass
    for c in children:
        try:c.wait(timeout=5)
        except S.TimeoutExpired:os.killpg(c.pid,signal.SIGKILL)
    poses.close();log.close()
observations=[]
for line in (P/'crossing_poses.jsonl').read_text().splitlines():
    try:
        msg=json.loads(line)
        observations += [p for p in msg.get('pose',[]) if p.get('name')=='rubblerescue']
    except ValueError:pass
if observations:
    positions=[p.get('position',{}) for p in observations]
    result={'samples':len(positions),'max_x':max(p.get('x',0) for p in positions),'min_z':min(p.get('z',0) for p in positions),'max_z':max(p.get('z',0) for p in positions),'last_position':positions[-1]}
    crest=[p.get('z',0) for p in positions if 1.05<p.get('x',0)<1.35]
    result['ridge_chassis_rise_m']=max(crest,default=0)
    result['crossed']=result['max_x']>1.85 and result['ridge_chassis_rise_m']>.01
else:result={'crossed':False,'error':'No pose samples'}
(P/'crossing_result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
