"""Bounded retries of room survey stations; Nav2 still plans every path."""
import json
import math


def alternatives(name, x, y):
    yield x, y
    # Keep replacement viewpoints in the original room, or original corridor.
    for dx, dy in ((.8, 0), (-.8, 0), (0, .8), (0, -.8)):
        a, b = x + dx, y + dy
        if abs(x) < 1.2:
            valid = abs(a) < .8 and abs(b) < 6
        else:
            valid = 2.2 < abs(a) < 7 and .7 < abs(b) < 6
            valid = valid and a*x > 0 and b*y > 0
        if valid:
            yield a, b


def reach_station(node, name, x, y):
    for attempt, (a, b) in enumerate(alternatives(name, x, y)):
        try:
            node.check_view(a, b)
        except AssertionError:
            continue
        p = node.buf.lookup_transform('map', 'base_link', node.latest_time()).transform.translation
        print('ROUTE_ATTEMPT', json.dumps({'station': name, 'attempt': attempt+1,
                                         'target': [a, b]}), flush=True)
        try:
            node.transit(a, b, math.atan2(b-p.y, a-p.x), name)
            return a, b
        except RuntimeError as error:
            # Clock, TF and sensor failures must still stop the mission.
            if not str(error).startswith(('Transit timeout or repeated recovery:', 'Transit failed:')):
                raise
            node.cancel()
            print('ROUTE_RETRY', str(error), flush=True)
            node.pump(.5)
    print('STATION_UNREACHABLE', name, flush=True)
    return None
