#!/usr/bin/env python3
"""Camera room survey. Uses mapped room stations, never survivor ground truth."""
import json,math,signal,sys,time
import cv2
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'navigation_setup'))
from room_search_mission import Search
from route_recovery import reach_station
import rclpy
from rclpy.signals import SignalHandlerOptions

# Aisles and room view stations from the building layout, not candidate positions.
ROUTE=[('rear_hall',0.,3.5),('rear_left_entry',-4.5,3.5),
       ('rear_left',-4.5,1.1),('front_left',-4.5,-3.5),
       ('front_hall',0.,-3.5),('front_right',2.65,-3.5),
       ('front_hall_return',0.,-3.5),('rear_hall_return',0.,3.5),
       ('rear_right',2.65,3.81),('rear_hall_home',0.,3.5)]
ROOMS={'rear_left','front_left','front_right','rear_right'}

class FinalSearch(Search):
    @staticmethod
    def latest_time():
        return rclpy.time.Time()
    def __init__(self):
        super().__init__();self.reporter.snapshots={};self.room_observation_positions={}
        self.transit_recovery_limit=6;self.transit_timeout=900
    def scan(self,name,x,y):
        room={'room':name,'station':[x,y],'views':[]};self.rooms.append(room)
        # 30-degree spacing gives a centered view missed by the coarse sweep.
        for index in range(12):
            yaw=index*math.pi/6;self.turn(yaw)
            arrived=self.get_clock().now().nanoseconds/1e9;deadline=time.monotonic()+30
            while self.get_clock().now().nanoseconds/1e9-arrived<3.5 and time.monotonic()<deadline:self.pump(.15)
            if self.get_clock().now().nanoseconds/1e9-arrived<3.5:raise RuntimeError('Clock stalled at inspection stop')
            self.pump(.6);labels=[]
            for label,snapshot in self.reporter.snapshots.items():
                if snapshot['simulation_seconds']>=arrived:
                    labels.append(label);self.sightings[label]={'room_observed_from':name,'image_sim_s':snapshot['simulation_seconds']}
            if self.reporter.images:
                image=self.reporter.images[-1]
                cv2.imwrite(str(ROOT/'logs'/f'camera_{name}_{index:02d}.jpg'),self.reporter.bridge.imgmsg_to_cv2(image,'bgr8'))
            room['views'].append({'heading_rad':yaw,'fresh_camera_candidates':labels})
            self.reporter.write();self.checkpoint()
            print('ROOM_VIEW',json.dumps({'room':name,'view':index+1,'fresh_camera_candidates':labels}),flush=True)
        room['completed']=True;self.checkpoint();print('ROOM_COMPLETE',name,flush=True)
    def checkpoint(self):
        (ROOT/'search_progress.json').write_text(json.dumps({'rooms':self.rooms,'fresh_camera_sightings':self.sightings,'simulation_reference':True},indent=2)+'\n')

def main():
    rclpy.init(signal_handler_options=SignalHandlerOptions.NO)
    def interrupt(signum,frame):raise KeyboardInterrupt
    signal.signal(signal.SIGINT,interrupt);signal.signal(signal.SIGTERM,interrupt)
    n=FinalSearch();error=None;returned=False;start=None;start_sim=None
    try:
        n.initialize();n.pump(2)
        t=n.buf.lookup_transform('map','base_link',rclpy.time.Time()).transform;p=t.translation;q=t.rotation
        start=[p.x,p.y,math.atan2(2*q.w*q.z,1-2*q.z*q.z)];start_sim=n.get_clock().now().nanoseconds/1e9
        print('SEARCH_START',json.dumps({'start_pose':start,'route':ROUTE,'known_candidate_positions_used':False}),flush=True)
        for name,x,y in ROUTE:
            reached=reach_station(n,name,x,y)
            if reached is None:
                if name in ROOMS:
                    n.rooms.append({'room':name,'station':[x,y],'views':[],
                                    'completed':False,'reason':'No reachable inspection station'})
                    n.checkpoint()
                continue
            if name in ROOMS:n.scan(name,*reached)
            else:n.pump(.2)
        p=n.buf.lookup_transform('map','base_link',rclpy.time.Time()).transform.translation
        n.transit(start[0],start[1],math.atan2(start[1]-p.y,start[0]-p.x),'return_home_position')
        n.turn(start[2]);n.pump(2);returned=True
    except KeyboardInterrupt:error='Interrupted'
    except Exception as e:error=str(e);print('MISSION_ERROR',error,flush=True)
    finally:
        signal.signal(signal.SIGINT,signal.SIG_IGN);signal.signal(signal.SIGTERM,signal.SIG_IGN)
        n.last_clock=time.monotonic()+60;n.cancel()
        registry=n.state.get('registry',{});labels={r['label'] for r in registry.get('candidates',[])}
        result={'mode':'known_layout_camera_room_survey','simulation_reference':True,'bootstrap_map':'stationary simulation setup scans, not autonomous mapping','candidate_positions_used_for_navigation':False,'start_pose':start,'started_sim_s':start_sim,'rooms':n.rooms,'fresh_camera_sightings':n.sightings,'registry':registry,'images_captured':sorted(n.reporter.snapshots),'unobserved_registry_labels':sorted(labels-set(n.sightings)),'returned_to_start':returned,'navigation':n.transit_results,'error':error,'resumed':False,'completed':returned and len(n.rooms)==4 and all(r.get('completed') for r in n.rooms) and error is None}
        (ROOT/'mission_result.json').write_text(json.dumps(result,indent=2)+'\n');print('MISSION_RESULT',json.dumps(result),flush=True)
        n.close();rclpy.shutdown()
if __name__=='__main__':main()
