#!/usr/bin/env python3
"""Owned-process supervisor for the RubbleRescue simulation demo."""
import argparse,json,math,os,signal,subprocess,sys,time,uuid,shutil
from pathlib import Path
import xml.etree.ElementTree as ET
import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data,QoSProfile,DurabilityPolicy
from nav_msgs.msg import OccupancyGrid,Odometry
from sensor_msgs.msg import Image,LaserScan
from geometry_msgs.msg import Twist
from std_msgs.msg import String
from slam_toolbox.srv import Pause,Reset
from lifecycle_msgs.srv import GetState
from rclpy.signals import SignalHandlerOptions
from process_lifecycle import stop_processes

ROOT=Path(__file__).resolve().parent;OUT=ROOT.parent
class Project(Node):
    def __init__(self):
        super().__init__('rubblerescue_project_manager');self.children=[];self.files=[];self.state={};self.received={};self.stop_pub=self.create_publisher(Twist,'/cmd_vel',10)
        for kind,topic,key in [(Image,'/rescue_camera/image','rgb'),(Image,'/rescue_camera/depth_image','depth'),(LaserScan,'/scan','scan'),(Odometry,'/mapping_reference/odom','pose')]:
            self.create_subscription(kind,topic,lambda m,k=key:self.receive(k,m),qos_profile_sensor_data)
        self.create_subscription(OccupancyGrid,'/map',lambda m:self.receive('map',m),QoSProfile(depth=1,durability=DurabilityPolicy.TRANSIENT_LOCAL))
        self.create_subscription(String,'/survivor_candidates/registry',lambda m:self.receive('registry',m),QoSProfile(depth=1,durability=DurabilityPolicy.TRANSIENT_LOCAL))
    def receive(self,key,msg):self.state[key]=msg;self.received[key]=time.monotonic()
    def launch(self,name,cmd):
        f=open(ROOT/'logs'/f'{name}.log','w');self.files.append(f)
        p=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);self.children.append((name,p));print('STARTED',name,flush=True);return p
    def pump(self,seconds):
        end=time.monotonic()+seconds
        while time.monotonic()<end:
            rclpy.spin_once(self,timeout_sec=.1)
            for name,p in self.children:
                if p.poll() is not None and name not in ('mission','rviz','gazebo_gui','pose_audit'):raise RuntimeError(name+' exited; see '+str(ROOT/'logs'/f'{name}.log'))
    def wait(self,predicate,timeout,description):
        end=time.monotonic()+timeout
        while not predicate() and time.monotonic()<end:self.pump(.2)
        if not predicate():raise RuntimeError('Timed out waiting for '+description)
        print('READY',description,flush=True)
    def service(self,kind,name,req,timeout=12):
        c=self.create_client(kind,name)
        if not c.wait_for_service(timeout_sec=timeout):raise RuntimeError('Unavailable '+name)
        f=c.call_async(req);rclpy.spin_until_future_complete(self,f,timeout_sec=timeout)
        self.destroy_client(c)
        if not f.done() or f.result() is None:raise RuntimeError('No response '+name)
        return f.result()
    def prepare_map(self):
        reset=Reset.Request();reset.pause_new_measurements=True
        self.service(Reset,'/rescue_reference_mapper/reset',reset)
        points=[(-4.5,-3.5),(-4.5,3.5),(4.5,3.5),(4.5,-3.5),(0.,0.),(0.,5.5),(0.,-5.5)]
        for x,y in points:
            for yaw in [0.,.12,.24]:
                self.set_pose(x,y,yaw);self.pump(.7)
                self.service(Pause,'/rescue_reference_mapper/pause_new_measurements',Pause.Request());self.pump(1.8)
                self.service(Pause,'/rescue_reference_mapper/pause_new_measurements',Pause.Request())
            print('MAP_SETUP_SCAN',x,y,flush=True)
        self.set_pose(0.,0.,math.pi/2);self.pump(1)
        self.service(Pause,'/rescue_reference_mapper/pause_new_measurements',Pause.Request());self.pump(3)
        self.wait(lambda:'map'in self.state and self.state['map'].info.width>100,15,'unsaved map')
    def set_pose(self,x,y,yaw):
        req=f'name:"rubblerescue",position:{{x:{x},y:{y},z:0.03}},orientation:{{z:{math.sin(yaw/2)},w:{math.cos(yaw/2)}}}'
        r=subprocess.run(['gz','service','-s','/world/rubble_world/set_pose','--reqtype','gz.msgs.Pose','--reptype','gz.msgs.Boolean','--timeout','5000','--req',req],capture_output=True,text=True,timeout=8)
        if 'true' not in r.stdout:raise RuntimeError('Map setup pose failed: '+r.stdout+r.stderr)
    def close(self):
        for sig in (signal.SIGINT,signal.SIGTERM,signal.SIGHUP):signal.signal(sig,signal.SIG_IGN)
        try:
            if rclpy.ok():
                for _ in range(5):self.stop_pub.publish(Twist());rclpy.spin_once(self,timeout_sec=.05)
        finally:
            stop_processes(session=os.environ['RUBBLERESCUE_SESSION_ID'])
            for _,process in self.children:
                try:process.wait(timeout=1)
                except subprocess.TimeoutExpired:pass
            for file in self.files:file.close()

def prepare_files():
    ROOT.joinpath('logs').mkdir(exist_ok=True)
    # Retain results from previous attempts before a restart creates new files.
    history=ROOT/'logs'/'history'/(time.strftime('%Y%m%d-%H%M%S')+'-'+uuid.uuid4().hex[:8])
    history.mkdir(parents=True,exist_ok=True)
    for name in ['mission_result.json','verification_result.json','project_status.json','search_progress.json']:
        previous=ROOT/name
        if previous.exists():shutil.copy2(previous,history/name)
    for name in ['verification_result.json']:
        previous=ROOT/name
        if previous.exists():previous.unlink()
    source=str(OUT/'lidar_mount_fix'/'Unsaved.urdf.xacro')
    xml=subprocess.check_output(['xacro',source],text=True);tree=ET.fromstring(xml)
    sys.path.insert(0,str(OUT/'autonomous_search'))
    from robot_setup import remove_arm,add_imu
    remove_arm(tree)
    if os.environ.get('RUBBLE_IMU_ODOMETRY')=='1':add_imu(tree)
    for sensor in tree.findall('.//sensor'):
        if sensor.get('type')=='rgbd_camera':
            sensor.find('update_rate').text='5'
            sensor.find('camera/image/width').text='320'
            sensor.find('camera/image/height').text='240'
    ET.ElementTree(tree).write(ROOT/'robot.urdf',encoding='unicode')
    source='/home/sreedevi-k/rubblerescue_ws/src/rubblerescue_gazebo/worlds/rubble_world.sdf'
    sys.path.insert(0,str(OUT/'rubble_terrain'))
    from add_terrain import add_terrain
    add_terrain(source,ROOT/'world.sdf')

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--setup-only',action='store_true');parser.add_argument('--no-ui',action='store_true');args=parser.parse_args()
    # The shell holds project.lock before this cleanup, so another live run is protected.
    stop_processes(legacy=True)
    os.environ['RUBBLERESCUE_PROJECT_ROOT']=str(ROOT)
    os.environ['RUBBLERESCUE_SESSION_ID']=uuid.uuid4().hex
    os.environ['RUBBLERESCUE_MANAGED_RUN']='1'
    prepare_files();rclpy.init(signal_handler_options=SignalHandlerOptions.NO)
    def interrupt(signum,frame):raise KeyboardInterrupt
    signal.signal(signal.SIGINT,interrupt);signal.signal(signal.SIGTERM,interrupt);signal.signal(signal.SIGHUP,interrupt)
    n=Project();status={'phase':'starting','error':None,'passed':False}
    try:
        n.launch('simulation',['ros2','launch',str(ROOT/'simulation.launch.py')])
        n.wait(lambda:all(k in n.state for k in ['rgb','depth','scan']),90,'RGB, depth and LiDAR')
        n.launch('mapping',['bash',str(OUT/'mapping_repair/start_simulation_reference_mapping.sh')])
        n.wait(lambda:'pose'in n.state,30,'simulation pose reference');n.pump(3)
        n.prepare_map()
        n.launch('detector',[sys.executable,str(OUT/'survivor_detection/survivor_candidate_detector.py')])
        n.launch('registry',[sys.executable,str(OUT/'survivor_detection/survivor_map_markers.py')])
        n.launch('navigation',['bash',str(OUT/'navigation_setup/start_navigation.sh')])
        n.wait(lambda:'bt_navigator'in n.get_node_names(),30,'navigation nodes');n.pump(5)
        state=n.service(GetState,'/bt_navigator/get_state',GetState.Request()).current_state.id
        if state!=3:raise RuntimeError('Nav2 is not active')
        if not args.no_ui:
            n.launch('gazebo_gui',['gz','sim','-g'])
            env=os.environ.copy();env['LIBGL_ALWAYS_SOFTWARE']='1'
            # Same environment as the supervised ROS domain.
            n.launch('rviz',['bash',str(ROOT/'open_viewer.sh')])
        status['phase']='ready';print('PROJECT_READY',flush=True)
        if not args.setup_only:
            mission=n.launch('mission',[sys.executable,str(ROOT/'search_mission.py')])
            with open(ROOT/'logs'/'mission.log') as progress:
                while mission.poll() is None:
                    n.pump(.5)
                    for line in progress.readlines():
                        if line.startswith(('TRANSIT_','NAVIGATION_FEEDBACK','ROOM_VIEW','ROOM_COMPLETE','MISSION_ERROR','ROUTE_','STATION_UNREACHABLE')):print(line.rstrip(),flush=True)
                    stale=[k for k in ['rgb','depth','scan','pose'] if time.monotonic()-n.received.get(k,0)>15]
                    if stale:raise RuntimeError('Stale simulation data: '+','.join(stale))
            result=json.loads((ROOT/'mission_result.json').read_text())
            if result['completed']:
                with open(ROOT/'logs'/'verification.log','w') as f:subprocess.run([sys.executable,str(ROOT/'verify_project.py')],stdout=f,stderr=subprocess.STDOUT,check=True,timeout=20)
                status['verification']=json.loads((ROOT/'verification_result.json').read_text())
            status['passed']=result['completed'] and status.get('verification',{}).get('passed',False);status['phase']='finished';status['result']=result
            print('PROJECT_RESULT',json.dumps(status),flush=True)
        (ROOT/'project_status.json').write_text(json.dumps(status,indent=2)+'\n')
        if status['phase']=='finished':subprocess.run([sys.executable,str(ROOT/'build_delivery.py')],check=True,timeout=60)
        print('Project remains open. Ctrl+C stops all owned processes.',flush=True)
        while True:n.pump(.5)
    except KeyboardInterrupt:status['phase']='stopped';print('PROJECT_STOPPING',flush=True)
    except Exception as e:
        status['phase']='failed';status['error']=str(e);print('PROJECT_ERROR',e,flush=True)
    finally:
        try:(ROOT/'project_status.json').write_text(json.dumps(status,indent=2)+'\n')
        finally:
            n.close();n.destroy_node();rclpy.shutdown()
if __name__=='__main__':
    if '--autonomous' in sys.argv:
        sys.path.insert(0,str(OUT/'autonomous_search'))
        from run_autonomous import main as autonomous_main
        autonomous_main()
    else:main()
