import json,os
from pathlib import Path
ROOT=Path(__file__).resolve().parent;found=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  if p.stat().st_uid!=os.getuid():continue
  env=dict(x.split(b'=',1) for x in (p/'environ').read_bytes().split(b'\0') if b'=' in x)
  if env.get(b'ROS_DOMAIN_ID')!=b'42' or env.get(b'GZ_PARTITION')!=b'rubblerescue_final':continue
  args=[x.decode(errors='replace') for x in (p/'cmdline').read_bytes().split(b'\0') if x]
  found.append({'pid':int(p.name),'pgid':os.getpgid(int(p.name)),'args':args})
 except (FileNotFoundError,PermissionError,ProcessLookupError):pass
(ROOT/'stale_sessions.json').write_text(json.dumps(found,indent=2))
