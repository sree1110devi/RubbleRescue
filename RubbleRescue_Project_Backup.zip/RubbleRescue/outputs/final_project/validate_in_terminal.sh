#!/usr/bin/env bash
set -e
exec gnome-terminal --title='RubbleRescue validation' -- bash -c 'bash /home/sreedevi-k/Documents/Codex/2026-11-18/th/outputs/final_project/run_project.sh --no-ui 2>&1 | tee /home/sreedevi-k/Documents/Codex/2026-11-18/th/outputs/final_project/logs/project.log; read -r -p "Press Enter to close this terminal."'
