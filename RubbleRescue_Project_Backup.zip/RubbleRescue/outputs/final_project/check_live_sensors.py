import json,time,rclpy
from pathlib import Path
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import Image,LaserScan
from nav_msgs.msg import Odometry
rclpy.init();n=Node('rubblerescue_display_health_check');counts=dict.fromkeys(['rgb','depth','scan','pose'],0)
for kind,topic,key in [(Image,'/rescue_camera/image','rgb'),(Image,'/rescue_camera/depth_image','depth'),(LaserScan,'/scan','scan'),(Odometry,'/mapping_reference/odom','pose')]:
 def receive(msg,k=key):counts[k]+=1
 n.create_subscription(kind,topic,receive,qos_profile_sensor_data)
end=time.monotonic()+5
while time.monotonic()<end:rclpy.spin_once(n,timeout_sec=.1)
r={'passed':all(c>0 for c in counts.values()),'messages_after_opening_gui':counts};Path(__file__).with_name('display_health_result.json').write_text(json.dumps(r,indent=2)+'\n');print(r);n.destroy_node();rclpy.shutdown()
