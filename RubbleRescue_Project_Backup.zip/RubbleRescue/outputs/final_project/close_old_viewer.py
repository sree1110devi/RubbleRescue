"""Close only this project's obsolete viewer without the rendering overlay."""
import os,signal
from pathlib import Path
config=b'/home/sreedevi-k/Documents/Codex/2026-11-18/th/outputs/final_project/project_view.rviz'
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  args=(p/'cmdline').read_bytes().split(b'\0')
  if not args or not args[0].endswith(b'/rviz2') or config not in args:continue
  env=(p/'environ').read_bytes()
  if b'/final_project/rviz_overlay' not in env:os.kill(int(p.name),signal.SIGINT)
 except (FileNotFoundError,PermissionError,ProcessLookupError):pass
