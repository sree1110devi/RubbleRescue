from pathlib import Path
import os
from launch import LaunchDescription
from launch.actions import ExecuteProcess, Shutdown
from launch_ros.actions import Node

def generate_launch_description():
    folder=Path(__file__).resolve().parent
    robot=(folder/'robot.urdf').read_text()
    bridges=['/cmd_vel@geometry_msgs/msg/Twist]gz.msgs.Twist','/odom@nav_msgs/msg/Odometry[gz.msgs.Odometry','/joint_states@sensor_msgs/msg/JointState[gz.msgs.Model','/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock','/scan@sensor_msgs/msg/LaserScan[gz.msgs.LaserScan','/rescue_camera/image@sensor_msgs/msg/Image[gz.msgs.Image','/rescue_camera/depth_image@sensor_msgs/msg/Image[gz.msgs.Image','/rescue_camera/camera_info@sensor_msgs/msg/CameraInfo[gz.msgs.CameraInfo','/model/rubblerescue/tf@tf2_msgs/msg/TFMessage[gz.msgs.Pose_V']
    if os.environ.get('RUBBLE_IMU_ODOMETRY')=='1':
        bridges=[b for b in bridges if not b.startswith('/model/rubblerescue/tf@')]
        bridges.append('/imu@sensor_msgs/msg/Imu[gz.msgs.IMU')
    return LaunchDescription([
        ExecuteProcess(cmd=['gz','sim','-r','-s',str(folder/'world.sdf')],output='screen',on_exit=[Shutdown(reason='Gazebo server exited')]),
        Node(package='robot_state_publisher',executable='robot_state_publisher',parameters=[{'robot_description':robot,'use_sim_time':True}]),
        Node(package='ros_gz_sim',executable='create',arguments=['-name','rubblerescue','-topic','robot_description','-x',os.environ.get('RUBBLE_SPAWN_X','0'),'-y',os.environ.get('RUBBLE_SPAWN_Y','0'),'-z',os.environ.get('RUBBLE_SPAWN_Z','0.2'),'-Y',os.environ.get('RUBBLE_SPAWN_YAW','0')]),
        Node(package='ros_gz_bridge',executable='parameter_bridge',arguments=bridges,remappings=[('/model/rubblerescue/tf','/tf')],output='screen',on_exit=[Shutdown(reason='Sensor bridge exited')])])
