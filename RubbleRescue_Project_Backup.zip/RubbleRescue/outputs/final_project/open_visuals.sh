#!/usr/bin/env bash
set -e
source /home/sreedevi-k/Documents/Codex/2026-11-18/th/outputs/final_project/environment.sh
gz sim -g > /home/sreedevi-k/Documents/Codex/2026-11-18/th/outputs/final_project/logs/gazebo_gui.log 2>&1 &
project_gui_pid=$!
trap 'kill "$project_gui_pid" 2>/dev/null || true' EXIT
bash /home/sreedevi-k/Documents/Codex/2026-11-18/th/outputs/final_project/open_viewer.sh
