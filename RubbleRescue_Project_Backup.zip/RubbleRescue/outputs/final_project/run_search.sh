#!/usr/bin/env bash
set -e
source /home/sreedevi-k/Documents/Codex/2026-11-18/th/outputs/final_project/environment.sh
exec python3 /home/sreedevi-k/Documents/Codex/2026-11-18/th/outputs/final_project/search_mission.py
