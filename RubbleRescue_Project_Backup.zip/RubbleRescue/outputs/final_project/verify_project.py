#!/usr/bin/env python3
"""Evaluate demo results against the scene only AFTER the search mission."""
import csv,json,math,time
from pathlib import Path
import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from nav_msgs.msg import Odometry
ROOT=Path(__file__).resolve().parent
r=json.loads((ROOT/'mission_result.json').read_text())
records=r.get('registry',{}).get('candidates',[])
truth=list(csv.DictReader((ROOT.parent/'rubblerescue_house_v2/survivor_ground_truth.csv').open()))
# Ground truth is used by this evaluator only, never by the search/detector.
scene_matches=[];used=set()
for person in truth:
 choices=[(math.hypot(c['position'][0]-float(person['x_m']),c['position'][1]-float(person['y_m'])),c) for c in records if c['label'] not in used]
 if choices:
  distance,c=min(choices,key=lambda v:v[0])
  if distance<.8:used.add(c['label']);scene_matches.append({'scene_id':person['id'],'posture':person['posture'],'candidate_label':c['label'],'surface_to_model_origin_distance_xy_m':distance})
rclpy.init();n=Node('rubblerescue_final_verification');samples=[]
def pose(msg):
 p=msg.pose.pose;q=p.orientation
 samples.append((p.position.x,p.position.y,math.atan2(2*q.w*q.z,1-2*q.z*q.z)))
n.create_subscription(Odometry,'/mapping_reference/odom',pose,qos_profile_sensor_data)
end=time.monotonic()+5
while time.monotonic()<end:rclpy.spin_once(n,timeout_sec=.1)
if len(samples)>2:
 a,b=samples[0],samples[-1];displacement=math.hypot(a[0]-b[0],a[1]-b[1]);rotation=abs(math.atan2(math.sin(b[2]-a[2]),math.cos(b[2]-a[2])))
 start=r['start_pose'];home_error=math.hypot(b[0]-start[0],b[1]-start[1]);heading_error=abs(math.atan2(math.sin(b[2]-start[2]),math.cos(b[2]-start[2])))
 stopped=displacement<.01 and rotation<.02
else:displacement=rotation=home_error=heading_error=None;stopped=False
empty_room=next((room for room in r.get('rooms',[]) if room['room']=='front_right'),{})
checks={'empty_control_room_no_candidates':bool(empty_room.get('completed')) and all(not view.get('fresh_camera_candidates') for view in empty_room.get('views',[])),'mission_completed':r.get('completed',False),'four_room_sweeps':len(r.get('rooms',[]))==4 and all(c.get('completed') for c in r.get('rooms',[])),'all_three_scene_mannequins_matched':len(scene_matches)==3 and len(records)==3,'all_candidates_have_fresh_camera_sightings':set(c['label'] for c in records)<=set(r.get('fresh_camera_sightings',{})),'all_candidates_have_images':set(c['label'] for c in records)<=set(r.get('images_captured',[])),'returned_to_start':r.get('returned_to_start',False) and home_error is not None and home_error<.2 and heading_error<.3,'robot_stopped':stopped}
result={'passed':all(checks.values()),'checks':checks,'scene_matches_evaluation_only':scene_matches,'pose_samples':len(samples),'stationary_displacement_m':displacement,'stationary_rotation_rad':rotation,'home_position_error_m':home_error,'home_heading_error_rad':heading_error,'simulated_unconfirmed_candidates_only':True,'occupancy_map_saved':False}
(ROOT/'verification_result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True);n.destroy_node();rclpy.shutdown()
