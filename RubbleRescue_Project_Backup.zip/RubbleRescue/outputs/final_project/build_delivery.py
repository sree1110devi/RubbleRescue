#!/usr/bin/env python3
"""Build a clearly scoped project guide and source backup after validation."""
import base64,html,json,zipfile
from datetime import datetime
from pathlib import Path
ROOT=Path(__file__).resolve().parent;OUT=ROOT.parent
result=json.loads((ROOT/'mission_result.json').read_text())
report=json.loads((OUT/'rescue_report/rescue_report.json').read_text())
verification=json.loads((ROOT/'verification_result.json').read_text()) if (ROOT/'verification_result.json').exists() else {}
passed=result.get('completed',False) and verification.get('passed',False)
labels=result.get('fresh_camera_sightings',{});snapshots=result.get('images_captured',[])
status='PASSED' if passed else 'NOT PASSED'
restart=json.loads((ROOT/'restart_verification.json').read_text()) if (ROOT/'restart_verification.json').exists() else {}
text=f'''RubbleRescue — Search and location-reporting simulation project

Latest full search test: {status}
Restart/shutdown validation: {restart}
Restart testing covers startup and clean shutdown only. It does not re-run the
full search. An older failed full-search result remains a failure until a fresh
full search completes; historical results are retained under logs/history.
Verification checks: {verification.get('checks',{})}
Room sweeps completed: {sum(bool(r.get('completed')) for r in result.get('rooms',[]))}/4
Fresh camera sightings: {', '.join(labels) or 'none'}
Images captured: {', '.join(snapshots) or 'none'}
Returned to starting pose: {result.get('returned_to_start',False)}
Error: {result.get('error')}

START THE COMPLETE PROJECT ON THIS LAPTOP
Run this in a terminal (only one instance):
bash /home/sreedevi-k/Documents/Codex/2026-11-18/th/outputs/final_project/run_project.sh

Or open it in a dedicated terminal:
bash /home/sreedevi-k/Documents/Codex/2026-11-18/th/outputs/final_project/launch_in_terminal.sh

What happens automatically:
1. Start Gazebo and spawn the robot in the collapsed building.
2. Verify RGB, depth and LiDAR data.
3. Prepare an unsaved map from stationary simulation setup scans.
4. Start Nav2, the colour/depth detector and candidate registry.
5. Open the Gazebo viewer and the combined RViz display.
6. Survey four mapped room stations, turning through 12 camera headings per room.
7. Record unconfirmed candidate positions, camera images and last-seen times.
8. Return to the initial robot position and heading, then remain open.

Do not use teleop while the mission is running. No manual goals are required.
Navigation cruise target: 0.35 m/s, with a 1.0 rad/s turning limit. Nav2 can
slow the robot near obstacles and goals. Inspection pauses remain unchanged.
The earlier 0.25 m/s profile passed a hallway out-and-back test. The current
0.35 m/s settings were applied during an existing search; its following room
navigation goal succeeded with zero recoveries. This was not a new full-search
validation at the higher speed.
The earlier full-scene validation figures refer to the previous speed profile.
Wait for PROJECT_RESULT in the terminal. Ctrl+C stops the owned processes.
Terminal-close (SIGHUP) shutdown is also handled. Startup removes leftover
processes from this project after acquiring its exclusive run lock.
The complete survey can take tens of minutes on this laptop because simulation
runs slower than real time. Progress is printed; do not start another instance.
--no-ui runs the same test without the graphical viewers.
--setup-only starts the environment without automatically driving.

OPEN THE COMBINED VIEWER WHILE THE PROJECT IS RUNNING
bash /home/sreedevi-k/Documents/Codex/2026-11-18/th/outputs/final_project/open_viewer.sh

REPORT
/home/sreedevi-k/Documents/Codex/2026-11-18/th/outputs/rescue_report/rescue_report.html
Reload the report to see the latest captured observations.
After return, the live camera shows the starting area; the report retains the
three candidate images captured during the search.

PROOF OF THE TEST
/home/sreedevi-k/Documents/Codex/2026-11-18/th/outputs/final_project/mission_result.json
/home/sreedevi-k/Documents/Codex/2026-11-18/th/outputs/final_project/project_status.json
Logs are in outputs/final_project/logs. Failed goals are recorded as failures.

ARCHITECTURE
Gazebo → ROS/Gazebo bridge → LiDAR + RGB/depth + wheel odometry
Gazebo pose reference + wheel odometry → TF → stationary-scan map
Live map + LiDAR + small depth obstacle cloud → Nav2 → collision monitor → robot
RGB + depth → simulated mannequin candidate detector → map registry → camera report
Room survey runner → Nav2 goals + collision-checked turns → stop and observe → return

DEMO EXPLANATION FOR CLASS
“RubbleRescue is a simulated search and location-reporting robot for a collapsed
building. It surveys known room stations, uses RGB and depth observations to flag
possible mannequin victims, places unconfirmed locations on the map, saves camera
evidence in a report, and returns to its start. Human review is required.”

SCOPE AND LIMITATIONS
This is a simulation prototype, not a field-ready rescue system.
The room stations come from the building layout; this is not unknown-area frontier
exploration. Candidate positions and the survivor ground-truth CSV are not used to
choose the search route. Detection uses mannequin colours and depth geometry,
not a trained human-recognition model. Occlusion, lighting and viewing angle can
cause false positives or missed detections. Labels are spatial candidate records,
not a verified survivor count. Positions are visible surface observations in the
local map frame, not GPS coordinates. Localization uses Gazebo's reference pose;
this does not validate autonomous localization or repair wheel-odometry drift.
Map preparation stages stationary scan poses before the search starts; that setup
is not autonomous mapping. The search test itself uses Nav2 without pose resets.
The robot reports possible survivor locations; it does not lift or carry people.
No occupancy map is saved. Reports, camera images and test results are saved.

SOFTWARE
Ubuntu, ROS 2 Jazzy, Gazebo Sim, ros_gz, Nav2, SLAM Toolbox, Python 3,
OpenCV, NumPy and cv_bridge. These are already present on this laptop.
Blender is only needed to edit the scene asset, not to run the demo.
RViz uses a local rendering-resource overlay to fix the palette shader error on
this laptop. The system ROS installation has not been modified.
ROS domain 42 and Gazebo partition rubblerescue_final isolate the managed demo
from earlier manually started nodes. Use the provided scripts so these match.
Candidate IDs restart with a new simulation session; labels are not permanent identities.
Camera track numbers may differ from the registry labels shown on the map/report.

SOURCE BACKUP
The ZIP includes the project scripts, configuration, building assets and robot
ROS package sources. It is a backup of this laptop's setup. Absolute paths in
scripts must be adjusted if moving to a different user or computer. No dependency
installer or physical-hardware validation is claimed.
'''
(ROOT/'PROJECT_GUIDE.txt').write_text(text)
style='body{max-width:1080px;margin:40px auto;padding:24px;font:16px/1.65 system-ui;color:#183143;background:#f3f6f8}pre{white-space:pre-wrap;background:white;padding:26px;border-radius:12px}img{max-width:100%}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:20px}article{padding:18px;background:white;border-radius:10px}'
cards=[]
for record in report.get('candidates',[]):
 snap=record.get('camera_snapshot');image=('<img src="'+html.escape(snap['path'],quote=True)+'" alt="Candidate camera evidence">') if snap else '<p>No matching image captured.</p>'
 cards.append('<article><h2>'+html.escape(record['label'])+'</h2><p>Unconfirmed — needs human review</p>'+image+'<p>Map position: '+html.escape(str([round(v,3) for v in record['position']]))+' m</p></article>')
(ROOT/'PROJECT_GUIDE.html').write_text('<!doctype html><html><meta charset="utf-8"><title>RubbleRescue Project Guide</title><style>'+style+'</style><h1>RubbleRescue</h1><p>Simulation project · validation '+status+'</p><div class="grid">'+''.join(cards)+'</div><pre>'+html.escape(text)+'</pre></html>')
backup=OUT/'RubbleRescue_Project_Backup.zip'
include=['final_project','navigation_setup','mapping_repair','survivor_detection','rescue_report','rubblerescue_house_v2','lidar_mount_fix','rubble_terrain','autonomous_search']
with zipfile.ZipFile(backup,'w',zipfile.ZIP_DEFLATED) as z:
 for name in include:
  for p in (OUT/name).rglob('*'):
   if p.is_file() and '__pycache__' not in p.parts and 'logs' not in p.parts and p.suffix not in {'.log','.lock','.tmp'}:z.write(p,'RubbleRescue/outputs/'+str(p.relative_to(OUT)))
 z.write(OUT.parent/'work/ros_udp.xml','RubbleRescue/work/ros_udp.xml')
 for package in ['robocar_description','rubblerescue_gazebo']:
  base=Path('/home/sreedevi-k/rubblerescue_ws/src')/package
  for p in base.rglob('*'):
   if p.is_file() and '__pycache__' not in p.parts and '.git' not in p.parts:z.write(p,'RubbleRescue/robot_ws/src/'+str(p.relative_to(base.parent)))
with zipfile.ZipFile(backup) as z:assert z.testzip() is None
print(json.dumps({'validation':status,'guide':str(ROOT/'PROJECT_GUIDE.html'),'backup':str(backup),'bytes':backup.stat().st_size}))
