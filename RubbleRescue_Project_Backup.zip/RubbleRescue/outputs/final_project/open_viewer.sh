#!/usr/bin/env bash
set -e
source /home/sreedevi-k/Documents/Codex/2026-11-18/th/outputs/final_project/environment.sh
export LIBGL_ALWAYS_SOFTWARE=1
export AMENT_PREFIX_PATH=/home/sreedevi-k/Documents/Codex/2026-11-18/th/outputs/final_project/rviz_overlay:${AMENT_PREFIX_PATH}
view=/home/sreedevi-k/Documents/Codex/2026-11-18/th/outputs/final_project/project_view.rviz
if [ "${RUBBLE_AUTONOMOUS:-0}" = "1" ]; then
  view=/home/sreedevi-k/Documents/Codex/2026-11-18/th/outputs/autonomous_search/operator_view.rviz
fi
exec rviz2 -d "$view" --ros-args -p use_sim_time:=true
