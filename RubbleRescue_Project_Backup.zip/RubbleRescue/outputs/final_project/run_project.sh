#!/usr/bin/env bash
set -eo pipefail
source /opt/ros/jazzy/setup.bash
source /home/sreedevi-k/rubblerescue_ws/install/setup.bash
export ROS_DOMAIN_ID=42
unset ROS_LOCALHOST_ONLY
export ROS_AUTOMATIC_DISCOVERY_RANGE=LOCALHOST
export GZ_PARTITION=rubblerescue_final
export ROS_LOG_DIR=/home/sreedevi-k/Documents/Codex/2026-11-18/th/outputs/final_project/logs/ros
export FASTRTPS_DEFAULT_PROFILES_FILE=/home/sreedevi-k/Documents/Codex/2026-11-18/th/work/ros_udp.xml
export GZ_SIM_RESOURCE_PATH=/home/sreedevi-k/Documents/Codex/2026-11-18/th/outputs:/home/sreedevi-k/rubblerescue_ws/install/robocar_description/share
exec flock -n -E 75 --verbose /home/sreedevi-k/Documents/Codex/2026-11-18/th/outputs/final_project/project.lock python3 /home/sreedevi-k/Documents/Codex/2026-11-18/th/outputs/final_project/project.py "$@"
