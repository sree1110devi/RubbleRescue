"""Apply persisted speed settings and observe motion without sending goals."""
import json,time,yaml,rclpy
from pathlib import Path
from rclpy.node import Node
from rclpy.parameter import Parameter
from rcl_interfaces.srv import SetParameters,GetParameters
from rclpy.qos import qos_profile_sensor_data
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
ROOT=Path(__file__).resolve().parent
rclpy.init();n=Node('rubblerescue_speed_profile_update');peak={'command_m_s':0.,'measured_m_s':0.,'turn_rad_s':0.};result={'applied':{},'motion_observed':False,'test_scope':'Passive observation during the existing search; no extra goals or stop commands.'}
def cmd(m):peak['command_m_s']=max(peak['command_m_s'],abs(m.linear.x));peak['turn_rad_s']=max(peak['turn_rad_s'],abs(m.angular.z))
n.create_subscription(Twist,'/cmd_vel',cmd,10)
n.create_subscription(Odometry,'/nav2/odom',lambda m:peak.update(measured_m_s=max(peak['measured_m_s'],abs(m.twist.twist.linear.x))),qos_profile_sensor_data)
d=yaml.safe_load((ROOT.parent/'navigation_setup/nav2_params.yaml').read_text());p=d['controller_server']['ros__parameters']['FollowPath'];v=d['velocity_smoother']['ros__parameters'];b=d['behavior_server']['ros__parameters']
settings={'controller_server':{'FollowPath.'+k:p[k] for k in ['desired_linear_vel','rotate_to_heading_angular_vel','max_angular_accel']},'velocity_smoother':{k:v[k] for k in ['max_velocity','min_velocity','max_accel','max_decel']},'behavior_server':{k:b[k] for k in ['max_rotational_vel','rotational_acc_lim']}}
try:
 for name,values in settings.items():
  c=n.create_client(SetParameters,'/'+name+'/set_parameters');assert c.wait_for_service(timeout_sec=5),name+' unavailable'
  q=SetParameters.Request();q.parameters=[Parameter(k,value=value).to_parameter_msg() for k,value in values.items()];f=c.call_async(q);rclpy.spin_until_future_complete(n,f,timeout_sec=5)
  assert f.done() and f.result() is not None,name+' did not respond'
  states=[{'name':k,'successful':x.successful,'reason':x.reason} for k,x in zip(values,f.result().results)];result['applied'][name]=states;assert all(x['successful'] for x in states),states
 print('PROFILE_APPLIED',json.dumps(settings),flush=True)
 end=time.monotonic()+150
 while (peak['command_m_s']<.34 or peak['measured_m_s']<.30) and time.monotonic()<end:rclpy.spin_once(n,timeout_sec=.1)
 result['motion_observed']=peak['command_m_s']>=.34 and peak['measured_m_s']>=.30
 result['peak']=peak
except Exception as e:result['error']=str(e)
finally:
 (ROOT/'faster_profile_result.json').write_text(json.dumps(result,indent=2)+'\n');print('PROFILE_RESULT',json.dumps(result),flush=True);n.destroy_node();rclpy.shutdown()
