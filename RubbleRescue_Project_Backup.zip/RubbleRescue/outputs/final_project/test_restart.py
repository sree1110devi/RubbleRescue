"""Exercise terminal-close and Ctrl+C shutdown, then restart cleanly."""
import json,os,signal,subprocess,time
from pathlib import Path
from process_lifecycle import matching
ROOT=Path(__file__).resolve().parent
results=[]
try:
 for index,sig in enumerate([signal.SIGHUP,signal.SIGINT],1):
  log=ROOT/'logs'/f'restart_cycle_{index}.log'
  with log.open('w') as output:
   p=subprocess.Popen(['bash',str(ROOT/'run_project.sh'),'--setup-only','--no-ui'],stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
   end=time.monotonic()+420
   ready=False
   while p.poll() is None and time.monotonic()<end:
    data=log.read_text(errors='replace')
    if 'PROJECT_READY' in data:ready=True;break
    time.sleep(.2)
   if not ready:
    if p.poll() is None:os.killpg(p.pid,signal.SIGINT)
    raise RuntimeError('Startup cycle '+str(index)+' failed; see '+str(log))
   print('CYCLE_READY',index,flush=True);os.killpg(p.pid,sig)
   try:p.wait(timeout=25)
   except subprocess.TimeoutExpired:raise RuntimeError('Supervisor did not exit after '+sig.name)
   end=time.monotonic()+10
   while matching(legacy=True) and time.monotonic()<end:time.sleep(.2)
   remaining=matching(legacy=True);assert not remaining,('Leftover project processes',remaining)
   results.append({'cycle':index,'startup_ready':True,'signal':sig.name,'remaining_project_processes':0})
   print('CYCLE_SHUTDOWN_PASSED',index,sig.name,flush=True)
 result={'passed':len(results)==2,'cycles':results,'scope':'restart and shutdown lifecycle; earlier full search verification retained'}
except Exception as e:result={'passed':False,'cycles':results,'error':str(e)}
(ROOT/'restart_verification.json').write_text(json.dumps(result,indent=2)+'\n');print('RESTART_RESULT',json.dumps(result),flush=True)
