import sys,json,time,math
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'navigation_setup'))
from candidate_inspection_mission import Mission
import rclpy
from rclpy.parameter import Parameter
from rcl_interfaces.srv import SetParameters
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from action_msgs.msg import GoalStatusArray
from rclpy.qos import QoSProfile,DurabilityPolicy,qos_profile_sensor_data
rclpy.init();n=Mission();result={'applied':{},'test':None};peak={'command_m_s':0.,'measured_m_s':0.};active=[]
n.create_subscription(Twist,'/cmd_vel',lambda m:peak.update(command_m_s=max(peak['command_m_s'],abs(m.linear.x))),10)
n.create_subscription(Odometry,'/nav2/odom',lambda m:peak.update(measured_m_s=max(peak['measured_m_s'],abs(m.twist.twist.linear.x))),qos_profile_sensor_data)
n.create_subscription(GoalStatusArray,'/navigate_to_pose/_action/status',lambda m:active.extend(s.status for s in m.status_list if s.status in (1,2)),QoSProfile(depth=1,durability=DurabilityPolicy.TRANSIENT_LOCAL))
settings={'controller_server':{'FollowPath.desired_linear_vel':.25,'FollowPath.rotate_to_heading_angular_vel':.8,'FollowPath.max_angular_accel':1.8},'velocity_smoother':{'max_velocity':[.25,0.,.8],'min_velocity':[-.1,0.,-.8],'max_accel':[.4,0.,1.8],'max_decel':[-.6,0.,-1.8]},'behavior_server':{'max_rotational_vel':.8,'rotational_acc_lim':1.8}}
try:
 for node,values in settings.items():
  c=n.create_client(SetParameters,'/'+node+'/set_parameters');assert c.wait_for_service(timeout_sec=5),node+' not available'
  q=SetParameters.Request();q.parameters=[Parameter(k,value=v).to_parameter_msg() for k,v in values.items()];f=c.call_async(q);rclpy.spin_until_future_complete(n,f,timeout_sec=5)
  assert f.done() and f.result() is not None,node+' did not respond'
  result['applied'][node]={k:{'successful':r.successful,'reason':r.reason} for k,r in zip(values,f.result().results)}
  assert all(r.successful for r in f.result().results),result['applied'][node]
 n.spin_for(2)
 if active:result['test']='Live settings updated; existing navigation goal left running.'
 else:
  n.initialize();p=n.buf.lookup_transform('map','base_link',rclpy.time.Time()).transform;t=p.translation;q=p.rotation;yaw=math.atan2(2*q.w*q.z,1-2*q.z*q.z)
  if abs(t.x)<.5 and abs(t.y)<.5:
   x,y=t.x,t.y;n.transit(x,y+1.8,math.pi/2,'faster_hallway_out');n.transit(x,y,yaw,'faster_return_home');result['test']={'passed':peak['command_m_s']>=.2,'navigation':n.transit_results,'peak':peak}
  else:result['test']='Settings applied; short test skipped because robot is outside the start corridor.'
except Exception as e:result['error']=str(e)
finally:
 if not active:n.cancel()
 (ROOT/'speed_change_result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True);n.destroy_node();rclpy.shutdown()
