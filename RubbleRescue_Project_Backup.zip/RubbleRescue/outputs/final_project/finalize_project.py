import json,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
subprocess.run([sys.executable,str(ROOT/'verify_project.py')],check=True,timeout=20)
v=json.loads((ROOT/'verification_result.json').read_text());s=json.loads((ROOT/'project_status.json').read_text());s['verification']=v;s['passed']=bool(s.get('result',{}).get('completed')) and v['passed'];(ROOT/'project_status.json').write_text(json.dumps(s,indent=2)+'\n')
subprocess.run([sys.executable,str(ROOT/'build_delivery.py')],check=True,timeout=60)
print('FINAL_VERIFICATION_PASSED',v['passed'],flush=True)
