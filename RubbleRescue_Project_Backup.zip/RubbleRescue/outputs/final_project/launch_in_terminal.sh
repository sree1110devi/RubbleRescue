#!/usr/bin/env bash
set -e
export GSETTINGS_BACKEND=memory
exec gnome-terminal --title=RubbleRescue -- bash -c 'bash /home/sreedevi-k/Documents/Codex/2026-11-18/th/outputs/final_project/run_project.sh; echo; read -r -p "Press Enter to close this terminal."'
