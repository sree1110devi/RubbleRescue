"""Own-session cleanup, including descendants whose launcher already exited."""
import os,signal,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def ancestors():
    found={os.getpid()};pid=os.getpid()
    while pid>1:
        try:
            text=Path(f'/proc/{pid}/stat').read_text();pid=int(text[text.rfind(')')+2:].split()[1]);found.add(pid)
        except (FileNotFoundError,PermissionError,ValueError):break
    return found

def matching(session=None,legacy=False):
    excluded=ancestors();found=[]
    for entry in Path('/proc').iterdir():
        if not entry.name.isdigit() or int(entry.name) in excluded:continue
        try:
            if entry.stat().st_uid!=os.getuid():continue
            env=dict(p.split(b'=',1) for p in (entry/'environ').read_bytes().split(b'\0') if b'=' in p)
            tagged=env.get(b'RUBBLERESCUE_PROJECT_ROOT')==str(ROOT).encode()
            if session is not None:owned=tagged and env.get(b'RUBBLERESCUE_SESSION_ID')==session.encode()
            else:owned=tagged or (legacy and env.get(b'ROS_DOMAIN_ID')==b'42' and env.get(b'GZ_PARTITION')==b'rubblerescue_final')
            if owned:found.append(int(entry.name))
        except (FileNotFoundError,PermissionError,ProcessLookupError):pass
    return found

def stop_processes(session=None,legacy=False):
    initial=matching(session,legacy)
    for sig,wait in [(signal.SIGINT,4),(signal.SIGTERM,2),(signal.SIGKILL,2)]:
        for pid in matching(session,legacy):
            try:os.kill(pid,sig)
            except ProcessLookupError:pass
        end=time.monotonic()+wait
        while time.monotonic()<end and matching(session,legacy):time.sleep(.1)
        if not matching(session,legacy):break
    remaining=matching(session,legacy)
    print(f'PROCESS_CLEANUP stopped={len(initial)} remaining={len(remaining)}',flush=True)
    if remaining:raise RuntimeError('Project processes did not stop: '+str(remaining))
    return len(initial)

if __name__=='__main__':
    # This utility is also protected by the project's existing exclusive lock.
    import fcntl
    with (ROOT/'project.lock').open('a') as lock:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:raise SystemExit('The main project is running; stop its terminal with Ctrl+C first.')
        stop_processes(legacy=True)
