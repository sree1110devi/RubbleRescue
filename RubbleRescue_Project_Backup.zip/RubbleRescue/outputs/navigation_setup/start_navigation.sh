#!/usr/bin/env bash
# Requires Gazebo, simulation-reference mapping, and the odom->base_link TF bridge.
# Start only one Nav2 instance. Keep teleop idle while navigating.
set -e
source /opt/ros/jazzy/setup.bash
source /home/sreedevi-k/rubblerescue_ws/install/setup.bash
exec ros2 launch /home/sreedevi-k/Documents/Codex/2026-11-18/th/outputs/navigation_setup/rescue_navigation.launch.py
