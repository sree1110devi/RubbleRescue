#!/usr/bin/env python3
"""Revisit known mannequin candidates using Nav2. Not unknown-area search.
Requires existing live map, simulation pose reference, Nav2, detector and registry.
No map or registry file is saved. --output optionally records the test summary.
"""
import argparse,json,math,time,signal
from pathlib import Path
import numpy as np,rclpy,tf2_ros
from rclpy.node import Node
from rclpy.parameter import Parameter
from rclpy.signals import SignalHandlerOptions
from rclpy.qos import QoSProfile,DurabilityPolicy
from rclpy.action import ActionClient
from nav2_msgs.action import NavigateToPose
from nav_msgs.msg import OccupancyGrid
from geometry_msgs.msg import Twist
from std_msgs.msg import String

VIEWPOINTS={'S01':(2.65,3.81),'S02':(-4.5,-3.5),'S03':(-4.5,1.1)}
class Mission(Node):
 def __init__(self):
  super().__init__('candidate_inspection_mission',parameter_overrides=[Parameter('use_sim_time',value=True)])
  self.state={};self.transit_results=[];self.buf=tf2_ros.Buffer();self.listener=tf2_ros.TransformListener(self.buf,self);self.goal_handle=None;self.recoveries=0;self.last_feedback=0
  self.client=ActionClient(self,NavigateToPose,'/navigate_to_pose');self.stop=self.create_publisher(Twist,'/cmd_vel',10)
  latched=QoSProfile(depth=1,durability=DurabilityPolicy.TRANSIENT_LOCAL)
  self.create_subscription(OccupancyGrid,'/map',lambda m:self.state.update(map=m),latched)
  self.create_subscription(String,'/survivor_candidates/registry',lambda m:self.receive('registry',m),latched)
  self.create_subscription(String,'/survivor_candidates/report',lambda m:self.receive('report',m),10)
 def receive(self,key,m):
  try:self.state[key]=json.loads(m.data);self.state[key+'_received']=time.monotonic()
  except ValueError:pass
 def spin_for(self,seconds):
  end=time.monotonic()+seconds
  while time.monotonic()<end:rclpy.spin_once(self,timeout_sec=.1)
 def initialize(self):
  assert self.client.wait_for_server(timeout_sec=15),'Nav2 is not available'
  end=time.monotonic()+15
  while time.monotonic()<end:
   rclpy.spin_once(self,timeout_sec=.1)
   if all(k in self.state for k in ['map','registry']) and self.buf.can_transform('map','base_link',rclpy.time.Time()):break
  assert all(k in self.state for k in ['map','registry']),'Map or candidate registry is unavailable'
  t=self.buf.lookup_transform('map','gazebo_odom',rclpy.time.Time()).transform
  assert math.hypot(t.translation.x,t.translation.y)<.05 and abs(t.rotation.z)<.02,'Known viewpoints require the validated simulation map reference'
 def check_view(self,x,y):
  m=self.state['map'];g=np.asarray(m.data).reshape(m.info.height,m.info.width)
  for dx in np.linspace(-.55,.55,11):
   for dy in np.linspace(-.55,.55,11):
    if dx*dx+dy*dy>.55*.55:continue
    ix=int((x+dx-m.info.origin.position.x)/m.info.resolution);iy=int((y+dy-m.info.origin.position.y)/m.info.resolution)
    assert 0<=ix<g.shape[1] and 0<=iy<g.shape[0] and 0<=g[iy,ix]<50,('Inspection viewpoint is not known free',x+dx,y+dy)
 def feedback(self,m):
  self.recoveries=m.feedback.number_of_recoveries
  if time.monotonic()-self.last_feedback>8:
   print('NAVIGATION_FEEDBACK',json.dumps({'remaining_m':round(m.feedback.distance_remaining,3),'recoveries':self.recoveries}),flush=True);self.last_feedback=time.monotonic()
 def cancel(self):
  if self.goal_handle:
   f=self.goal_handle.cancel_goal_async();rclpy.spin_until_future_complete(self,f,timeout_sec=4);self.goal_handle=None
  for _ in range(6):self.stop.publish(Twist());rclpy.spin_once(self,timeout_sec=.05)
 def transit(self,x,y,yaw,tag):
  self.check_view(x,y)
  goal=NavigateToPose.Goal();goal.pose.header.frame_id='map';goal.pose.header.stamp=self.get_clock().now().to_msg();goal.pose.pose.position.x=x;goal.pose.pose.position.y=y;goal.pose.pose.orientation.z=math.sin(yaw/2);goal.pose.pose.orientation.w=math.cos(yaw/2)
  print('TRANSIT_START',tag,[x,y,yaw],flush=True)
  self.recoveries=0;f=self.client.send_goal_async(goal,feedback_callback=self.feedback);rclpy.spin_until_future_complete(self,f,timeout_sec=10);self.goal_handle=f.result();assert self.goal_handle and self.goal_handle.accepted,'Transit rejected'
  result=self.goal_handle.get_result_async();deadline=time.monotonic()+getattr(self,'transit_timeout',480)
  while not result.done() and time.monotonic()<deadline and self.recoveries<getattr(self,'transit_recovery_limit',2):rclpy.spin_once(self,timeout_sec=.1)
  if not result.done():self.cancel();raise RuntimeError('Transit timeout or repeated recovery: '+tag)
  r=result.result();self.goal_handle=None;t=self.buf.lookup_transform('map','base_link',rclpy.time.Time()).transform;error=math.hypot(t.translation.x-x,t.translation.y-y)
  transit_result={'tag':tag,'status':r.status,'error_m':error,'recoveries':self.recoveries};self.transit_results.append(transit_result);print('TRANSIT_RESULT',json.dumps(transit_result),flush=True)
  if r.status!=4 or error>.2:raise RuntimeError('Transit failed: '+tag)
 def inspect(self,label):
  record=next((r for r in self.state['registry']['candidates'] if r['label']==label),None)
  assert record,'Candidate '+label+' is not in the registry'
  if label=='S01':
   current=self.buf.lookup_transform('map','base_link',rclpy.time.Time()).transform.translation
   if current.x<-1.2 and current.y<0:
    self.transit(0.,-3.5,0.,'front_hallway')
    self.transit(0.,3.5,math.pi/2,'rear_hallway')
  x,y=VIEWPOINTS[label];self.check_view(x,y);target=record['position'];yaw=math.atan2(target[1]-y,target[0]-x);baseline_seen=record['last_seen_sim_s'];baseline_count=len(self.state['registry']['candidates'])
  print('INSPECTION_START',json.dumps({'label':label,'viewpoint':[x,y,yaw],'previous_candidate_position':target,'previous_last_seen':baseline_seen}),flush=True)
  goal=NavigateToPose.Goal();goal.pose.header.frame_id='map';goal.pose.header.stamp=self.get_clock().now().to_msg();goal.pose.pose.position.x=x;goal.pose.pose.position.y=y;goal.pose.pose.orientation.z=math.sin(yaw/2);goal.pose.pose.orientation.w=math.cos(yaw/2)
  self.recoveries=0;f=self.client.send_goal_async(goal,feedback_callback=self.feedback);rclpy.spin_until_future_complete(self,f,timeout_sec=10);self.goal_handle=f.result();assert self.goal_handle and self.goal_handle.accepted,'Nav2 rejected goal'
  result=self.goal_handle.get_result_async();deadline=time.monotonic()+getattr(self,'transit_timeout',480)
  while not result.done() and time.monotonic()<deadline and self.recoveries<getattr(self,'transit_recovery_limit',2):rclpy.spin_once(self,timeout_sec=.1)
  if not result.done():self.cancel();raise RuntimeError('Stopped '+label+': timeout or repeated recovery')
  r=result.result();self.goal_handle=None
  t=self.buf.lookup_transform('map','base_link',rclpy.time.Time()).transform;error=math.hypot(t.translation.x-x,t.translation.y-y)
  passed=r.status==4 and error<=.2
  print('NAVIGATION_RESULT',json.dumps({'label':label,'status':r.status,'position_error_m':error,'final_xy':[t.translation.x,t.translation.y],'recoveries':self.recoveries}),flush=True)
  if not passed:raise RuntimeError('Navigation did not pass for '+label)
  for _ in range(6):self.stop.publish(Twist());rclpy.spin_once(self,timeout_sec=.05)
  inspection_started=time.monotonic();fresh=False;updated=None
  while time.monotonic()-inspection_started<30:
   rclpy.spin_once(self,timeout_sec=.1)
   visible=[c for c in self.state.get('report',{}).get('candidates',[]) if 'map_surface_xyz_m'in c and math.hypot(c['map_surface_xyz_m'][0]-target[0],c['map_surface_xyz_m'][1]-target[1])<.8]
   updated=next((c for c in self.state.get('registry',{}).get('candidates',[]) if c['label']==label),None)
   if visible and self.state.get('report_received',0)>inspection_started and updated and updated['last_seen_sim_s']>baseline_seen:
    fresh=True;break
  count=len(self.state.get('registry',{}).get('candidates',[]));summary={'label':label,'navigation_succeeded':True,'position_error_m':error,'recoveries':self.recoveries,'fresh_camera_detection':fresh,'existing_record_updated':bool(updated and updated['last_seen_sim_s']>baseline_seen),'no_duplicate_added':count==baseline_count,'registry_count':count,'updated_record':updated}
  summary['passed']=summary['fresh_camera_detection'] and summary['existing_record_updated'] and summary['no_duplicate_added'];print('INSPECTION_RESULT',json.dumps(summary),flush=True)
  return summary

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--candidates',nargs='+',choices=list(VIEWPOINTS),default=['S03','S02','S01']);parser.add_argument('--output');args=parser.parse_args()
 rclpy.init(signal_handler_options=SignalHandlerOptions.NO)
 def interrupt(signum,frame):raise KeyboardInterrupt
 signal.signal(signal.SIGINT,interrupt)
 signal.signal(signal.SIGTERM,interrupt)
 n=Mission();results=[];error=None
 try:
  n.initialize()
  for label in args.candidates:
   result=n.inspect(label);results.append(result)
   if not result['passed']:break
 except KeyboardInterrupt:error='Interrupted'
 except Exception as e:error=str(e);print('MISSION_ERROR',error,flush=True)
 finally:
  n.cancel();report={'mission':'known_candidate_reinspection','simulation_reference':True,'requested':args.candidates,'passed':len(results)==len(args.candidates) and all(r['passed'] for r in results) and error is None,'results':results,'transits':n.transit_results,'error':error,'registry':n.state.get('registry',{})};print('MISSION_SUMMARY',json.dumps(report),flush=True)
  if args.output:Path(args.output).write_text(json.dumps(report,indent=2)+'\n')
  n.destroy_node();rclpy.shutdown()
if __name__=='__main__':main()
