RubbleRescue automatic room survey

Start Gazebo, simulation-reference mapping, Nav2, the camera detector and candidate registry first. Keep teleop idle. Do not start a second survey while one is running.

Run:
bash /home/sreedevi-k/Documents/Codex/2026-11-18/th/outputs/navigation_setup/start_room_search.sh

Stop: press Ctrl+C in the terminal running the survey. The runner cancels its current Nav2 navigation/spin goal and sends a zero velocity command.

What it does:
- Validates four configured room viewing stations on the live occupancy map.
- Uses Nav2 to travel through the building's known hallway and room stations.
- Turns in place through six overlapping camera headings per station.
- Holds still for three simulation seconds at each heading.
- Matches camera frames to detector reports by timestamp, then associates them with a unique nearby registry record.
- Updates the local HTML/JSON candidate report and returns to its starting pose.

Outputs:
/home/sreedevi-k/Documents/Codex/2026-11-18/th/outputs/rescue_report/rescue_report.html
/home/sreedevi-k/Documents/Codex/2026-11-18/th/outputs/navigation_setup/room_search_result.json

Scope:
Known-layout room survey on an existing map, using Gazebo reference localization. The route does not use candidate positions. It is not frontier exploration or guaranteed complete visual coverage. Obstacles and viewing angle can hide mannequins. A completed route does not mean all people were found. Candidates remain unconfirmed simulation colour/depth observations. No occupancy map is saved.

Validation notes:
The development test was paused and resumed while adjusting camera stations; the result records that fact. Navigation completion and fresh detections are recorded separately. S03 was missed by the tested coarse sweep, even though earlier targeted inspection detected it. Missing fresh detections must not be treated as evidence that a room is empty.

Final development-test outcome:
All four room sweeps completed; S01 and S02 had fresh sightings. S03 was not reobserved. During return-to-start, the collision-monitor heartbeat was lost and the simulation services subsequently became unavailable. The runner cancelled the goal; completed=false and returned_to_start=false are retained. A clock-loss watchdog now aborts when simulation time stops advancing for 15 wall-clock seconds. Its missing-clock rejection was checked locally; a new full run with restored services is still required.
