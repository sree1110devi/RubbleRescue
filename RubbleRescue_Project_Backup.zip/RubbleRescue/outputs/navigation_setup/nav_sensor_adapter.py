#!/usr/bin/env python3
"""Small depth obstacle cloud + simulation reference velocity for Nav2."""
import math
import numpy as np,rclpy,tf2_ros
from rclpy.node import Node
from rclpy.executors import ExternalShutdownException
from rclpy.parameter import Parameter
from rclpy.qos import qos_profile_sensor_data,QoSProfile,ReliabilityPolicy
from sensor_msgs.msg import PointCloud2,PointField,Image,CameraInfo
from nav_msgs.msg import Odometry
class Adapter(Node):
 def __init__(self):
  super().__init__('rescue_nav_sensor_adapter',parameter_overrides=[Parameter('use_sim_time',value=True)])
  self.tf=tf2_ros.Buffer();self.listener=tf2_ros.TransformListener(self.tf,self);self.prev=None;self.count=0;self.info=None
  self.cloudpub=self.create_publisher(PointCloud2,'/nav2/depth_points',qos_profile_sensor_data)
  self.odpub=self.create_publisher(Odometry,'/nav2/odom',10)
  latest=QoSProfile(depth=1,reliability=ReliabilityPolicy.BEST_EFFORT)
  self.create_subscription(Image,'/rescue_camera/depth_image',self.depth,latest)
  self.create_subscription(CameraInfo,'/rescue_camera/camera_info',lambda m:setattr(self,'info',m),latest)
  self.create_subscription(Odometry,'/mapping_reference/odom',self.odom,20)
 def odom(self,m):
  t=m.header.stamp.sec+m.header.stamp.nanosec*1e-9;q=m.pose.pose.orientation;a=math.atan2(2*(q.w*q.z+q.x*q.y),1-2*(q.y*q.y+q.z*q.z));p=m.pose.pose.position
  if self.prev:
   t0,x0,y0,a0=self.prev;dt=t-t0
   if 0<dt<.5:
    dx=p.x-x0;dy=p.y-y0
    if math.hypot(dx,dy)<.05:
     m.twist.twist.linear.x=(dx*math.cos(a)+dy*math.sin(a))/dt;m.twist.twist.angular.z=math.atan2(math.sin(a-a0),math.cos(a-a0))/dt
  self.prev=(t,p.x,p.y,a);self.odpub.publish(m)
 def depth(self,m):
  if self.info is None:return
  try:
   tf=self.tf.lookup_transform('base_link',m.header.frame_id,rclpy.time.Time.from_msg(m.header.stamp))
   if m.encoding=='32FC1':dtype='>f4' if m.is_bigendian else '<f4';scale=1.
   elif m.encoding=='16UC1':dtype='>u2' if m.is_bigendian else '<u2';scale=.001
   else:return
   z=np.ndarray((m.height,m.width),dtype=dtype,buffer=m.data,strides=(m.step,np.dtype(dtype).itemsize))[::8,::8].astype(np.float32)*scale
   vv,uu=np.meshgrid(np.arange(0,m.height,8),np.arange(0,m.width,8),indexing='ij');fx,fy,cx,cy=self.info.k[0],self.info.k[4],self.info.k[2],self.info.k[5]
   if fx<=0 or fy<=0:return
   valid=np.isfinite(z)&(z>.10)&(z<4.5);zz=z[valid];xyz=np.column_stack(((uu[valid]-cx)*zz/fx,(vv[valid]-cy)*zz/fy,zz)).astype(np.float32)
   q=tf.transform.rotation;x,y,zq,w=q.x,q.y,q.z,q.w
   R=np.array([[1-2*(y*y+zq*zq),2*(x*y-zq*w),2*(x*zq+y*w)],[2*(x*y+zq*w),1-2*(x*x+zq*zq),2*(y*zq-x*w)],[2*(x*zq-y*w),2*(y*zq+x*w),1-2*(x*x+y*y)]])
   t=tf.transform.translation;base=xyz@R.T+np.array([t.x,t.y,t.z])
   inside=(base[:,0]>-.31)&(base[:,0]<.51)&(abs(base[:,1])<.28)&(base[:,2]<.65)&(base[:,2]>-.05)
   xyz=xyz[~inside]
   out=PointCloud2();out.header=m.header;out.height=1;out.width=len(xyz);out.fields=[PointField(name=k,offset=i*4,datatype=PointField.FLOAT32,count=1) for i,k in enumerate(['x','y','z'])];out.is_bigendian=False;out.point_step=12;out.row_step=out.width*12;out.is_dense=True;out.data=xyz.astype('<f4').tobytes();self.cloudpub.publish(out)
   self.count+=1
   if self.count%50==1:self.get_logger().info('Depth-image obstacle cloud: '+str(out.width)+' points.')
  except Exception as e:
   if self.count%50==0:self.get_logger().warn('Waiting for depth transform: '+str(e))
   self.count+=1

def main():
 rclpy.init();n=Adapter()
 try:rclpy.spin(n)
 except (KeyboardInterrupt,ExternalShutdownException):pass
 finally:
  n.destroy_node()
  if rclpy.ok():rclpy.shutdown()
if __name__=='__main__':main()
