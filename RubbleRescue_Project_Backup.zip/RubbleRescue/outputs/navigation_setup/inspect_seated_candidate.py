#!/usr/bin/env python3
"""Nav2 revisit of known seated-candidate viewing point; camera verification required."""
import time,math,json
import numpy as np,rclpy,tf2_ros
from rclpy.node import Node
from rclpy.parameter import Parameter
from rclpy.action import ActionClient
from rclpy.qos import QoSProfile,DurabilityPolicy
from nav2_msgs.action import NavigateToPose
from nav_msgs.msg import OccupancyGrid
from geometry_msgs.msg import Twist
from std_msgs.msg import String
rclpy.init();n=Node('rescue_seated_inspection_test',parameter_overrides=[Parameter('use_sim_time',value=True)])
b=tf2_ros.Buffer();listener=tf2_ros.TransformListener(b,n);stop=n.create_publisher(Twist,'/cmd_vel',10);client=ActionClient(n,NavigateToPose,'/navigate_to_pose');handle=None;done=False;last=0;state={};too_many_recoveries=False
n.create_subscription(OccupancyGrid,'/map',lambda m:state.update(map=m),QoSProfile(depth=1,durability=DurabilityPolicy.TRANSIENT_LOCAL))
def receive(key,msg):
 try:state[key]=json.loads(msg.data);state[key+'_received']=time.monotonic()
 except ValueError:pass
n.create_subscription(String,'/survivor_candidates/registry',lambda m:receive('registry',m),QoSProfile(depth=1,durability=DurabilityPolicy.TRANSIENT_LOCAL))
n.create_subscription(String,'/survivor_candidates/report',lambda m:receive('report',m),10)

try:
 assert client.wait_for_server(timeout_sec=15),'Nav2 action unavailable'
 end=time.monotonic()+12
 while time.monotonic()<end:
  rclpy.spin_once(n,timeout_sec=.1)
  if 'registry' in state and 'map' in state and b.can_transform('map','base_link',rclpy.time.Time()):break
 reference=b.lookup_transform('map','gazebo_odom',rclpy.time.Time()).transform
 assert math.hypot(reference.translation.x,reference.translation.y)<.05 and abs(reference.rotation.z)<.02,'Map reference changed; historical coordinates cannot be reused.'
 t=b.lookup_transform('map','base_link',rclpy.time.Time()).transform;start=(t.translation.x,t.translation.y)
 assert math.hypot(start[0]+3.,start[1]-3.5)<.8,('Robot not near rear-left doorway start',start)
 m=state['map'];grid=np.asarray(m.data).reshape(m.info.height,m.info.width)
 goalxy=(-4.5,1.1)
 records=state['registry']['candidates'];seated=next(r for r in records if r['label']=='S03');baseline_seen=seated['last_seen_sim_s'];baseline_count=len(records);target=seated['position'];target_yaw=math.atan2(target[1]-goalxy[1],target[0]-goalxy[0])
 print('INSPECTING_EXISTING_CANDIDATE',seated,flush=True)
 for frac in np.linspace(0,1,60):
  px=start[0]+frac*(goalxy[0]-start[0]);py=start[1]+frac*(goalxy[1]-start[1])
  for dx in np.linspace(-.55,.55,9):
   for dy in np.linspace(-.55,.55,9):
    if dx*dx+dy*dy>.55*.55:continue
    ix=int((px+dx-m.info.origin.position.x)/m.info.resolution);iy=int((py+dy-m.info.origin.position.y)/m.info.resolution)
    assert 0<=iy<grid.shape[0] and 0<=ix<grid.shape[1] and 0<=grid[iy,ix]<50,('Inspection test envelope not known free',px+dx,py+dy)
 print('MAP_CLEARANCE_PASSED',start,'->',goalxy,flush=True)
 goal=NavigateToPose.Goal();goal.pose.header.frame_id='map';goal.pose.header.stamp=n.get_clock().now().to_msg();goal.pose.pose.position.x=goalxy[0];goal.pose.pose.position.y=goalxy[1];goal.pose.pose.orientation.z=math.sin(target_yaw/2);goal.pose.pose.orientation.w=math.cos(target_yaw/2)
 def feedback(m):
  global last,too_many_recoveries
  too_many_recoveries=m.feedback.number_of_recoveries>=2
  if time.monotonic()-last>4:print('FEEDBACK remaining_m',round(m.feedback.distance_remaining,3),'recoveries',m.feedback.number_of_recoveries,flush=True);last=time.monotonic()
 f=client.send_goal_async(goal,feedback_callback=feedback);rclpy.spin_until_future_complete(n,f,timeout_sec=10);handle=f.result();assert handle and handle.accepted,'Goal rejected'
 result=handle.get_result_async();deadline=time.monotonic()+180
 while not result.done() and time.monotonic()<deadline and not too_many_recoveries:rclpy.spin_once(n,timeout_sec=.1)
 if not result.done():
  f=handle.cancel_goal_async();rclpy.spin_until_future_complete(n,f,timeout_sec=5);raise RuntimeError('Inspection navigation stopped: timeout or repeated recovery')
 r=result.result();done=True;t=b.lookup_transform('map','base_link',rclpy.time.Time()).transform;q=t.rotation;yaw=math.atan2(2*(q.w*q.z+q.x*q.y),1-2*(q.y*q.y+q.z*q.z));error=math.hypot(t.translation.x-goalxy[0],t.translation.y-goalxy[1])
 navigation_passed=r.status==4 and error<=.20
 print('NAVIGATION_RESULT',json.dumps({'passed':navigation_passed,'action_status':r.status,'error_code':r.result.error_code,'start_xy':start,'goal_xy':goalxy,'final_xy':[t.translation.x,t.translation.y],'final_yaw_rad':yaw,'position_error_m':error}),flush=True)
 inspection_start=time.monotonic();fresh=False;updated=None
 if navigation_passed:
  for _ in range(5):stop.publish(Twist());rclpy.spin_once(n,timeout_sec=.05)
  while time.monotonic()-inspection_start<25:
   rclpy.spin_once(n,timeout_sec=.1)
   candidates=state.get('report',{}).get('candidates',[])
   matches=[c for c in candidates if 'map_surface_xyz_m'in c and math.hypot(c['map_surface_xyz_m'][0]-target[0],c['map_surface_xyz_m'][1]-target[1])<.8]
   record=next((c for c in state.get('registry',{}).get('candidates',[]) if c['label']=='S03'),None)
   if matches and state.get('report_received',0)>inspection_start and record and record['last_seen_sim_s']>baseline_seen:
    fresh=True;updated=record;break
 no_duplicate=len(state.get('registry',{}).get('candidates',[]))==baseline_count
 print('INSPECTION_SUMMARY',json.dumps({'passed':navigation_passed and fresh and no_duplicate,'navigation_passed':navigation_passed,'fresh_camera_detection':fresh,'existing_S03_updated':updated,'registry_count':len(state.get('registry',{}).get('candidates',[])),'no_new_registry_location':no_duplicate,'position_error_m':error}),flush=True)

finally:
 if handle and not done:
  f=handle.cancel_goal_async();rclpy.spin_until_future_complete(n,f,timeout_sec=3)
 for _ in range(10):stop.publish(Twist());rclpy.spin_once(n,timeout_sec=.05)
 n.destroy_node();rclpy.shutdown()
