#!/usr/bin/env python3
"""Survey four known room regions; no candidate positions are used for navigation."""
import argparse,json,math,signal,time,sys
from pathlib import Path
from candidate_inspection_mission import Mission
import rclpy
from rclpy.signals import SignalHandlerOptions
from rclpy.action import ActionClient
from nav2_msgs.action import Spin
from rosgraph_msgs.msg import Clock as ClockMessage
from rclpy.clock import Clock,ClockType
from rclpy.qos import qos_profile_sensor_data
from rclpy.executors import SingleThreadedExecutor
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'rescue_report'))
from create_rescue_report import Report,associate,stamp

# Known building entry/view stations, independent of the candidate registry.
# This is a room survey on an existing map, not frontier exploration.
ROUTE=[('rear_right',2.65,3.81),('rear_hall',0.,3.5),
       ('rear_left',-4.5,1.1),('front_left',-4.5,-3.5),
       ('front_hall',0.,-3.5),('front_right',2.65,-3.5),
       ('return_front_hall',0.,-3.5),('return_rear_hall',0.,3.5)]
class Search(Mission):
    def __init__(self):
        super().__init__();self.reporter=Report();self.report_executor=SingleThreadedExecutor();self.report_executor.add_node(self.reporter)
        self.rooms=[];self.sightings={};self.started_sim=None;self.turn_client=ActionClient(self,Spin,"/spin")
        self.last_clock=time.monotonic();self.last_clock_stamp=None
        self.create_subscription(ClockMessage,'/clock',self.clock_received,qos_profile_sensor_data)
        self.create_timer(1.,self.check_clock,clock=Clock(clock_type=ClockType.STEADY_TIME))
    def clock_received(self,msg):
        value=msg.clock.sec+msg.clock.nanosec*1e-9
        if value!=self.last_clock_stamp:self.last_clock=time.monotonic();self.last_clock_stamp=value
    def check_clock(self):
        if time.monotonic()-self.last_clock>(45 if self.last_clock_stamp is None else 15):raise RuntimeError('Simulation clock stopped or became unavailable; survey cancelled')
    def pump(self,seconds):
        end=time.monotonic()+seconds
        while time.monotonic()<end:
            rclpy.spin_once(self,timeout_sec=.03);self.report_executor.spin_once(timeout_sec=.03)
    def turn(self,yaw):
        t=self.buf.lookup_transform('map','base_link',rclpy.time.Time()).transform;q=t.rotation
        current=math.atan2(2*q.w*q.z,1-2*q.z*q.z);delta=math.atan2(math.sin(yaw-current),math.cos(yaw-current))
        if abs(delta)<.08:return
        assert self.turn_client.wait_for_server(timeout_sec=5),'Nav2 spin is unavailable'
        goal=Spin.Goal();goal.target_yaw=delta;goal.time_allowance.sec=35
        f=self.turn_client.send_goal_async(goal);rclpy.spin_until_future_complete(self,f,timeout_sec=8)
        self.goal_handle=f.result();assert self.goal_handle and self.goal_handle.accepted,'Spin rejected'
        result=self.goal_handle.get_result_async();deadline=time.monotonic()+150
        while not result.done() and time.monotonic()<deadline:self.pump(.1)
        if not result.done():self.cancel();raise RuntimeError('Camera sweep turn timed out')
        status=result.result();self.goal_handle=None
        if status.status!=4 or status.result.error_code:raise RuntimeError('Camera sweep blocked: '+str(status.result.error_msg))
        print('TURN_COMPLETE',json.dumps({'target_heading':yaw,'status':status.status}),flush=True)
    def scan(self,name,x,y):
        room={'room':name,'station':[x,y],'views':[]};self.rooms.append(room)
        for index in range(6):
            yaw=(index+.5)*math.pi/3
            self.turn(yaw)
            arrived=self.get_clock().now().nanoseconds/1e9
            # Hold still for 3 simulated seconds (registry requires one second).
            end=time.monotonic()+30
            while self.get_clock().now().nanoseconds/1e9-arrived<3 and time.monotonic()<end:self.pump(.15)
            if self.get_clock().now().nanoseconds/1e9-arrived<3:raise RuntimeError('Simulation clock stalled during inspection')
            self.pump(1)
            labels=[]
            for label,snapshot in self.reporter.snapshots.items():
                if snapshot['simulation_seconds']>=arrived:
                    labels.append(label);self.sightings[label]={'room':name,'image_sim_s':snapshot['simulation_seconds']}
            room['views'].append({'heading_rad':yaw,'fresh_candidates':labels})
            self.reporter.write()
            print('ROOM_VIEW',json.dumps({'room':name,'heading':index+1,'fresh_candidates':labels}),flush=True)
        room['completed']=True
        print('ROOM_COMPLETE',json.dumps(room),flush=True)
    def close(self):
        self.last_clock=time.monotonic()+60
        self.cancel()
        if self.reporter.registry:self.reporter.write()
        self.report_executor.remove_node(self.reporter);self.reporter.destroy_node();self.report_executor.shutdown();self.destroy_node()

def main():
    parser=argparse.ArgumentParser();parser.add_argument("--resume");args=parser.parse_args()
    rclpy.init(signal_handler_options=SignalHandlerOptions.NO)
    def interrupt(signum,frame):raise KeyboardInterrupt
    signal.signal(signal.SIGINT,interrupt);signal.signal(signal.SIGTERM,interrupt)
    n=Search();error=None;returned=False
    output=Path(__file__).with_name('room_search_result.json')
    try:
        n.initialize();n.pump(2)
        t=n.buf.lookup_transform('map','base_link',rclpy.time.Time()).transform;p=t.translation;q=t.rotation
        original=(p.x,p.y,math.atan2(2*q.w*q.z,1-2*q.z*q.z))
        resumed=False
        if args.resume:
            saved=json.loads(Path(args.resume).read_text());original=tuple(saved['start_pose']);n.rooms=saved['rooms'];resumed=True
            for room in n.rooms:
                for view in room['views']:
                    for label in view['fresh_candidates']:n.sightings[label]={'room':room['room'],'from_completed_checkpoint':True}
        # Validate every station before moving; Nav2 checks the connecting routes.
        for _,x,y in ROUTE:n.check_view(x,y)
        print('SEARCH_START',json.dumps({'route':ROUTE,'candidate_positions_used_for_navigation':False,'start_pose':original}),flush=True)
        route=ROUTE[2:] if args.resume else ROUTE
        for name,x,y in route:
            p=n.buf.lookup_transform('map','base_link',rclpy.time.Time()).transform.translation
            travel_heading=math.atan2(y-p.y,x-p.x)
            n.transit(x,y,travel_heading,name+'_arrival')
            if name in {'rear_right','rear_left','front_left','front_right'}:n.scan(name,x,y)
            else:n.pump(.3)
        n.transit(*original,'return_to_start');returned=True
    except KeyboardInterrupt:error='Interrupted'
    except Exception as e:error=str(e);print('SEARCH_ERROR',error,flush=True)
    finally:
        signal.signal(signal.SIGINT,signal.SIG_IGN);signal.signal(signal.SIGTERM,signal.SIG_IGN)
        result={'unobserved_registered_labels':sorted({r['label'] for r in n.state.get('registry',{}).get('candidates',[])}-set(n.sightings)),'visual_coverage_guaranteed':False,'resumed_from_checkpoint':bool(args.resume),'mode':'known_layout_room_survey','simulation_reference':True,'candidate_positions_used_for_navigation':False,'rooms':n.rooms,'fresh_camera_sightings':n.sightings,'returned_to_start':returned,'navigation':n.transit_results,'error':error,'completed':returned and len(n.rooms)==4 and all(r.get('completed') for r in n.rooms) and error is None}
        output.write_text(json.dumps(result,indent=2)+'\n');print('SEARCH_RESULT',json.dumps(result),flush=True);n.close();rclpy.shutdown()
if __name__=='__main__':main()
