import rclpy
from rclpy.node import Node
from action_msgs.srv import CancelGoal
from geometry_msgs.msg import Twist
rclpy.init();n=Node('rescue_nav_cancel');c=n.create_client(CancelGoal,'/navigate_to_pose/_action/cancel_goal')
if c.wait_for_service(timeout_sec=5):
 f=c.call_async(CancelGoal.Request());rclpy.spin_until_future_complete(n,f,timeout_sec=5);print('CANCEL',f.result(),flush=True)
p=n.create_publisher(Twist,'/cmd_vel',10)
for _ in range(10):p.publish(Twist());rclpy.spin_once(n,timeout_sec=.05)
n.destroy_node();rclpy.shutdown()
