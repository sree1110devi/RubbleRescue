#!/usr/bin/env bash
set -eo pipefail
source /opt/ros/jazzy/setup.bash
export ROS_LOG_DIR=/home/sreedevi-k/Documents/Codex/2026-11-18/th/work/ros_logs
export FASTRTPS_DEFAULT_PROFILES_FILE=/home/sreedevi-k/Documents/Codex/2026-11-18/th/work/ros_udp.xml
# Only one survey runner may command this route at a time.
exec flock -n /home/sreedevi-k/Documents/Codex/2026-11-18/th/work/room_search.lock python3 /home/sreedevi-k/Documents/Codex/2026-11-18/th/outputs/navigation_setup/room_search_mission.py
