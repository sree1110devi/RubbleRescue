from pathlib import Path
import os
from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import ExecuteProcess, Shutdown

def generate_launch_description():
 folder=Path(__file__).resolve().parent;params=os.environ.get('RUBBLE_NAV_PARAMS',str(folder/'nav2_params.yaml'))
 nodes=[ExecuteProcess(cmd=['python3',str(folder/'nav_sensor_adapter.py')]+(['--ros-args','-r','/mapping_reference/odom:='+('/odometry/filtered' if os.environ.get('RUBBLE_IMU_ODOMETRY')=='1' else '/odom')] if os.environ.get('RUBBLE_AUTONOMOUS')=='1' else []),output='screen',on_exit=[Shutdown(reason='Navigation sensor adapter exited')])]
 specs=[('nav2_controller','controller_server','controller_server',[('cmd_vel','/nav2/cmd_vel_raw'),('odom','/nav2/odom')]),('nav2_planner','planner_server','planner_server',[]),('nav2_behaviors','behavior_server','behavior_server',[('cmd_vel','/nav2/cmd_vel_raw')]),('nav2_bt_navigator','bt_navigator','bt_navigator',[]),('nav2_velocity_smoother','velocity_smoother','velocity_smoother',[('cmd_vel','/nav2/cmd_vel_raw'),('cmd_vel_smoothed','/nav2/cmd_vel_smoothed')]),('nav2_collision_monitor','collision_monitor','collision_monitor',[])]
 for pkg,exe,name,remaps in specs:nodes.append(Node(package=pkg,executable=exe,name=name,output='screen',parameters=[params],remappings=remaps,on_exit=[Shutdown(reason='Critical navigation node exited: '+name)]))
 nodes.append(Node(package='nav2_lifecycle_manager',executable='lifecycle_manager',name='lifecycle_manager_rescue_navigation',output='screen',parameters=[{'use_sim_time':True,'autostart':True,'bond_timeout':10.,'node_names':[s[2] for s in specs]}]))
 return LaunchDescription(nodes)
