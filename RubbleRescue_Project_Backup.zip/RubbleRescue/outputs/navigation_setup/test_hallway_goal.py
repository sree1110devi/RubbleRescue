#!/usr/bin/env python3
"""Bounded simulation test: only run with robot staged at (0,-2), heading +Y."""
import time,math,json
import rclpy,tf2_ros
from rclpy.node import Node
from rclpy.parameter import Parameter
from rclpy.action import ActionClient
from nav2_msgs.action import NavigateToPose
from geometry_msgs.msg import Twist
rclpy.init();n=Node('rescue_hallway_goal_test',parameter_overrides=[Parameter('use_sim_time',value=True)])
b=tf2_ros.Buffer();listener=tf2_ros.TransformListener(b,n);stop=n.create_publisher(Twist,'/cmd_vel',10);client=ActionClient(n,NavigateToPose,'/navigate_to_pose');handle=None;success=False;last=0
try:
 assert client.wait_for_server(timeout_sec=20),'NavigateToPose action unavailable'
 end=time.monotonic()+6
 while time.monotonic()<end:rclpy.spin_once(n,timeout_sec=.1)
 t=b.lookup_transform('map','base_link',rclpy.time.Time()).transform
 start=(t.translation.x,t.translation.y);assert math.hypot(start[0],start[1]+2)<.3,('Robot is not at staged hallway start',start)
 print('START',start,flush=True)
 goal=NavigateToPose.Goal();goal.pose.header.frame_id='map';goal.pose.header.stamp=n.get_clock().now().to_msg();goal.pose.pose.position.x=0.;goal.pose.pose.position.y=-.8;goal.pose.pose.orientation.z=math.sin(math.pi/4);goal.pose.pose.orientation.w=math.cos(math.pi/4)
 def feedback(m):
  global last
  if time.monotonic()-last>3:print('FEEDBACK remaining_m',round(m.feedback.distance_remaining,3),'recoveries',m.feedback.number_of_recoveries,flush=True);last=time.monotonic()
 f=client.send_goal_async(goal,feedback_callback=feedback);rclpy.spin_until_future_complete(n,f,timeout_sec=10);handle=f.result();assert handle and handle.accepted,'Goal rejected'
 result=handle.get_result_async();deadline=time.monotonic()+120
 while not result.done() and time.monotonic()<deadline:rclpy.spin_once(n,timeout_sec=.1)
 if not result.done():
  f=handle.cancel_goal_async();rclpy.spin_until_future_complete(n,f,timeout_sec=5);raise RuntimeError('Goal timed out; cancelled')
 r=result.result();print('ACTION_RESULT',r,flush=True)
 t=b.lookup_transform('map','base_link',rclpy.time.Time()).transform;q=t.rotation;yaw=math.atan2(2*(q.w*q.z+q.x*q.y),1-2*(q.y*q.y+q.z*q.z));distance=math.hypot(t.translation.x,t.translation.y+.8)
 success=r.status==4 and distance<=.20
 print('TEST_SUMMARY',json.dumps({'passed':success,'action_status':r.status,'error_code':r.result.error_code,'start_xy':start,'final_xy':[t.translation.x,t.translation.y],'final_yaw_rad':yaw,'position_error_m':distance,'travelled_displacement_m':math.hypot(t.translation.x-start[0],t.translation.y-start[1])}),flush=True)
finally:
 for _ in range(10):stop.publish(Twist());rclpy.spin_once(n,timeout_sec=.05)
 n.destroy_node();rclpy.shutdown()
