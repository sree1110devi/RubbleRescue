#!/usr/bin/env python3
"""Bounded Nav2 test from rear hallway through rear-left room doorway."""
import time,math,json
import numpy as np,rclpy,tf2_ros
from rclpy.node import Node
from rclpy.parameter import Parameter
from rclpy.action import ActionClient
from rclpy.qos import QoSProfile,DurabilityPolicy
from nav2_msgs.action import NavigateToPose
from nav_msgs.msg import OccupancyGrid
from geometry_msgs.msg import Twist
rclpy.init();n=Node('rescue_doorway_goal_test',parameter_overrides=[Parameter('use_sim_time',value=True)])
b=tf2_ros.Buffer();listener=tf2_ros.TransformListener(b,n);stop=n.create_publisher(Twist,'/cmd_vel',10);client=ActionClient(n,NavigateToPose,'/navigate_to_pose');handle=None;done=False;last=0;state={};too_many_recoveries=False
n.create_subscription(OccupancyGrid,'/map',lambda m:state.update(map=m),QoSProfile(depth=1,durability=DurabilityPolicy.TRANSIENT_LOCAL))
try:
 assert client.wait_for_server(timeout_sec=15),'Nav2 action unavailable'
 end=time.monotonic()+5
 while time.monotonic()<end:rclpy.spin_once(n,timeout_sec=.1)
 t=b.lookup_transform('map','base_link',rclpy.time.Time()).transform;start=(t.translation.x,t.translation.y)
 assert math.hypot(start[0],start[1]-3.9)<.8,('Robot not near rear hallway test start',start)
 m=state['map'];grid=np.asarray(m.data).reshape(m.info.height,m.info.width)
 goalxy=(-3.,3.5)
 for frac in np.linspace(0,1,60):
  px=start[0]+frac*(goalxy[0]-start[0]);py=start[1]+frac*(goalxy[1]-start[1])
  for dx in np.linspace(-.55,.55,9):
   for dy in np.linspace(-.55,.55,9):
    if dx*dx+dy*dy>.55*.55:continue
    ix=int((px+dx-m.info.origin.position.x)/m.info.resolution);iy=int((py+dy-m.info.origin.position.y)/m.info.resolution)
    assert 0<=iy<grid.shape[0] and 0<=ix<grid.shape[1] and 0<=grid[iy,ix]<50,('Doorway test envelope not known free',px+dx,py+dy)
 print('MAP_CLEARANCE_PASSED',start,'->',goalxy,flush=True)
 goal=NavigateToPose.Goal();goal.pose.header.frame_id='map';goal.pose.header.stamp=n.get_clock().now().to_msg();goal.pose.pose.position.x=goalxy[0];goal.pose.pose.position.y=goalxy[1];goal.pose.pose.orientation.z=1.;goal.pose.pose.orientation.w=0.
 def feedback(m):
  global last,too_many_recoveries
  too_many_recoveries=m.feedback.number_of_recoveries>=2
  if time.monotonic()-last>4:print('FEEDBACK remaining_m',round(m.feedback.distance_remaining,3),'recoveries',m.feedback.number_of_recoveries,flush=True);last=time.monotonic()
 f=client.send_goal_async(goal,feedback_callback=feedback);rclpy.spin_until_future_complete(n,f,timeout_sec=10);handle=f.result();assert handle and handle.accepted,'Goal rejected'
 result=handle.get_result_async();deadline=time.monotonic()+180
 while not result.done() and time.monotonic()<deadline and not too_many_recoveries:rclpy.spin_once(n,timeout_sec=.1)
 if not result.done():
  f=handle.cancel_goal_async();rclpy.spin_until_future_complete(n,f,timeout_sec=5);raise RuntimeError('Doorway test stopped: timeout or repeated recovery')
 r=result.result();done=True;t=b.lookup_transform('map','base_link',rclpy.time.Time()).transform;q=t.rotation;yaw=math.atan2(2*(q.w*q.z+q.x*q.y),1-2*(q.y*q.y+q.z*q.z));error=math.hypot(t.translation.x-goalxy[0],t.translation.y-goalxy[1])
 print('TEST_SUMMARY',json.dumps({'passed':r.status==4 and error<=.20,'action_status':r.status,'error_code':r.result.error_code,'start_xy':start,'goal_xy':goalxy,'final_xy':[t.translation.x,t.translation.y],'final_yaw_rad':yaw,'position_error_m':error,'recoveries_at_least_two':too_many_recoveries}),flush=True)
finally:
 if handle and not done:
  f=handle.cancel_goal_async();rclpy.spin_until_future_complete(n,f,timeout_sec=3)
 for _ in range(10):stop.publish(Twist());rclpy.spin_once(n,timeout_sec=.05)
 n.destroy_node();rclpy.shutdown()
