#!/usr/bin/env bash
# Requires running Gazebo and robot odom->base_link transform bridge.
# Uses Gazebo pose reference; not autonomous localization. Creates a fresh unsaved map.
set -e
source /opt/ros/jazzy/setup.bash
source /home/sreedevi-k/rubblerescue_ws/install/setup.bash
exec python3 /home/sreedevi-k/Documents/Codex/2026-11-18/th/outputs/mapping_repair/start_reference_session.py
