#!/usr/bin/env python3
import subprocess,sys,time,signal,os
from pathlib import Path
import rclpy
from rclpy.node import Node
from lifecycle_msgs.srv import ChangeState,GetState
from rcl_interfaces.srv import GetParameters
rclpy.init();n=Node('reference_mapping_manager');children=[]
folder=Path(__file__).resolve().parent

def call(kind,path,request,timeout=12):
 c=n.create_client(kind,path)
 if not c.wait_for_service(timeout_sec=timeout):raise RuntimeError('Service unavailable: '+path)
 f=c.call_async(request);rclpy.spin_until_future_complete(n,f,timeout_sec=timeout)
 if not f.done() or f.result() is None:raise RuntimeError('No response: '+path)
 return f.result()
def transition(name,value):
 q=ChangeState.Request();q.transition.id=value;r=call(ChangeState,name+'/change_state',q);assert r.success,(name,value,r)
try:
 end=time.monotonic()+3
 while time.monotonic()<end:rclpy.spin_once(n,timeout_sec=.1)
 names=n.get_node_names()
 if 'rescue_reference_mapper' in names:
  try:existing=call(GetState,'/rescue_reference_mapper/get_state',GetState.Request(),timeout=2)
  except RuntimeError:print('Ignoring stale discovery entry for an exited mapper.',flush=True)
  else:raise RuntimeError('Reference mapper already running; do not start a duplicate.')
 if 'slam_toolbox' in names:
  state=call(GetState,'/slam_toolbox/get_state',GetState.Request()).current_state.id
  if state==3:transition('/slam_toolbox',4);print('Paused old SLAM instance to avoid competing map transforms.',flush=True)
 if os.environ.get('RUBBLERESCUE_MANAGED_RUN')=='1' or 'gazebo_mapping_reference' not in names:
  children.append(subprocess.Popen([sys.executable,str(folder/'gazebo_pose_reference.py')]))
 children.append(subprocess.Popen(['/opt/ros/jazzy/lib/slam_toolbox/async_slam_toolbox_node','--ros-args','-r','__node:=rescue_reference_mapper','--params-file',str(folder/'reference_mapper_params.yaml'),'-r','/slam_toolbox/reset:=/rescue_reference_mapper/reset','-r','/slam_toolbox/pause_new_measurements:=/rescue_reference_mapper/pause_new_measurements']))
 transition('/rescue_reference_mapper',1)
 q=GetParameters.Request();q.names=['odom_frame','base_frame','use_scan_matching'];r=call(GetParameters,'/rescue_reference_mapper/get_parameters',q)
 assert r.values[0].string_value=='gazebo_odom' and r.values[1].string_value=='base_link' and not r.values[2].bool_value, r
 transition('/rescue_reference_mapper',3)
 print('VERIFIED: rescue_reference_mapper active; odom_frame=gazebo_odom; no wheel-odometry map publisher active. Keep this terminal open. No map is saved.',flush=True)
 while rclpy.ok():
  rclpy.spin_once(n,timeout_sec=.5)
  if children[-1].poll() is not None:raise RuntimeError('Reference mapper exited.')
except KeyboardInterrupt:pass
finally:
 for child in children:
  if child.poll() is None:child.send_signal(signal.SIGINT)
 for child in children:
  try:child.wait(timeout=5)
  except subprocess.TimeoutExpired:child.terminate()
 n.destroy_node();rclpy.shutdown()
