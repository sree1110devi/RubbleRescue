#!/usr/bin/env python3
"""Simulation-only Gazebo pose reference for mapping. Not wheel odometry."""
import math,threading,collections
import rclpy
from rclpy.node import Node
from rclpy.parameter import Parameter
from nav_msgs.msg import Odometry
from geometry_msgs.msg import TransformStamped
from tf2_ros import TransformBroadcaster
from gz.transport13 import Node as GzNode
from gz.msgs10.pose_v_pb2 import Pose_V

def yaw(q):return math.atan2(2*(q.w*q.z+q.x*q.y),1-2*(q.y*q.y+q.z*q.z))
def wrap(v):return math.atan2(math.sin(v),math.cos(v))
class Reference(Node):
 def __init__(self):
  super().__init__('gazebo_mapping_reference',parameter_overrides=[Parameter('use_sim_time',value=True)])
  self.history=collections.deque(maxlen=300);self.pending=collections.deque(maxlen=300);self.lock=threading.Lock();self.tf=TransformBroadcaster(self);self.pub=self.create_publisher(Odometry,'/mapping_reference/odom',10)
  self.create_subscription(Odometry,'/odom',self.odom,100)
  self.gz=GzNode();assert self.gz.subscribe(Pose_V,'/world/rubble_world/dynamic_pose/info',self.truth)
  self.create_timer(.01,self.tick);self.get_logger().warn('SIMULATION REFERENCE: Gazebo ground-truth pose supplies gazebo_odom -> odom. This does not repair wheel odometry or demonstrate autonomous localization.')
 def odom(self,m):
  sec=m.header.stamp.sec+m.header.stamp.nanosec*1e-9;p=m.pose.pose
  self.history.append((sec,p.position.x,p.position.y,yaw(p.orientation)))
 def truth(self,m):
  for p in m.pose:
   if p.name=='rubblerescue':
    with self.lock:self.pending.append((m.header.stamp.sec,m.header.stamp.nsec,p.position.x,p.position.y,yaw(p.orientation)))
    break
 def tick(self):
  with self.lock:
   if not self.pending:return
   poses=list(self.pending);self.pending.clear()
  hist=list(self.history)
  if not hist:return
  for sec,ns,x,y,a in poses:
   ts=sec+ns*1e-9
   # Match reference and wheel samples in simulation time to avoid phase error.
   lo=None;hi=None
   for sample in hist:
    if sample[0]<=ts:lo=sample
    elif hi is None:hi=sample;break
   if lo is None:continue
   if hi:
    f=(ts-lo[0])/max(hi[0]-lo[0],1e-9);ox=lo[1]+f*(hi[1]-lo[1]);oy=lo[2]+f*(hi[2]-lo[2]);oa=lo[3]+f*wrap(hi[3]-lo[3])
   elif ts-lo[0]<.08:ox,oy,oa=lo[1:]
   else:continue
   d=wrap(a-oa);t=TransformStamped();t.header.stamp.sec=sec;t.header.stamp.nanosec=ns;t.header.frame_id='gazebo_odom';t.child_frame_id='odom';t.transform.translation.x=x-math.cos(d)*ox+math.sin(d)*oy;t.transform.translation.y=y-math.sin(d)*ox-math.cos(d)*oy;t.transform.rotation.z=math.sin(d/2);t.transform.rotation.w=math.cos(d/2);self.tf.sendTransform(t)
   m=Odometry();m.header=t.header;m.child_frame_id='base_link';m.pose.pose.position.x=x;m.pose.pose.position.y=y;m.pose.pose.orientation.z=math.sin(a/2);m.pose.pose.orientation.w=math.cos(a/2);self.pub.publish(m)
def main():
 rclpy.init();n=Reference()
 try:rclpy.spin(n)
 except KeyboardInterrupt:pass
 finally:n.destroy_node();rclpy.shutdown()
if __name__=='__main__':main()
