# Unsaved — Robot Description

![Unsaved](images/robot.png)

## Overview

| Property | Value |
|----------|-------|
| Total mass | 205.051 kg |
| Links | 15 |
| Joints | 14 (10 movable) |
| Assemblies | 1 |
| Root link | `base_link` |

## Table of Contents

- [Kinematic Tree](#kinematic-tree)
- [Link Properties](#link-properties)
- [Joint Properties](#joint-properties)
- [Assembly Breakdown](#assembly-breakdown)
- [Quick Start (ROS 2)](#quick-start-ros-2)
- [Files](#files)

## Kinematic Tree

```
base_link
  └─ right_track_link_fixed [fixed]
    right_track_link
  └─ left_track_link_fixed [fixed]
    left_track_link
  └─ cage_link_fixed [fixed]
    cage_link
  └─ sensor_link_fixed [fixed]
    sensor_link
  └─ turret_joint [revolute]
    turret_link [BAKE]
      └─ shoulder_joint [revolute]
        upper_arm_link [BAKE]
          └─ elbow_joint [revolute]
            forearm_link [BAKE]
              └─ wrist_joint [revolute]
                wrist_link [BAKE]
                  └─ left_finger_joint [prismatic]
                    left_finger_link [BAKE]
                  └─ right_finger_joint [prismatic]
                    right_finger_link [BAKE]
  └─ left_front_roller_joint [continuous]
    left_front_roller [BAKE]
  └─ left_rear_roller_joint [continuous]
    left_rear_roller [BAKE]
  └─ right_front_roller_joint [continuous]
    right_front_roller [BAKE]
  └─ right_rear_roller_joint [continuous]
    right_rear_roller [BAKE]
```

## Link Properties

| Link | Mass (kg) | Material | Collision | Bodies |
|------|-----------|----------|-----------|--------|
| `base_link` | 97.3822 | Steel | box | 36 |
| `cage_link` | 1.5866 | Steel | box | 8 |
| `forearm_link` | 1.6457 | Steel | box | 5 |
| `left_finger_link` | 0.0916 | Steel | box | 2 |
| `left_front_roller` | 8.5424 | Steel | cylinder | 1 |
| `left_rear_roller` | 8.5424 | Steel | cylinder | 1 |
| `left_track_link` | 30.5562 | Steel | box | 182 |
| `right_finger_link` | 0.0916 | Steel | box | 2 |
| `right_front_roller` | 8.5424 | Steel | cylinder | 1 |
| `right_rear_roller` | 8.5424 | Steel | cylinder | 1 |
| `right_track_link` | 30.5562 | Steel | box | 182 |
| `sensor_link` | 3.7341 | Steel | box | 15 |
| `turret_link` | 2.1637 | Steel | cylinder | 3 |
| `upper_arm_link` | 1.9221 | Steel | box | 5 |
| `wrist_link` | 1.1516 | Steel | box | 5 |

## Joint Properties

| Joint | Type | Parent → Child | Axis | Limits |
|-------|------|---------------|------|--------|
| `cage_link_fixed` | fixed | `base_link` → `cage_link` | (0,0,1) | — |
| `elbow_joint` | revolute | `upper_arm_link` → `forearm_link` | (0,0,1) | [-40.1°, 40.1°] |
| `left_finger_joint` | prismatic | `wrist_link` → `left_finger_link` | (0,0,1) | [-8.0, 25.0] mm |
| `left_front_roller_joint` | continuous | `base_link` → `left_front_roller` | (0,0,1) | — |
| `left_rear_roller_joint` | continuous | `base_link` → `left_rear_roller` | (0,0,1) | — |
| `left_track_link_fixed` | fixed | `base_link` → `left_track_link` | (0,0,1) | — |
| `right_finger_joint` | prismatic | `wrist_link` → `right_finger_link` | (0,0,1) | [-8.0, 25.0] mm |
| `right_front_roller_joint` | continuous | `base_link` → `right_front_roller` | (0,0,1) | — |
| `right_rear_roller_joint` | continuous | `base_link` → `right_rear_roller` | (0,0,1) | — |
| `right_track_link_fixed` | fixed | `base_link` → `right_track_link` | (0,0,1) | — |
| `sensor_link_fixed` | fixed | `base_link` → `sensor_link` | (0,0,1) | — |
| `shoulder_joint` | revolute | `turret_link` → `upper_arm_link` | (0,0,1) | [-37.2°, 25.8°] |
| `turret_joint` | revolute | `base_link` → `turret_link` | (0,0,1) | [-90.0°, 90.0°] |
| `wrist_joint` | revolute | `forearm_link` → `wrist_link` | (0,0,1) | [-40.1°, 40.1°] |

## Assembly Breakdown

### Unsaved

- **Links**: base_link, right_track_link, left_track_link, cage_link, sensor_link, turret_link, upper_arm_link, forearm_link, wrist_link, left_finger_link, right_finger_link, left_front_roller, left_rear_roller, right_front_roller, right_rear_roller
- **Total mass**: 205.051 kg

## Quick Start (ROS 2)

```bash
# 1. Copy package to your ROS 2 workspace
cp -r Unsaved_description ~/ros2_ws/src/

# 2. Build
cd ~/ros2_ws
colcon build --packages-select Unsaved_description
source install/setup.bash

# 3. Visualize in RViz2
ros2 launch Unsaved_description display.launch.py

# 4. Validate URDF structure
check_urdf install/Unsaved_description/share/Unsaved_description/urdf/Unsaved.urdf

# 5. Print kinematic tree
urdf_to_graphviz install/Unsaved_description/share/Unsaved_description/urdf/Unsaved.urdf
```

**Joint control**: The launch file includes `joint_state_publisher_gui` —
use the sliders to move revolute/prismatic joints in RViz2.

**Topic inspection**:
```bash
# See published joint states
ros2 topic echo /joint_states

# See robot description parameter
ros2 param get /robot_state_publisher robot_description
```

## Files

| Path | Description |
|------|-------------|
| `urdf/Unsaved.urdf.xacro` | Top-level xacro (entry point) |
| `urdf/Unsaved.urdf` | Flat URDF (for validation) |
| `urdf/assemblies/` | Per-assembly xacro macros |
| `meshes/` | Visual (OBJ) and collision (STL) meshes |
| `launch/display.launch.py` | Launch robot_state_publisher, RViz, and generated controllers |
| `config/joint_state.yaml` | Joint state publisher config |
| `config/ros2_controllers.yaml` | Generated ros2_control controller manager config |
| `robot_data.yaml` | Supplementary data (beyond URDF) |
| `docs/transforms.md` | Transformation matrices (KaTeX) |

## Customizing

Assemblies tagged `!dummy_` are designed to be swapped out. To replace one:

1. Create your replacement as a xacro macro with the same interface
2. Place it in `urdf/assemblies/`
3. Update the `<xacro:include>` in `urdf/Unsaved.urdf.xacro`
4. Update meshes in `meshes/<your_assembly>/`

The xacro prefix system (`${prefix}`) ensures link names stay unique
when multiple instances of the same assembly are used.

---
*Generated by Fusion URDF/XACRO Exporter v3.1.1*