# Transformation Matrices - Unsaved

Homogeneous transformation matrices between consecutive frames.
Convention: URDF RPY (XYZ extrinsic / ZYX intrinsic).

## Notation

### Frames

| Index | Link |
|-------|------|
| $L_{0}$ | base_link |
| $L_{1}$ | right_track_link |
| $L_{2}$ | left_track_link |
| $L_{3}$ | cage_link |
| $L_{4}$ | sensor_link |
| $L_{5}$ | turret_link |
| $L_{6}$ | left_front_roller |
| $L_{7}$ | left_rear_roller |
| $L_{8}$ | right_front_roller |
| $L_{9}$ | right_rear_roller |
| $L_{10}$ | upper_arm_link |
| $L_{11}$ | forearm_link |
| $L_{12}$ | wrist_link |
| $L_{13}$ | left_finger_link |
| $L_{14}$ | right_finger_link |

### Joint Variables

| Variable | Joint | Type | From | To |
|----------|-------|------|------|----|
| $q_{1}$ | turret_joint | revolute (rad) | $L_{0}$ | $L_{5}$ |
| $q_{2}$ | left_front_roller_joint | continuous (rad) | $L_{0}$ | $L_{6}$ |
| $q_{3}$ | left_rear_roller_joint | continuous (rad) | $L_{0}$ | $L_{7}$ |
| $q_{4}$ | right_front_roller_joint | continuous (rad) | $L_{0}$ | $L_{8}$ |
| $q_{5}$ | right_rear_roller_joint | continuous (rad) | $L_{0}$ | $L_{9}$ |
| $q_{6}$ | shoulder_joint | revolute (rad) | $L_{5}$ | $L_{10}$ |
| $q_{7}$ | elbow_joint | revolute (rad) | $L_{10}$ | $L_{11}$ |
| $q_{8}$ | wrist_joint | revolute (rad) | $L_{11}$ | $L_{12}$ |
| $q_{9}$ | left_finger_joint | prismatic (m) | $L_{12}$ | $L_{13}$ |
| $q_{10}$ | right_finger_joint | prismatic (m) | $L_{12}$ | $L_{14}$ |

Shorthand: $c_i = \cos(q_i)$, $s_i = \sin(q_i)$

### Kinematic Tree

```
L0: base_link
  |-- [fixed] right_track_link_fixed
  |   L1: right_track_link
  |-- [fixed] left_track_link_fixed
  |   L2: left_track_link
  |-- [fixed] cage_link_fixed
  |   L3: cage_link
  |-- [fixed] sensor_link_fixed
  |   L4: sensor_link
  |-- [revolute] turret_joint (q1)
  |   L5: turret_link
  |     +-- [revolute] shoulder_joint (q6)
  |         L10: upper_arm_link
  |           +-- [revolute] elbow_joint (q7)
  |               L11: forearm_link
  |                 +-- [revolute] wrist_joint (q8)
  |                     L12: wrist_link
  |                       |-- [prismatic] left_finger_joint (q9)
  |                       |   L13: left_finger_link
  |                       +-- [prismatic] right_finger_joint (q10)
  |                           L14: right_finger_link
  |-- [continuous] left_front_roller_joint (q2)
  |   L6: left_front_roller
  |-- [continuous] left_rear_roller_joint (q3)
  |   L7: left_rear_roller
  |-- [continuous] right_front_roller_joint (q4)
  |   L8: right_front_roller
  +-- [continuous] right_rear_roller_joint (q5)
      L9: right_rear_roller
```

## Transforms

## right_track_link_fixed

$L_{0}$ **base_link** -> $L_{1}$ **right_track_link** (fixed)

- **origin xyz**: (0, 0, 0) m
- **origin rpy**: (0, 0, 0) rad

### Local Transform

$$
T^{0}_{1} = \begin{bmatrix}
1 & 0 & 0 & 0 \\
0 & 1 & 0 & 0 \\
0 & 0 & 1 & 0 \\
0 & 0 & 0 & 1 \\
\end{bmatrix}
$$

---

## left_track_link_fixed

$L_{0}$ **base_link** -> $L_{2}$ **left_track_link** (fixed)

- **origin xyz**: (0, 0, 0) m
- **origin rpy**: (0, 0, 0) rad

### Local Transform

$$
T^{0}_{2} = \begin{bmatrix}
1 & 0 & 0 & 0 \\
0 & 1 & 0 & 0 \\
0 & 0 & 1 & 0 \\
0 & 0 & 0 & 1 \\
\end{bmatrix}
$$

---

## cage_link_fixed

$L_{0}$ **base_link** -> $L_{3}$ **cage_link** (fixed)

- **origin xyz**: (0, 0, 0) m
- **origin rpy**: (0, 0, 0) rad

### Local Transform

$$
T^{0}_{3} = \begin{bmatrix}
1 & 0 & 0 & 0 \\
0 & 1 & 0 & 0 \\
0 & 0 & 1 & 0 \\
0 & 0 & 0 & 1 \\
\end{bmatrix}
$$

---

## sensor_link_fixed

$L_{0}$ **base_link** -> $L_{4}$ **sensor_link** (fixed)

- **origin xyz**: (0, 0, 0) m
- **origin rpy**: (0, 0, 0) rad

### Local Transform

$$
T^{0}_{4} = \begin{bmatrix}
1 & 0 & 0 & 0 \\
0 & 1 & 0 & 0 \\
0 & 0 & 1 & 0 \\
0 & 0 & 0 & 1 \\
\end{bmatrix}
$$

---

## turret_joint

$L_{0}$ **base_link** -> $L_{5}$ **turret_link** (revolute)
  Variable: $q_{1}$

- **origin xyz**: (0.055, 0, 0.203) m
- **origin rpy**: (0, 0, 0) rad
- **axis**: (0, 0, 1)
- **limits**: [-1.570796, 1.570796] rad ([-90deg, 90deg])

### Local Transform

$$
T^{0}_{5}(q_{1}) = \begin{bmatrix}
c_{1} & -s_{1} & 0 & 0.055 \\
s_{1} & c_{1} & 0 & 0 \\
0 & 0 & 1 & 0.203 \\
0 & 0 & 0 & 1 \\
\end{bmatrix}
$$

---

## left_front_roller_joint

$L_{0}$ **base_link** -> $L_{6}$ **left_front_roller** (continuous)
  Variable: $q_{2}$

- **origin xyz**: (0.155, 0.165, 0.073) m
- **origin rpy**: (0, 0, 0) rad
- **axis**: (0, 0, 1)

### Local Transform

$$
T^{0}_{6}(q_{2}) = \begin{bmatrix}
c_{2} & -s_{2} & 0 & 0.155 \\
s_{2} & c_{2} & 0 & 0.165 \\
0 & 0 & 1 & 0.073 \\
0 & 0 & 0 & 1 \\
\end{bmatrix}
$$

---

## left_rear_roller_joint

$L_{0}$ **base_link** -> $L_{7}$ **left_rear_roller** (continuous)
  Variable: $q_{3}$

- **origin xyz**: (-0.155, 0.165, 0.073) m
- **origin rpy**: (0, 0, 0) rad
- **axis**: (0, 0, 1)

### Local Transform

$$
T^{0}_{7}(q_{3}) = \begin{bmatrix}
c_{3} & -s_{3} & 0 & -0.155 \\
s_{3} & c_{3} & 0 & 0.165 \\
0 & 0 & 1 & 0.073 \\
0 & 0 & 0 & 1 \\
\end{bmatrix}
$$

---

## right_front_roller_joint

$L_{0}$ **base_link** -> $L_{8}$ **right_front_roller** (continuous)
  Variable: $q_{4}$

- **origin xyz**: (0.155, -0.165, 0.073) m
- **origin rpy**: (0, 0, 0) rad
- **axis**: (0, 0, 1)

### Local Transform

$$
T^{0}_{8}(q_{4}) = \begin{bmatrix}
c_{4} & -s_{4} & 0 & 0.155 \\
s_{4} & c_{4} & 0 & -0.165 \\
0 & 0 & 1 & 0.073 \\
0 & 0 & 0 & 1 \\
\end{bmatrix}
$$

---

## right_rear_roller_joint

$L_{0}$ **base_link** -> $L_{9}$ **right_rear_roller** (continuous)
  Variable: $q_{5}$

- **origin xyz**: (-0.155, -0.165, 0.073) m
- **origin rpy**: (0, 0, 0) rad
- **axis**: (0, 0, 1)

### Local Transform

$$
T^{0}_{9}(q_{5}) = \begin{bmatrix}
c_{5} & -s_{5} & 0 & -0.155 \\
s_{5} & c_{5} & 0 & -0.165 \\
0 & 0 & 1 & 0.073 \\
0 & 0 & 0 & 1 \\
\end{bmatrix}
$$

---

## shoulder_joint

$L_{5}$ **turret_link** -> $L_{10}$ **upper_arm_link** (revolute)
  Variable: $q_{6}$

- **origin xyz**: (0, 0, 0.031) m
- **origin rpy**: (0, 0, 0) rad
- **axis**: (0, 0, 1)
- **limits**: [-0.649262, 0.450295] rad ([-37.2deg, 25.8deg])

### Local Transform

$$
T^{5}_{10}(q_{6}) = \begin{bmatrix}
c_{6} & -s_{6} & 0 & 0 \\
s_{6} & c_{6} & 0 & 0 \\
0 & 0 & 1 & 0.031 \\
0 & 0 & 0 & 1 \\
\end{bmatrix}
$$

---

## elbow_joint

$L_{10}$ **upper_arm_link** -> $L_{11}$ **forearm_link** (revolute)
  Variable: $q_{7}$

- **origin xyz**: (0.094, 0, 0.111) m
- **origin rpy**: (0, 0, 0) rad
- **axis**: (0, 0, 1)
- **limits**: [-0.699877, 0.699877] rad ([-40.1deg, 40.1deg])

### Local Transform

$$
T^{10}_{11}(q_{7}) = \begin{bmatrix}
c_{7} & -s_{7} & 0 & 0.094 \\
s_{7} & c_{7} & 0 & 0 \\
0 & 0 & 1 & 0.111 \\
0 & 0 & 0 & 1 \\
\end{bmatrix}
$$

---

## wrist_joint

$L_{11}$ **forearm_link** -> $L_{12}$ **wrist_link** (revolute)
  Variable: $q_{8}$

- **origin xyz**: (0.141, 0, -0.067) m
- **origin rpy**: (0, 0, 0) rad
- **axis**: (0, 0, 1)
- **limits**: [-0.699877, 0.699877] rad ([-40.1deg, 40.1deg])

### Local Transform

$$
T^{11}_{12}(q_{8}) = \begin{bmatrix}
c_{8} & -s_{8} & 0 & 0.141 \\
s_{8} & c_{8} & 0 & 0 \\
0 & 0 & 1 & -0.067 \\
0 & 0 & 0 & 1 \\
\end{bmatrix}
$$

---

## left_finger_joint

$L_{12}$ **wrist_link** -> $L_{13}$ **left_finger_link** (prismatic)
  Variable: $q_{9}$

- **origin xyz**: (0.042, 0.033, -0.016) m
- **origin rpy**: (0, 0, 0) rad
- **axis**: (0, 0, 1)
- **limits**: [-0.008, 0.025] m

### Local Transform

$$
T^{12}_{13}(q_{9}) = \begin{bmatrix}
1 & 0 & 0 & 0.042 \\
0 & 1 & 0 & 0.033 \\
0 & 0 & 1 & -0.016 + q_{9} \\
0 & 0 & 0 & 1 \\
\end{bmatrix}
$$

---

## right_finger_joint

$L_{12}$ **wrist_link** -> $L_{14}$ **right_finger_link** (prismatic)
  Variable: $q_{10}$

- **origin xyz**: (0.042, -0.033, -0.016) m
- **origin rpy**: (0, 0, 0) rad
- **axis**: (0, 0, 1)
- **limits**: [-0.008, 0.025] m

### Local Transform

$$
T^{12}_{14}(q_{10}) = \begin{bmatrix}
1 & 0 & 0 & 0.042 \\
0 & 1 & 0 & -0.033 \\
0 & 0 & 1 & -0.016 + q_{10} \\
0 & 0 & 0 & 1 \\
\end{bmatrix}
$$

---

## Global Transform Chains

Transform from root $L_0$ to any link, as product of local transforms along the kinematic chain.

$$T^{0}_{10} = T^{0}_{5}(q_{1}) \cdot T^{5}_{10}(q_{6})\quad (L_0 \to L_{10}: \text{upper_arm_link})$$

$$T^{0}_{11} = T^{0}_{5}(q_{1}) \cdot T^{5}_{10}(q_{6}) \cdot T^{10}_{11}(q_{7})\quad (L_0 \to L_{11}: \text{forearm_link})$$

$$T^{0}_{12} = T^{0}_{5}(q_{1}) \cdot T^{5}_{10}(q_{6}) \cdot T^{10}_{11}(q_{7}) \cdot T^{11}_{12}(q_{8})\quad (L_0 \to L_{12}: \text{wrist_link})$$

$$T^{0}_{13} = T^{0}_{5}(q_{1}) \cdot T^{5}_{10}(q_{6}) \cdot T^{10}_{11}(q_{7}) \cdot T^{11}_{12}(q_{8}) \cdot T^{12}_{13}(q_{9})\quad (L_0 \to L_{13}: \text{left_finger_link})$$

$$T^{0}_{14} = T^{0}_{5}(q_{1}) \cdot T^{5}_{10}(q_{6}) \cdot T^{10}_{11}(q_{7}) \cdot T^{11}_{12}(q_{8}) \cdot T^{12}_{14}(q_{10})\quad (L_0 \to L_{14}: \text{right_finger_link})$$

