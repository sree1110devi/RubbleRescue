import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, SetEnvironmentVariable
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import Command
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue

def generate_launch_description():
    pkg_gazebo = get_package_share_directory('rubblerescue_gazebo')
    pkg_description = get_package_share_directory('robocar_description')
    pkg_ros_gz_sim = get_package_share_directory('ros_gz_sim')

    world_path = os.path.join(pkg_gazebo, 'worlds', 'rubble_world.sdf')
    xacro_file = os.path.join(pkg_description, 'urdf', 'Unsaved.urdf.xacro')

    # Path to where package meshes are installed so Gazebo can resolve model://
    description_share_parent = os.path.dirname(pkg_description)

    # 1. Set Gazebo Resource Path so it finds CAD meshes
    gz_resource_path = SetEnvironmentVariable(
        name='GZ_SIM_RESOURCE_PATH',
        value=[description_share_parent, ':', os.environ.get('GZ_SIM_RESOURCE_PATH', '')]
    )

    robot_description = ParameterValue(
        Command(['xacro ', xacro_file]),
        value_type=str
    )

    # 2. Start Gazebo Sim with Rubble World
    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_ros_gz_sim, 'launch', 'gz_sim.launch.py')
        ),
        launch_arguments={'gz_args': f'-r {world_path}'}.items(),
    )

    # 3. Robot State Publisher
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        parameters=[{
            'robot_description': robot_description,
            'use_sim_time': True
        }],
        output='screen'
    )

    # 4. Spawn Robot Entity into Gazebo
    spawn_robot = Node(
        package='ros_gz_sim',
        executable='create',
        arguments=[
            '-name', 'rubblerescue',
            '-topic', 'robot_description',
            '-x', '0.0',
            '-y', '0.0',
            '-z', '0.2',
        ],
        output='screen'
    )

    # 5. Bridge /cmd_vel and /odom between ROS 2 and Gazebo
    bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        arguments=[
            '/cmd_vel@geometry_msgs/msg/Twist@gz.msgs.Twist',
            '/odom@nav_msgs/msg/Odometry@gz.msgs.Odometry',
            '/joint_states@sensor_msgs/msg/JointState@gz.msgs.Model',
            '/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock',
            '/rescue_camera/image@sensor_msgs/msg/Image[gz.msgs.Image',
            '/rescue_camera/depth_image@sensor_msgs/msg/Image[gz.msgs.Image',
            '/rescue_camera/camera_info@sensor_msgs/msg/CameraInfo[gz.msgs.CameraInfo',
            '/rescue_camera/points@sensor_msgs/msg/PointCloud2[gz.msgs.PointCloudPacked',

            '/scan@sensor_msgs/msg/LaserScan[gz.msgs.LaserScan',
        ],
        output='screen'
    )

    return LaunchDescription([
        gz_resource_path,
        gazebo,
        robot_state_publisher,
        spawn_robot,
        bridge,
    ])